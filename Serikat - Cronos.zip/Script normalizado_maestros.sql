﻿PRINT 'normalizado_maestros.sql'
GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_tipos_ingreso')
CREATE TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_ingreso(
  id_tipo_ingreso int IDENTITY(1,1),
  tipo_ingreso varchar(1) NOT NULL,
  des_tipo_ingreso varchar(50) NOT NULL,
  es_indefinido bit,
  fec_alta datetime,
  fec_modificacion datetime,
  fec_baja datetime,
  CONSTRAINT uk_ot_tipos_ingreso UNIQUE (tipo_ingreso),
  CONSTRAINT PK_tbn1_ot_tipos_ingreso PRIMARY KEY CLUSTERED (id_tipo_ingreso)
)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_tipos_ingreso' AND COLUMN_NAME='id_tipo_ingreso')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_ingreso ADD id_tipo_ingreso int

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_tipos_ingreso' AND COLUMN_NAME='tipo_ingreso')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_ingreso ADD tipo_ingreso varchar(1)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_tipos_ingreso' AND COLUMN_NAME='des_tipo_ingreso')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_ingreso ADD des_tipo_ingreso varchar(50)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_tipos_ingreso' AND COLUMN_NAME='es_indefinido')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_ingreso ADD es_indefinido bit

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_tipos_ingreso' AND COLUMN_NAME='fec_alta')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_ingreso ADD fec_alta datetime

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_tipos_ingreso' AND COLUMN_NAME='fec_modificacion')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_ingreso ADD fec_modificacion datetime

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_tipos_ingreso' AND COLUMN_NAME='fec_baja')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_ingreso ADD fec_baja datetime

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_tipos_ingreso' AND COLUMN_NAME='es_indefinido' AND COLUMN_DEFAULT IS NULL)
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_ingreso ADD CONSTRAINT DF_DBO_TBN1_OT_TIPOS_INGRESO_ES_INDEFINIDO DEFAULT 0 FOR es_indefinido

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_tipos_ingreso' AND COLUMN_NAME='id_tipo_ingreso' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_ingreso ALTER COLUMN id_tipo_ingreso int NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_tipos_ingreso' AND COLUMN_NAME='tipo_ingreso' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_ingreso ALTER COLUMN tipo_ingreso varchar(1) NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_tipos_ingreso' AND COLUMN_NAME='des_tipo_ingreso' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_ingreso ALTER COLUMN des_tipo_ingreso varchar(50) NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_tipos_ingreso' AND COLUMN_NAME='es_indefinido' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_ingreso ALTER COLUMN es_indefinido bit NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_tipos_ingreso' AND COLUMN_NAME='fec_alta' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_ingreso ALTER COLUMN fec_alta datetime NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_tipos_ingreso' AND COLUMN_NAME='fec_modificacion' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_ingreso ALTER COLUMN fec_modificacion datetime NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_tipos_ingreso' AND COLUMN_NAME='fec_baja' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_ingreso ALTER COLUMN fec_baja datetime NULL

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_tipos_ingreso' AND CONSTRAINT_NAME='PK_tbn1_ot_tipos_ingreso')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_ingreso ADD CONSTRAINT PK_tbn1_ot_tipos_ingreso PRIMARY KEY CLUSTERED (id_tipo_ingreso)

GO

;WITH
query AS (
  SELECT 1 AS es_indefinido,'9' AS tipo_ingreso,'Otro' AS des_tipo_ingreso
)
MERGE dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_ingreso AS tbn1_ot_tipos_ingreso
USING query ON query.es_indefinido=tbn1_ot_tipos_ingreso.es_indefinido
WHEN MATCHED AND ((tbn1_ot_tipos_ingreso.tipo_ingreso<>query.tipo_ingreso OR (tbn1_ot_tipos_ingreso.tipo_ingreso IS NULL AND query.tipo_ingreso IS NOT NULL) OR  (tbn1_ot_tipos_ingreso.tipo_ingreso IS NOT NULL AND query.tipo_ingreso IS NULL)
                  OR tbn1_ot_tipos_ingreso.des_tipo_ingreso<>query.des_tipo_ingreso OR (tbn1_ot_tipos_ingreso.des_tipo_ingreso IS NULL AND query.des_tipo_ingreso IS NOT NULL) OR  (tbn1_ot_tipos_ingreso.des_tipo_ingreso IS NOT NULL AND query.des_tipo_ingreso IS NULL))) THEN
  UPDATE SET
    tipo_ingreso=query.tipo_ingreso,
    des_tipo_ingreso=query.des_tipo_ingreso
WHEN NOT MATCHED THEN
  INSERT (es_indefinido,tipo_ingreso,des_tipo_ingreso) VALUES (
    query.es_indefinido,
    query.tipo_ingreso,
    query.des_tipo_ingreso);
GO

USE dbn1_stg_dhyf_u
GO

IF EXISTS (SELECT 1 FROM dbn1_stg_dhyf_u.INFORMATION_SCHEMA.ROUTINES WHERE ROUTINE_SCHEMA='dbo' AND ROUTINE_NAME='spn1_cargar_normalizado_ot_tipos_ingreso' AND ROUTINE_TYPE='PROCEDURE')
DROP PROCEDURE dbo.spn1_cargar_normalizado_ot_tipos_ingreso;
GO

CREATE PROCEDURE dbo.spn1_cargar_normalizado_ot_tipos_ingreso(@logpadre int) AS
BEGIN

  DECLARE @procedure_name varchar(100)='dbn1_stg_dhyf_u.dbo.spn1_cargar_normalizado_ot_tipos_ingreso'
  SET NOCOUNT ON;
  DECLARE @log int;
  EXECUTE @log = dbn1_stg_dhyf_u.dbo.spn1_apuntar_log @logpadre,@procedure_name;
  DECLARE @fecha_ultima_carga datetime=dbn1_stg_dhyf_u.dbo.fnn1_fecha_ultima_carga(@log);
  DECLARE @continuar_en_caso_error bit=0;
  IF @logpadre IS NOT NULL AND EXISTS (SELECT 1 AS expr1
  FROM dbn1_norm_dhyf_u.audit.tbn1_procedimientos_excluidos
  WHERE
    'dbn1_stg_dhyf_u.dbo.'+procedimiento=@procedure_name
    AND excluido=1
  ) BEGIN
    UPDATE dbn1_norm_dhyf_u.audit.tbn1_logs SET
      mensaje_error='EXCLUÍDO'
    WHERE
      id_log=@log;
    RETURN
  END
     BEGIN TRY

  ;WITH
  query AS (
    SELECT
      ting.tinting AS tipo_ingreso,
      ting.tindesc AS des_tipo_ingreso
    FROM dbn1_stg_dhyf_u.dbo.tbn1ting_ti ting
    WHERE
      ting.tinenti='DF'
      AND ting.tinejer=(SELECT max(tinejer) AS expr1
      FROM dbn1_stg_dhyf_u.dbo.tbn1ting_ti
      )
    GROUP BY
      ting.tinting,
      ting.tindesc
  )
  MERGE dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_ingreso AS tbn1_ot_tipos_ingreso
  USING query ON query.tipo_ingreso=tbn1_ot_tipos_ingreso.tipo_ingreso
  WHEN MATCHED AND (tbn1_ot_tipos_ingreso.es_indefinido=0
                    AND (tbn1_ot_tipos_ingreso.des_tipo_ingreso<>query.des_tipo_ingreso OR (tbn1_ot_tipos_ingreso.des_tipo_ingreso IS NULL AND query.des_tipo_ingreso IS NOT NULL) OR  (tbn1_ot_tipos_ingreso.des_tipo_ingreso IS NOT NULL AND query.des_tipo_ingreso IS NULL)
                    OR (fec_baja IS NOT NULL))) THEN
    UPDATE SET
      des_tipo_ingreso=query.des_tipo_ingreso,
      fec_modificacion=getdate(),
      fec_baja=null
  WHEN NOT MATCHED THEN
    INSERT (tipo_ingreso,des_tipo_ingreso,fec_alta,fec_modificacion) VALUES (
      query.tipo_ingreso,
      query.des_tipo_ingreso,
      getdate(),
      getdate())
  WHEN NOT MATCHED BY SOURCE AND (tbn1_ot_tipos_ingreso.es_indefinido=0
                                  AND fec_baja IS NULL) THEN
    UPDATE SET
      fec_baja=getdate(),
      fec_modificacion=getdate();

  EXECUTE dbn1_stg_dhyf_u.dbo.spn1_finalizar_log @log,@@ROWCOUNT;
   END TRY
  BEGIN CATCH
    EXECUTE dbn1_stg_dhyf_u.dbo.spn1_finalizar_log @log,null;
    UPDATE dbn1_norm_dhyf_u.audit.tbn1_logs SET
      mensaje_error=error_message(),
      procedimiento_error=error_procedure()
    WHERE
      id_log=@log;
    IF @continuar_en_caso_error=0 OR @logpadre IS NULL THROW
  END CATCH


END

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_claves_ingreso')
CREATE TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_ingreso(
  id_clave_ingreso int IDENTITY(1,1),
  cod_clave_ingreso varchar(7) NOT NULL,
  clave_ingreso varchar(50) NOT NULL,
  ejercicio_descripcion smallint,
  es_ingreso_del_presupuesto bit NOT NULL,
  es_indefinido bit,
  fec_alta datetime,
  fec_modificacion datetime,
  fec_baja datetime,
  CONSTRAINT uk_ot_claves_ingreso UNIQUE (cod_clave_ingreso),
  CONSTRAINT PK_tbn1_ot_claves_ingreso PRIMARY KEY CLUSTERED (id_clave_ingreso)
)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_claves_ingreso' AND COLUMN_NAME='id_clave_ingreso')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_ingreso ADD id_clave_ingreso int

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_claves_ingreso' AND COLUMN_NAME='cod_clave_ingreso')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_ingreso ADD cod_clave_ingreso varchar(7)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_claves_ingreso' AND COLUMN_NAME='clave_ingreso')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_ingreso ADD clave_ingreso varchar(50)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_claves_ingreso' AND COLUMN_NAME='ejercicio_descripcion')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_ingreso ADD ejercicio_descripcion smallint

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_claves_ingreso' AND COLUMN_NAME='es_ingreso_del_presupuesto')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_ingreso ADD es_ingreso_del_presupuesto bit

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_claves_ingreso' AND COLUMN_NAME='es_indefinido')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_ingreso ADD es_indefinido bit

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_claves_ingreso' AND COLUMN_NAME='fec_alta')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_ingreso ADD fec_alta datetime

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_claves_ingreso' AND COLUMN_NAME='fec_modificacion')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_ingreso ADD fec_modificacion datetime

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_claves_ingreso' AND COLUMN_NAME='fec_baja')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_ingreso ADD fec_baja datetime

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_claves_ingreso' AND COLUMN_NAME='es_ingreso_del_presupuesto' AND COLUMN_DEFAULT IS NULL)
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_ingreso ADD CONSTRAINT DF_DBO_TBN1_OT_CLAVES_INGRESO_ES_INGRESO_DEL_PRESUPUESTO DEFAULT 0 FOR es_ingreso_del_presupuesto

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_claves_ingreso' AND COLUMN_NAME='es_indefinido' AND COLUMN_DEFAULT IS NULL)
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_ingreso ADD CONSTRAINT DF_DBO_TBN1_OT_CLAVES_INGRESO_ES_INDEFINIDO DEFAULT 0 FOR es_indefinido

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_claves_ingreso' AND COLUMN_NAME='id_clave_ingreso' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_ingreso ALTER COLUMN id_clave_ingreso int NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_claves_ingreso' AND COLUMN_NAME='cod_clave_ingreso' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_ingreso ALTER COLUMN cod_clave_ingreso varchar(7) NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_claves_ingreso' AND COLUMN_NAME='clave_ingreso' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_ingreso ALTER COLUMN clave_ingreso varchar(50) NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_claves_ingreso' AND COLUMN_NAME='ejercicio_descripcion' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_ingreso ALTER COLUMN ejercicio_descripcion smallint NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_claves_ingreso' AND COLUMN_NAME='es_ingreso_del_presupuesto' AND IS_NULLABLE='YES')
BEGIN
  UPDATE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_ingreso SET es_ingreso_del_presupuesto=0 WHERE es_ingreso_del_presupuesto IS NULL
  ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_ingreso ALTER COLUMN es_ingreso_del_presupuesto bit NOT NULL
END

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_claves_ingreso' AND COLUMN_NAME='es_indefinido' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_ingreso ALTER COLUMN es_indefinido bit NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_claves_ingreso' AND COLUMN_NAME='fec_alta' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_ingreso ALTER COLUMN fec_alta datetime NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_claves_ingreso' AND COLUMN_NAME='fec_modificacion' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_ingreso ALTER COLUMN fec_modificacion datetime NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_claves_ingreso' AND COLUMN_NAME='fec_baja' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_ingreso ALTER COLUMN fec_baja datetime NULL

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_claves_ingreso' AND CONSTRAINT_NAME='PK_tbn1_ot_claves_ingreso')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_ingreso ADD CONSTRAINT PK_tbn1_ot_claves_ingreso PRIMARY KEY CLUSTERED (id_clave_ingreso)

GO

;WITH
query AS (
  SELECT 1 AS es_indefinido,'' AS cod_clave_ingreso,'Indefinido' AS clave_ingreso
)
MERGE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_ingreso AS tbn1_ot_claves_ingreso
USING query ON query.es_indefinido=tbn1_ot_claves_ingreso.es_indefinido
WHEN MATCHED AND ((tbn1_ot_claves_ingreso.cod_clave_ingreso<>query.cod_clave_ingreso OR (tbn1_ot_claves_ingreso.cod_clave_ingreso IS NULL AND query.cod_clave_ingreso IS NOT NULL) OR  (tbn1_ot_claves_ingreso.cod_clave_ingreso IS NOT NULL AND query.cod_clave_ingreso IS NULL)
                  OR tbn1_ot_claves_ingreso.clave_ingreso<>query.clave_ingreso OR (tbn1_ot_claves_ingreso.clave_ingreso IS NULL AND query.clave_ingreso IS NOT NULL) OR  (tbn1_ot_claves_ingreso.clave_ingreso IS NOT NULL AND query.clave_ingreso IS NULL))) THEN
  UPDATE SET
    cod_clave_ingreso=query.cod_clave_ingreso,
    clave_ingreso=query.clave_ingreso
WHEN NOT MATCHED THEN
  INSERT (es_indefinido,cod_clave_ingreso,clave_ingreso) VALUES (
    query.es_indefinido,
    query.cod_clave_ingreso,
    query.clave_ingreso);
GO

USE dbn1_stg_dhyf_u
GO

IF EXISTS (SELECT 1 FROM dbn1_stg_dhyf_u.INFORMATION_SCHEMA.ROUTINES WHERE ROUTINE_SCHEMA='dbo' AND ROUTINE_NAME='spn1_cargar_normalizado_ot_claves_ingreso' AND ROUTINE_TYPE='PROCEDURE')
DROP PROCEDURE dbo.spn1_cargar_normalizado_ot_claves_ingreso;
GO

CREATE PROCEDURE dbo.spn1_cargar_normalizado_ot_claves_ingreso(@logpadre int) AS
BEGIN

  DECLARE @procedure_name varchar(100)='dbn1_stg_dhyf_u.dbo.spn1_cargar_normalizado_ot_claves_ingreso'
  SET NOCOUNT ON;
  DECLARE @log int;
  EXECUTE @log = dbn1_stg_dhyf_u.dbo.spn1_apuntar_log @logpadre,@procedure_name;
  DECLARE @fecha_ultima_carga datetime=dbn1_stg_dhyf_u.dbo.fnn1_fecha_ultima_carga(@log);
  DECLARE @continuar_en_caso_error bit=0;
  IF @logpadre IS NOT NULL AND EXISTS (SELECT 1 AS expr1
  FROM dbn1_norm_dhyf_u.audit.tbn1_procedimientos_excluidos
  WHERE
    'dbn1_stg_dhyf_u.dbo.'+procedimiento=@procedure_name
    AND excluido=1
  ) BEGIN
    UPDATE dbn1_norm_dhyf_u.audit.tbn1_logs SET
      mensaje_error='EXCLUÍDO'
    WHERE
      id_log=@log;
    RETURN
  END
     BEGIN TRY

  ;WITH
  allRows AS (
    SELECT
      ccoccon AS cod_clave_ingreso,
      ccodesc AS clave_ingreso,
      ccoejer AS ejercicio_descripcion,
      CASE WHEN ccoting='I' THEN 1 ELSE 0 END AS es_ingreso_del_presupuesto
    FROM dbn1_stg_dhyf_u.dbo.tbn1ccon_ti
    WHERE ccoenti='DF'
  ),
  allRowsNumbered AS (
    SELECT
      cod_clave_ingreso,
      clave_ingreso,
      ejercicio_descripcion,
      es_ingreso_del_presupuesto,
      ROW_NUMBER() OVER (PARTITION BY cod_clave_ingreso ORDER BY es_ingreso_del_presupuesto DESC,ejercicio_descripcion DESC) rownumber
    FROM allRows
  ),
  query AS (
    SELECT
      cod_clave_ingreso,
      clave_ingreso,
      ejercicio_descripcion,
      es_ingreso_del_presupuesto
    FROM allRowsNumbered
    WHERE rownumber<=1
  )
  MERGE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_ingreso AS tbn1_ot_claves_ingreso
  USING query ON query.cod_clave_ingreso=tbn1_ot_claves_ingreso.cod_clave_ingreso
  WHEN MATCHED AND (tbn1_ot_claves_ingreso.es_indefinido=0
                    AND (tbn1_ot_claves_ingreso.clave_ingreso<>query.clave_ingreso OR (tbn1_ot_claves_ingreso.clave_ingreso IS NULL AND query.clave_ingreso IS NOT NULL) OR  (tbn1_ot_claves_ingreso.clave_ingreso IS NOT NULL AND query.clave_ingreso IS NULL)
                    OR tbn1_ot_claves_ingreso.ejercicio_descripcion<>query.ejercicio_descripcion OR (tbn1_ot_claves_ingreso.ejercicio_descripcion IS NULL AND query.ejercicio_descripcion IS NOT NULL) OR  (tbn1_ot_claves_ingreso.ejercicio_descripcion IS NOT NULL AND query.ejercicio_descripcion IS NULL)
                    OR tbn1_ot_claves_ingreso.es_ingreso_del_presupuesto<>query.es_ingreso_del_presupuesto OR (tbn1_ot_claves_ingreso.es_ingreso_del_presupuesto IS NULL AND query.es_ingreso_del_presupuesto IS NOT NULL) OR  (tbn1_ot_claves_ingreso.es_ingreso_del_presupuesto IS NOT NULL AND query.es_ingreso_del_presupuesto IS NULL)
                    OR (fec_baja IS NOT NULL))) THEN
    UPDATE SET
      clave_ingreso=query.clave_ingreso,
      ejercicio_descripcion=query.ejercicio_descripcion,
      es_ingreso_del_presupuesto=query.es_ingreso_del_presupuesto,
      fec_modificacion=getdate(),
      fec_baja=null
  WHEN NOT MATCHED THEN
    INSERT (cod_clave_ingreso,clave_ingreso,ejercicio_descripcion,es_ingreso_del_presupuesto,fec_alta,fec_modificacion) VALUES (
      query.cod_clave_ingreso,
      query.clave_ingreso,
      query.ejercicio_descripcion,
      query.es_ingreso_del_presupuesto,
      getdate(),
      getdate())
  WHEN NOT MATCHED BY SOURCE AND (tbn1_ot_claves_ingreso.es_indefinido=0
                                  AND fec_baja IS NULL) THEN
    UPDATE SET
      fec_baja=getdate(),
      fec_modificacion=getdate();

  EXECUTE dbn1_stg_dhyf_u.dbo.spn1_finalizar_log @log,@@ROWCOUNT;
   END TRY
  BEGIN CATCH
    EXECUTE dbn1_stg_dhyf_u.dbo.spn1_finalizar_log @log,null;
    UPDATE dbn1_norm_dhyf_u.audit.tbn1_logs SET
      mensaje_error=error_message(),
      procedimiento_error=error_procedure()
    WHERE
      id_log=@log;
    IF @continuar_en_caso_error=0 OR @logpadre IS NULL THROW
  END CATCH


END

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_claves_contables')
CREATE TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_contables(
  id_clave_contable int IDENTITY(1,1),
  anyo_contraido varchar(2) NOT NULL,
  id_tipo_ingreso int NOT NULL,
  id_clave_ingreso int NOT NULL,
  tipo_ingreso varchar(1) NOT NULL,
  clave_ingreso varchar(7) NOT NULL,
  descripcion varchar(50) NOT NULL,
  concepto varchar(20) NOT NULL,
  es_indefinido bit,
  origen varchar(10) NOT NULL,
  fec_alta datetime,
  fec_modificacion datetime,
  fec_baja datetime,
  CONSTRAINT uk_ot_claves_contables UNIQUE (anyo_contraido,tipo_ingreso,clave_ingreso),
  CONSTRAINT PK_tbn1_ot_claves_contables PRIMARY KEY CLUSTERED (id_clave_contable),
  CONSTRAINT FK_tbn1_ot_claves_contables_tbn1_ot_tipos_ingreso FOREIGN KEY (id_tipo_ingreso) REFERENCES dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_ingreso(id_tipo_ingreso),
  CONSTRAINT FK_tbn1_ot_claves_contables_tbn1_ot_claves_ingreso FOREIGN KEY (id_clave_ingreso) REFERENCES dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_ingreso(id_clave_ingreso)
)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_claves_contables' AND COLUMN_NAME='id_clave_contable')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_contables ADD id_clave_contable int

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_claves_contables' AND COLUMN_NAME='anyo_contraido')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_contables ADD anyo_contraido varchar(2)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_claves_contables' AND COLUMN_NAME='id_tipo_ingreso')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_contables ADD id_tipo_ingreso int

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_claves_contables' AND COLUMN_NAME='id_clave_ingreso')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_contables ADD id_clave_ingreso int

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_claves_contables' AND COLUMN_NAME='tipo_ingreso')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_contables ADD tipo_ingreso varchar(1)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_claves_contables' AND COLUMN_NAME='clave_ingreso')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_contables ADD clave_ingreso varchar(7)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_claves_contables' AND COLUMN_NAME='descripcion')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_contables ADD descripcion varchar(50)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_claves_contables' AND COLUMN_NAME='concepto')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_contables ADD concepto varchar(20)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_claves_contables' AND COLUMN_NAME='es_indefinido')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_contables ADD es_indefinido bit

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_claves_contables' AND COLUMN_NAME='origen')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_contables ADD origen varchar(10)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_claves_contables' AND COLUMN_NAME='fec_alta')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_contables ADD fec_alta datetime

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_claves_contables' AND COLUMN_NAME='fec_modificacion')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_contables ADD fec_modificacion datetime

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_claves_contables' AND COLUMN_NAME='fec_baja')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_contables ADD fec_baja datetime

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_claves_contables' AND COLUMN_NAME='id_clave_ingreso' AND COLUMN_DEFAULT IS NULL)
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_contables ADD CONSTRAINT DF_DBO_TBN1_OT_CLAVES_CONTABLES_ID_CLAVE_INGRESO DEFAULT 1 FOR id_clave_ingreso

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_claves_contables' AND COLUMN_NAME='tipo_ingreso' AND COLUMN_DEFAULT IS NULL)
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_contables ADD CONSTRAINT DF_DBO_TBN1_OT_CLAVES_CONTABLES_TIPO_INGRESO DEFAULT '' FOR tipo_ingreso

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_claves_contables' AND COLUMN_NAME='descripcion' AND COLUMN_DEFAULT IS NULL)
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_contables ADD CONSTRAINT DF_DBO_TBN1_OT_CLAVES_CONTABLES_DESCRIPCION DEFAULT '' FOR descripcion

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_claves_contables' AND COLUMN_NAME='concepto' AND COLUMN_DEFAULT IS NULL)
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_contables ADD CONSTRAINT DF_DBO_TBN1_OT_CLAVES_CONTABLES_CONCEPTO DEFAULT '' FOR concepto

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_claves_contables' AND COLUMN_NAME='es_indefinido' AND COLUMN_DEFAULT IS NULL)
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_contables ADD CONSTRAINT DF_DBO_TBN1_OT_CLAVES_CONTABLES_ES_INDEFINIDO DEFAULT 0 FOR es_indefinido

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_claves_contables' AND COLUMN_NAME='origen' AND COLUMN_DEFAULT IS NULL)
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_contables ADD CONSTRAINT DF_DBO_TBN1_OT_CLAVES_CONTABLES_ORIGEN DEFAULT '' FOR origen

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_claves_contables' AND COLUMN_NAME='id_clave_contable' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_contables ALTER COLUMN id_clave_contable int NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_claves_contables' AND COLUMN_NAME='anyo_contraido' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_contables ALTER COLUMN anyo_contraido varchar(2) NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_claves_contables' AND COLUMN_NAME='id_tipo_ingreso' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_contables ALTER COLUMN id_tipo_ingreso int NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_claves_contables' AND COLUMN_NAME='id_clave_ingreso' AND IS_NULLABLE='YES')
BEGIN
  UPDATE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_contables SET id_clave_ingreso=1 WHERE id_clave_ingreso IS NULL
  ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_contables ALTER COLUMN id_clave_ingreso int NOT NULL
END

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_claves_contables' AND COLUMN_NAME='tipo_ingreso' AND IS_NULLABLE='YES')
BEGIN
  UPDATE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_contables SET tipo_ingreso='' WHERE tipo_ingreso IS NULL
  ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_contables ALTER COLUMN tipo_ingreso varchar(1) NOT NULL
END

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_claves_contables' AND COLUMN_NAME='clave_ingreso' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_contables ALTER COLUMN clave_ingreso varchar(7) NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_claves_contables' AND COLUMN_NAME='descripcion' AND IS_NULLABLE='YES')
BEGIN
  UPDATE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_contables SET descripcion='' WHERE descripcion IS NULL
  ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_contables ALTER COLUMN descripcion varchar(50) NOT NULL
END

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_claves_contables' AND COLUMN_NAME='concepto' AND IS_NULLABLE='YES')
BEGIN
  UPDATE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_contables SET concepto='' WHERE concepto IS NULL
  ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_contables ALTER COLUMN concepto varchar(20) NOT NULL
END

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_claves_contables' AND COLUMN_NAME='es_indefinido' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_contables ALTER COLUMN es_indefinido bit NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_claves_contables' AND COLUMN_NAME='origen' AND IS_NULLABLE='YES')
BEGIN
  UPDATE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_contables SET origen='' WHERE origen IS NULL
  ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_contables ALTER COLUMN origen varchar(10) NOT NULL
END

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_claves_contables' AND COLUMN_NAME='fec_alta' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_contables ALTER COLUMN fec_alta datetime NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_claves_contables' AND COLUMN_NAME='fec_modificacion' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_contables ALTER COLUMN fec_modificacion datetime NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_claves_contables' AND COLUMN_NAME='fec_baja' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_contables ALTER COLUMN fec_baja datetime NULL

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_claves_contables' AND CONSTRAINT_NAME='PK_tbn1_ot_claves_contables')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_contables ADD CONSTRAINT PK_tbn1_ot_claves_contables PRIMARY KEY CLUSTERED (id_clave_contable)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_claves_contables' AND CONSTRAINT_NAME='FK_tbn1_ot_claves_contables_tbn1_ot_tipos_ingreso')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_contables ADD CONSTRAINT FK_tbn1_ot_claves_contables_tbn1_ot_tipos_ingreso FOREIGN KEY (id_tipo_ingreso) REFERENCES dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_ingreso(id_tipo_ingreso)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_claves_contables' AND CONSTRAINT_NAME='FK_tbn1_ot_claves_contables_tbn1_ot_claves_ingreso')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_contables ADD CONSTRAINT FK_tbn1_ot_claves_contables_tbn1_ot_claves_ingreso FOREIGN KEY (id_clave_ingreso) REFERENCES dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_ingreso(id_clave_ingreso)

GO

;WITH
query AS (
  SELECT 1 AS es_indefinido,'' AS anyo_contraido,1 AS id_tipo_ingreso,'' AS clave_ingreso,'Indefinido' AS descripcion
)
MERGE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_contables AS tbn1_ot_claves_contables
USING query ON query.es_indefinido=tbn1_ot_claves_contables.es_indefinido
WHEN MATCHED AND ((tbn1_ot_claves_contables.anyo_contraido<>query.anyo_contraido OR (tbn1_ot_claves_contables.anyo_contraido IS NULL AND query.anyo_contraido IS NOT NULL) OR  (tbn1_ot_claves_contables.anyo_contraido IS NOT NULL AND query.anyo_contraido IS NULL)
                  OR tbn1_ot_claves_contables.id_tipo_ingreso<>query.id_tipo_ingreso OR (tbn1_ot_claves_contables.id_tipo_ingreso IS NULL AND query.id_tipo_ingreso IS NOT NULL) OR  (tbn1_ot_claves_contables.id_tipo_ingreso IS NOT NULL AND query.id_tipo_ingreso IS NULL)
                  OR tbn1_ot_claves_contables.clave_ingreso<>query.clave_ingreso OR (tbn1_ot_claves_contables.clave_ingreso IS NULL AND query.clave_ingreso IS NOT NULL) OR  (tbn1_ot_claves_contables.clave_ingreso IS NOT NULL AND query.clave_ingreso IS NULL)
                  OR tbn1_ot_claves_contables.descripcion<>query.descripcion OR (tbn1_ot_claves_contables.descripcion IS NULL AND query.descripcion IS NOT NULL) OR  (tbn1_ot_claves_contables.descripcion IS NOT NULL AND query.descripcion IS NULL))) THEN
  UPDATE SET
    anyo_contraido=query.anyo_contraido,
    id_tipo_ingreso=query.id_tipo_ingreso,
    clave_ingreso=query.clave_ingreso,
    descripcion=query.descripcion
WHEN NOT MATCHED THEN
  INSERT (es_indefinido,anyo_contraido,id_tipo_ingreso,clave_ingreso,descripcion) VALUES (
    query.es_indefinido,
    query.anyo_contraido,
    query.id_tipo_ingreso,
    query.clave_ingreso,
    query.descripcion);
GO

USE dbn1_stg_dhyf_u
GO

IF EXISTS (SELECT 1 FROM dbn1_stg_dhyf_u.INFORMATION_SCHEMA.ROUTINES WHERE ROUTINE_SCHEMA='dbo' AND ROUTINE_NAME='spn1_cargar_normalizado_ot_claves_contables' AND ROUTINE_TYPE='PROCEDURE')
DROP PROCEDURE dbo.spn1_cargar_normalizado_ot_claves_contables;
GO

CREATE PROCEDURE dbo.spn1_cargar_normalizado_ot_claves_contables(@logpadre int) AS
BEGIN

  DECLARE @procedure_name varchar(100)='dbn1_stg_dhyf_u.dbo.spn1_cargar_normalizado_ot_claves_contables'
  SET NOCOUNT ON;
  DECLARE @log int;
  EXECUTE @log = dbn1_stg_dhyf_u.dbo.spn1_apuntar_log @logpadre,@procedure_name;
  DECLARE @fecha_ultima_carga datetime=dbn1_stg_dhyf_u.dbo.fnn1_fecha_ultima_carga(@log);
  DECLARE @continuar_en_caso_error bit=0;
  IF @logpadre IS NOT NULL AND EXISTS (SELECT 1 AS expr1
  FROM dbn1_norm_dhyf_u.audit.tbn1_procedimientos_excluidos
  WHERE
    'dbn1_stg_dhyf_u.dbo.'+procedimiento=@procedure_name
    AND excluido=1
  ) BEGIN
    UPDATE dbn1_norm_dhyf_u.audit.tbn1_logs SET
      mensaje_error='EXCLUÍDO'
    WHERE
      id_log=@log;
    RETURN
  END
     BEGIN TRY

  ;WITH
  query AS (
    SELECT
      anyo_contraido,
      tipo_ingreso,
      clave_ingreso,
      id_tipo_ingreso,
      id_clave_ingreso,
      descripcion,
      concepto,
      origen
    FROM
      (SELECT
         coalesce(maestro.anyo_contraido,movimientos.anyo_contraido) anyo_contraido,
         coalesce(maestro.tipo_ingreso,movimientos.tipo_ingreso) tipo_ingreso,
         coalesce(maestro.clave_ingreso,movimientos.clave_ingreso) clave_ingreso,
         coalesce(maestro.id_tipo_ingreso,movimientos.id_tipo_ingreso) id_tipo_ingreso,
         coalesce(maestro.id_clave_ingreso,movimientos.id_clave_ingreso) id_clave_ingreso,
         coalesce(maestro.descripcion,movimientos.descripcion) descripcion,
         coalesce(maestro.concepto,movimientos.concepto) concepto,
         coalesce(maestro.origen,movimientos.origen) origen
       FROM
           (SELECT
             right(clco.ccoejer,2) AS anyo_contraido,
             clco.ccoting AS tipo_ingreso,
             clco.ccoccon AS clave_ingreso,
             coalesce(tipo_ingreso.id_tipo_ingreso,indefinidos.id_tipo_ingreso) AS id_tipo_ingreso,
             coalesce(clave_ingreso.id_clave_ingreso,1) AS id_clave_ingreso,
             clco.ccodesc AS descripcion,
             CASE
                 WHEN clco.ccoccon='3920101' THEN 'RECARGO '
                 WHEN left(clco.ccoccon,5)='39202' THEN 'INTERESES'
                 ELSE 'CUOTA'
             END AS concepto,
             'MAESTRO' AS origen
           FROM dbn1_stg_dhyf_u.dbo.tbn1ccon_ti clco
           LEFT JOIN dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_ingreso tipo_ingreso ON (tipo_ingreso.tipo_ingreso=clco.ccoting)
           LEFT JOIN dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_ingreso clave_ingreso ON (clave_ingreso.cod_clave_ingreso=clco.ccoccon)
           CROSS JOIN dbn1_norm_dhyf_u.dbo.tbn1_indefinidos indefinidos
           WHERE
             clco.ccoenti='DF'
             AND clco.ccoejer<>'0000'
           GROUP BY
             right(clco.ccoejer,2),
             clco.ccoting,
             clco.ccoccon,
             coalesce(tipo_ingreso.id_tipo_ingreso,indefinidos.id_tipo_ingreso),
             coalesce(clave_ingreso.id_clave_ingreso,1),
             clco.ccodesc,
             CASE
                 WHEN clco.ccoccon='3920101' THEN 'RECARGO '
                 WHEN left(clco.ccoccon,5)='39202' THEN 'INTERESES'
                 ELSE 'CUOTA'
             END) maestro
       FULL JOIN
           (SELECT
             mov.conacont AS anyo_contraido,
             mov.contingr AS tipo_ingreso,
             mov.concingr AS clave_ingreso,
             coalesce(tipo_ingreso.id_tipo_ingreso,indefinidos.id_tipo_ingreso) AS id_tipo_ingreso,
             coalesce(clave_ingreso.id_clave_ingreso,1) AS id_clave_ingreso,
             'Clave contable faltante en Maestro' AS descripcion,
             CASE
                 WHEN mov.concingr='3920101' THEN 'RECARGO '
                 WHEN left(mov.concingr,5)='39202' THEN 'INTERESES'
                 ELSE 'CUOTA'
             END AS concepto,
             'S1CONT' AS origen
           FROM dbn1_stg_dhyf_u.dbo.tbn1cont_s1 mov
           LEFT JOIN dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_ingreso tipo_ingreso ON (tipo_ingreso.tipo_ingreso=mov.contingr)
           LEFT JOIN dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_ingreso clave_ingreso ON (clave_ingreso.cod_clave_ingreso=mov.concingr)
           CROSS JOIN dbn1_norm_dhyf_u.dbo.tbn1_indefinidos indefinidos
           GROUP BY
             mov.conacont,
             mov.contingr,
             mov.concingr,
             coalesce(tipo_ingreso.id_tipo_ingreso,indefinidos.id_tipo_ingreso),
             coalesce(clave_ingreso.id_clave_ingreso,1),
             CASE
                 WHEN mov.concingr='3920101' THEN 'RECARGO '
                 WHEN left(mov.concingr,5)='39202' THEN 'INTERESES'
                 ELSE 'CUOTA'
             END) AS movimientos ON (maestro.anyo_contraido=movimientos.anyo_contraido AND maestro.tipo_ingreso=movimientos.tipo_ingreso AND maestro.clave_ingreso=movimientos.clave_ingreso)) a
  )
  MERGE dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_contables AS tbn1_ot_claves_contables
  USING query ON query.anyo_contraido=tbn1_ot_claves_contables.anyo_contraido AND query.tipo_ingreso=tbn1_ot_claves_contables.tipo_ingreso AND query.clave_ingreso=tbn1_ot_claves_contables.clave_ingreso
  WHEN MATCHED AND ((tbn1_ot_claves_contables.id_tipo_ingreso<>query.id_tipo_ingreso OR (tbn1_ot_claves_contables.id_tipo_ingreso IS NULL AND query.id_tipo_ingreso IS NOT NULL) OR  (tbn1_ot_claves_contables.id_tipo_ingreso IS NOT NULL AND query.id_tipo_ingreso IS NULL)
                    OR tbn1_ot_claves_contables.id_clave_ingreso<>query.id_clave_ingreso OR (tbn1_ot_claves_contables.id_clave_ingreso IS NULL AND query.id_clave_ingreso IS NOT NULL) OR  (tbn1_ot_claves_contables.id_clave_ingreso IS NOT NULL AND query.id_clave_ingreso IS NULL)
                    OR tbn1_ot_claves_contables.descripcion<>query.descripcion OR (tbn1_ot_claves_contables.descripcion IS NULL AND query.descripcion IS NOT NULL) OR  (tbn1_ot_claves_contables.descripcion IS NOT NULL AND query.descripcion IS NULL)
                    OR tbn1_ot_claves_contables.concepto<>query.concepto OR (tbn1_ot_claves_contables.concepto IS NULL AND query.concepto IS NOT NULL) OR  (tbn1_ot_claves_contables.concepto IS NOT NULL AND query.concepto IS NULL)
                    OR tbn1_ot_claves_contables.origen<>query.origen OR (tbn1_ot_claves_contables.origen IS NULL AND query.origen IS NOT NULL) OR  (tbn1_ot_claves_contables.origen IS NOT NULL AND query.origen IS NULL)
                    OR (fec_baja IS NOT NULL))) THEN
    UPDATE SET
      id_tipo_ingreso=query.id_tipo_ingreso,
      id_clave_ingreso=query.id_clave_ingreso,
      descripcion=query.descripcion,
      concepto=query.concepto,
      origen=query.origen,
      fec_modificacion=getdate(),
      fec_baja=null
  WHEN NOT MATCHED THEN
    INSERT (anyo_contraido,tipo_ingreso,clave_ingreso,id_tipo_ingreso,id_clave_ingreso,descripcion,concepto,origen,fec_alta,fec_modificacion) VALUES (
      query.anyo_contraido,
      query.tipo_ingreso,
      query.clave_ingreso,
      query.id_tipo_ingreso,
      query.id_clave_ingreso,
      query.descripcion,
      query.concepto,
      query.origen,
      getdate(),
      getdate())
  WHEN NOT MATCHED BY SOURCE AND (fec_baja IS NULL) THEN
    UPDATE SET
      fec_baja=getdate(),
      fec_modificacion=getdate();

  EXECUTE dbn1_stg_dhyf_u.dbo.spn1_finalizar_log @log,@@ROWCOUNT;
   END TRY
  BEGIN CATCH
    EXECUTE dbn1_stg_dhyf_u.dbo.spn1_finalizar_log @log,null;
    UPDATE dbn1_norm_dhyf_u.audit.tbn1_logs SET
      mensaje_error=error_message(),
      procedimiento_error=error_procedure()
    WHERE
      id_log=@log;
    IF @continuar_en_caso_error=0 OR @logpadre IS NULL THROW
  END CATCH


END

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_grupos_subgrupos_subconceptos')
CREATE TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_grupos_subgrupos_subconceptos(
  id_grupo_subgrupo_subconcepto int IDENTITY(1,1),
  cod_grupo nvarchar(2) NOT NULL,
  cod_subgrupo nvarchar(5) NOT NULL,
  cod_subconcepto varchar(7) NOT NULL,
  des_grupo varchar(40) NOT NULL,
  des_subgrupo varchar(40) NOT NULL,
  des_subconcepto varchar(40) NOT NULL,
  peso decimal(5,4) NOT NULL,
  es_listado bit NOT NULL,
  es_ingreso_del_presupuesto bit NOT NULL,
  id_clave_ingreso int NULL,
  es_sancion bit NOT NULL,
  es_recargo bit NOT NULL,
  es_interes_demora bit NOT NULL,
  es_indefinido bit,
  fec_alta datetime,
  fec_modificacion datetime,
  fec_baja datetime,
  CONSTRAINT uk_grupo_subgrupo_subconcepto UNIQUE (cod_grupo,cod_subgrupo,cod_subconcepto),
  CONSTRAINT PK_tbn1_ot_grupos_subgrupos_subconceptos PRIMARY KEY CLUSTERED (id_grupo_subgrupo_subconcepto),
  CONSTRAINT FK_tbn1_ot_grupos_subgrupos_subconceptos_tbn1_ot_claves_ingreso FOREIGN KEY (id_clave_ingreso) REFERENCES dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_ingreso(id_clave_ingreso)
)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_grupos_subgrupos_subconceptos' AND COLUMN_NAME='id_grupo_subgrupo_subconcepto')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_grupos_subgrupos_subconceptos ADD id_grupo_subgrupo_subconcepto int

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_grupos_subgrupos_subconceptos' AND COLUMN_NAME='cod_grupo')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_grupos_subgrupos_subconceptos ADD cod_grupo nvarchar(2)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_grupos_subgrupos_subconceptos' AND COLUMN_NAME='cod_subgrupo')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_grupos_subgrupos_subconceptos ADD cod_subgrupo nvarchar(5)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_grupos_subgrupos_subconceptos' AND COLUMN_NAME='cod_subconcepto')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_grupos_subgrupos_subconceptos ADD cod_subconcepto varchar(7)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_grupos_subgrupos_subconceptos' AND COLUMN_NAME='des_grupo')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_grupos_subgrupos_subconceptos ADD des_grupo varchar(40)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_grupos_subgrupos_subconceptos' AND COLUMN_NAME='des_subgrupo')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_grupos_subgrupos_subconceptos ADD des_subgrupo varchar(40)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_grupos_subgrupos_subconceptos' AND COLUMN_NAME='des_subconcepto')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_grupos_subgrupos_subconceptos ADD des_subconcepto varchar(40)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_grupos_subgrupos_subconceptos' AND COLUMN_NAME='peso')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_grupos_subgrupos_subconceptos ADD peso decimal(5,4)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_grupos_subgrupos_subconceptos' AND COLUMN_NAME='es_listado')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_grupos_subgrupos_subconceptos ADD es_listado bit

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_grupos_subgrupos_subconceptos' AND COLUMN_NAME='es_ingreso_del_presupuesto')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_grupos_subgrupos_subconceptos ADD es_ingreso_del_presupuesto bit

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_grupos_subgrupos_subconceptos' AND COLUMN_NAME='id_clave_ingreso')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_grupos_subgrupos_subconceptos ADD id_clave_ingreso int

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_grupos_subgrupos_subconceptos' AND COLUMN_NAME='es_sancion')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_grupos_subgrupos_subconceptos ADD es_sancion bit

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_grupos_subgrupos_subconceptos' AND COLUMN_NAME='es_recargo')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_grupos_subgrupos_subconceptos ADD es_recargo bit

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_grupos_subgrupos_subconceptos' AND COLUMN_NAME='es_interes_demora')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_grupos_subgrupos_subconceptos ADD es_interes_demora bit

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_grupos_subgrupos_subconceptos' AND COLUMN_NAME='es_indefinido')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_grupos_subgrupos_subconceptos ADD es_indefinido bit

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_grupos_subgrupos_subconceptos' AND COLUMN_NAME='fec_alta')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_grupos_subgrupos_subconceptos ADD fec_alta datetime

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_grupos_subgrupos_subconceptos' AND COLUMN_NAME='fec_modificacion')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_grupos_subgrupos_subconceptos ADD fec_modificacion datetime

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_grupos_subgrupos_subconceptos' AND COLUMN_NAME='fec_baja')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_grupos_subgrupos_subconceptos ADD fec_baja datetime

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_grupos_subgrupos_subconceptos' AND COLUMN_NAME='es_listado' AND COLUMN_DEFAULT IS NULL)
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_grupos_subgrupos_subconceptos ADD CONSTRAINT DF_DBO_TBN1_OT_GRUPOS_SUBGRUPOS_SUBCONCEPTOS_ES_LISTADO DEFAULT 0 FOR es_listado

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_grupos_subgrupos_subconceptos' AND COLUMN_NAME='es_ingreso_del_presupuesto' AND COLUMN_DEFAULT IS NULL)
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_grupos_subgrupos_subconceptos ADD CONSTRAINT DF_DBO_TBN1_OT_GRUPOS_SUBGRUPOS_SUBCONCEPTOS_ES_INGRESO_DEL_PRESUPUESTO DEFAULT 0 FOR es_ingreso_del_presupuesto

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_grupos_subgrupos_subconceptos' AND COLUMN_NAME='es_sancion' AND COLUMN_DEFAULT IS NULL)
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_grupos_subgrupos_subconceptos ADD CONSTRAINT DF_DBO_TBN1_OT_GRUPOS_SUBGRUPOS_SUBCONCEPTOS_ES_SANCION DEFAULT 0 FOR es_sancion

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_grupos_subgrupos_subconceptos' AND COLUMN_NAME='es_recargo' AND COLUMN_DEFAULT IS NULL)
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_grupos_subgrupos_subconceptos ADD CONSTRAINT DF_DBO_TBN1_OT_GRUPOS_SUBGRUPOS_SUBCONCEPTOS_ES_RECARGO DEFAULT 0 FOR es_recargo

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_grupos_subgrupos_subconceptos' AND COLUMN_NAME='es_interes_demora' AND COLUMN_DEFAULT IS NULL)
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_grupos_subgrupos_subconceptos ADD CONSTRAINT DF_DBO_TBN1_OT_GRUPOS_SUBGRUPOS_SUBCONCEPTOS_ES_INTERES_DEMORA DEFAULT 0 FOR es_interes_demora

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_grupos_subgrupos_subconceptos' AND COLUMN_NAME='es_indefinido' AND COLUMN_DEFAULT IS NULL)
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_grupos_subgrupos_subconceptos ADD CONSTRAINT DF_DBO_TBN1_OT_GRUPOS_SUBGRUPOS_SUBCONCEPTOS_ES_INDEFINIDO DEFAULT 0 FOR es_indefinido

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_grupos_subgrupos_subconceptos' AND COLUMN_NAME='id_grupo_subgrupo_subconcepto' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_grupos_subgrupos_subconceptos ALTER COLUMN id_grupo_subgrupo_subconcepto int NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_grupos_subgrupos_subconceptos' AND COLUMN_NAME='cod_grupo' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_grupos_subgrupos_subconceptos ALTER COLUMN cod_grupo nvarchar(2) NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_grupos_subgrupos_subconceptos' AND COLUMN_NAME='cod_subgrupo' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_grupos_subgrupos_subconceptos ALTER COLUMN cod_subgrupo nvarchar(5) NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_grupos_subgrupos_subconceptos' AND COLUMN_NAME='cod_subconcepto' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_grupos_subgrupos_subconceptos ALTER COLUMN cod_subconcepto varchar(7) NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_grupos_subgrupos_subconceptos' AND COLUMN_NAME='des_grupo' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_grupos_subgrupos_subconceptos ALTER COLUMN des_grupo varchar(40) NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_grupos_subgrupos_subconceptos' AND COLUMN_NAME='des_subgrupo' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_grupos_subgrupos_subconceptos ALTER COLUMN des_subgrupo varchar(40) NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_grupos_subgrupos_subconceptos' AND COLUMN_NAME='des_subconcepto' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_grupos_subgrupos_subconceptos ALTER COLUMN des_subconcepto varchar(40) NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_grupos_subgrupos_subconceptos' AND COLUMN_NAME='peso' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_grupos_subgrupos_subconceptos ALTER COLUMN peso decimal(5,4) NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_grupos_subgrupos_subconceptos' AND COLUMN_NAME='es_listado' AND IS_NULLABLE='YES')
BEGIN
  UPDATE dbn1_norm_dhyf_u.dbo.tbn1_ot_grupos_subgrupos_subconceptos SET es_listado=0 WHERE es_listado IS NULL
  ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_grupos_subgrupos_subconceptos ALTER COLUMN es_listado bit NOT NULL
END

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_grupos_subgrupos_subconceptos' AND COLUMN_NAME='es_ingreso_del_presupuesto' AND IS_NULLABLE='YES')
BEGIN
  UPDATE dbn1_norm_dhyf_u.dbo.tbn1_ot_grupos_subgrupos_subconceptos SET es_ingreso_del_presupuesto=0 WHERE es_ingreso_del_presupuesto IS NULL
  ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_grupos_subgrupos_subconceptos ALTER COLUMN es_ingreso_del_presupuesto bit NOT NULL
END

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_grupos_subgrupos_subconceptos' AND COLUMN_NAME='id_clave_ingreso' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_grupos_subgrupos_subconceptos ALTER COLUMN id_clave_ingreso int NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_grupos_subgrupos_subconceptos' AND COLUMN_NAME='es_sancion' AND IS_NULLABLE='YES')
BEGIN
  UPDATE dbn1_norm_dhyf_u.dbo.tbn1_ot_grupos_subgrupos_subconceptos SET es_sancion=0 WHERE es_sancion IS NULL
  ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_grupos_subgrupos_subconceptos ALTER COLUMN es_sancion bit NOT NULL
END

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_grupos_subgrupos_subconceptos' AND COLUMN_NAME='es_recargo' AND IS_NULLABLE='YES')
BEGIN
  UPDATE dbn1_norm_dhyf_u.dbo.tbn1_ot_grupos_subgrupos_subconceptos SET es_recargo=0 WHERE es_recargo IS NULL
  ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_grupos_subgrupos_subconceptos ALTER COLUMN es_recargo bit NOT NULL
END

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_grupos_subgrupos_subconceptos' AND COLUMN_NAME='es_interes_demora' AND IS_NULLABLE='YES')
BEGIN
  UPDATE dbn1_norm_dhyf_u.dbo.tbn1_ot_grupos_subgrupos_subconceptos SET es_interes_demora=0 WHERE es_interes_demora IS NULL
  ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_grupos_subgrupos_subconceptos ALTER COLUMN es_interes_demora bit NOT NULL
END

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_grupos_subgrupos_subconceptos' AND COLUMN_NAME='es_indefinido' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_grupos_subgrupos_subconceptos ALTER COLUMN es_indefinido bit NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_grupos_subgrupos_subconceptos' AND COLUMN_NAME='fec_alta' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_grupos_subgrupos_subconceptos ALTER COLUMN fec_alta datetime NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_grupos_subgrupos_subconceptos' AND COLUMN_NAME='fec_modificacion' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_grupos_subgrupos_subconceptos ALTER COLUMN fec_modificacion datetime NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_grupos_subgrupos_subconceptos' AND COLUMN_NAME='fec_baja' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_grupos_subgrupos_subconceptos ALTER COLUMN fec_baja datetime NULL

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_grupos_subgrupos_subconceptos' AND CONSTRAINT_NAME='PK_tbn1_ot_grupos_subgrupos_subconceptos')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_grupos_subgrupos_subconceptos ADD CONSTRAINT PK_tbn1_ot_grupos_subgrupos_subconceptos PRIMARY KEY CLUSTERED (id_grupo_subgrupo_subconcepto)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_grupos_subgrupos_subconceptos' AND CONSTRAINT_NAME='FK_tbn1_ot_grupos_subgrupos_subconceptos_tbn1_ot_claves_ingreso')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_grupos_subgrupos_subconceptos ADD CONSTRAINT FK_tbn1_ot_grupos_subgrupos_subconceptos_tbn1_ot_claves_ingreso FOREIGN KEY (id_clave_ingreso) REFERENCES dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_ingreso(id_clave_ingreso)

GO

;WITH
query AS (
  SELECT 1 AS es_indefinido,'' AS cod_grupo,'' AS cod_subgrupo,'' AS cod_subconcepto,'Indefinido' AS des_grupo,'Indefinido' AS des_subgrupo,'Indefinido' AS des_subconcepto,1 AS peso
)
MERGE dbn1_norm_dhyf_u.dbo.tbn1_ot_grupos_subgrupos_subconceptos AS tbn1_ot_grupos_subgrupos_subconceptos
USING query ON query.es_indefinido=tbn1_ot_grupos_subgrupos_subconceptos.es_indefinido
WHEN MATCHED AND ((tbn1_ot_grupos_subgrupos_subconceptos.cod_grupo<>query.cod_grupo OR (tbn1_ot_grupos_subgrupos_subconceptos.cod_grupo IS NULL AND query.cod_grupo IS NOT NULL) OR  (tbn1_ot_grupos_subgrupos_subconceptos.cod_grupo IS NOT NULL AND query.cod_grupo IS NULL)
                  OR tbn1_ot_grupos_subgrupos_subconceptos.cod_subgrupo<>query.cod_subgrupo OR (tbn1_ot_grupos_subgrupos_subconceptos.cod_subgrupo IS NULL AND query.cod_subgrupo IS NOT NULL) OR  (tbn1_ot_grupos_subgrupos_subconceptos.cod_subgrupo IS NOT NULL AND query.cod_subgrupo IS NULL)
                  OR tbn1_ot_grupos_subgrupos_subconceptos.cod_subconcepto<>query.cod_subconcepto OR (tbn1_ot_grupos_subgrupos_subconceptos.cod_subconcepto IS NULL AND query.cod_subconcepto IS NOT NULL) OR  (tbn1_ot_grupos_subgrupos_subconceptos.cod_subconcepto IS NOT NULL AND query.cod_subconcepto IS NULL)
                  OR tbn1_ot_grupos_subgrupos_subconceptos.des_grupo<>query.des_grupo OR (tbn1_ot_grupos_subgrupos_subconceptos.des_grupo IS NULL AND query.des_grupo IS NOT NULL) OR  (tbn1_ot_grupos_subgrupos_subconceptos.des_grupo IS NOT NULL AND query.des_grupo IS NULL)
                  OR tbn1_ot_grupos_subgrupos_subconceptos.des_subgrupo<>query.des_subgrupo OR (tbn1_ot_grupos_subgrupos_subconceptos.des_subgrupo IS NULL AND query.des_subgrupo IS NOT NULL) OR  (tbn1_ot_grupos_subgrupos_subconceptos.des_subgrupo IS NOT NULL AND query.des_subgrupo IS NULL)
                  OR tbn1_ot_grupos_subgrupos_subconceptos.des_subconcepto<>query.des_subconcepto OR (tbn1_ot_grupos_subgrupos_subconceptos.des_subconcepto IS NULL AND query.des_subconcepto IS NOT NULL) OR  (tbn1_ot_grupos_subgrupos_subconceptos.des_subconcepto IS NOT NULL AND query.des_subconcepto IS NULL)
                  OR tbn1_ot_grupos_subgrupos_subconceptos.peso<>query.peso OR (tbn1_ot_grupos_subgrupos_subconceptos.peso IS NULL AND query.peso IS NOT NULL) OR  (tbn1_ot_grupos_subgrupos_subconceptos.peso IS NOT NULL AND query.peso IS NULL))) THEN
  UPDATE SET
    cod_grupo=query.cod_grupo,
    cod_subgrupo=query.cod_subgrupo,
    cod_subconcepto=query.cod_subconcepto,
    des_grupo=query.des_grupo,
    des_subgrupo=query.des_subgrupo,
    des_subconcepto=query.des_subconcepto,
    peso=query.peso
WHEN NOT MATCHED THEN
  INSERT (es_indefinido,cod_grupo,cod_subgrupo,cod_subconcepto,des_grupo,des_subgrupo,des_subconcepto,peso) VALUES (
    query.es_indefinido,
    query.cod_grupo,
    query.cod_subgrupo,
    query.cod_subconcepto,
    query.des_grupo,
    query.des_subgrupo,
    query.des_subconcepto,
    query.peso);
GO

USE dbn1_stg_dhyf_u
GO

IF EXISTS (SELECT 1 FROM dbn1_stg_dhyf_u.INFORMATION_SCHEMA.ROUTINES WHERE ROUTINE_SCHEMA='dbo' AND ROUTINE_NAME='spn1_cargar_normalizado_ot_grupos_subgrupos_subconceptos_lista' AND ROUTINE_TYPE='PROCEDURE')
DROP PROCEDURE dbo.spn1_cargar_normalizado_ot_grupos_subgrupos_subconceptos_lista;
GO

CREATE PROCEDURE dbo.spn1_cargar_normalizado_ot_grupos_subgrupos_subconceptos_lista(@logpadre int) AS
BEGIN

  DECLARE @procedure_name varchar(100)='dbn1_stg_dhyf_u.dbo.spn1_cargar_normalizado_ot_grupos_subgrupos_subconceptos_lista'
  SET NOCOUNT ON;
  DECLARE @log int;
  EXECUTE @log = dbn1_stg_dhyf_u.dbo.spn1_apuntar_log @logpadre,@procedure_name;
  DECLARE @fecha_ultima_carga datetime=dbn1_stg_dhyf_u.dbo.fnn1_fecha_ultima_carga(@log);
  DECLARE @continuar_en_caso_error bit=0;
  IF @logpadre IS NOT NULL AND EXISTS (SELECT 1 AS expr1
  FROM dbn1_norm_dhyf_u.audit.tbn1_procedimientos_excluidos
  WHERE
    'dbn1_stg_dhyf_u.dbo.'+procedimiento=@procedure_name
    AND excluido=1
  ) BEGIN
    UPDATE dbn1_norm_dhyf_u.audit.tbn1_logs SET
      mensaje_error='EXCLUÍDO'
    WHERE
      id_log=@log;
    RETURN
  END
     BEGIN TRY

  ;WITH
  query AS (
    SELECT
      substring(clave.auxi_re13_clave,14,2) AS cod_grupo,
      substring(clave.auxi_re13_clave,14,2)+substring(clave.auxi_re13_clave,16,3) AS cod_subgrupo,
      substring(clave.auxi_re13_clave,19,7) AS cod_subconcepto,
      clave_ingreso.id_clave_ingreso AS id_clave_ingreso,
      grupo.auxi_re11_descrg AS des_grupo,
      subgrupo.auxi_re12_descrg AS des_subgrupo,
      coalesce(clave_ingreso.clave_ingreso,'') AS des_subconcepto,
      clave.auxi_re13_porc/100 AS peso,
      1 AS es_listado,
      coalesce(clave_ingreso.es_ingreso_del_presupuesto,0) AS es_ingreso_del_presupuesto,
      CASE WHEN upper(subgrupo.auxi_re12_descrg) LIKE '%SANCIONES%' THEN 1 ELSE 0 END AS es_sancion,
      CASE WHEN upper(subgrupo.auxi_re12_descrg) LIKE '%RECARGOS%' THEN 1 ELSE 0 END AS es_recargo,
      CASE WHEN upper(subgrupo.auxi_re12_descrg) LIKE '%INTERESES DE DEMORA%' THEN 1 ELSE 0 END AS es_interes_demora
    FROM dbn1_stg_dhyf_u.dbo.tbn1auxi_s7_r13 clave
    LEFT JOIN dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_ingreso clave_ingreso ON (clave_ingreso.cod_clave_ingreso=substring(clave.auxi_re13_clave,19,7))
    INNER JOIN dbn1_stg_dhyf_u.dbo.tbn1auxi_s7_r12 subgrupo ON (right(subgrupo.auxi_re12_clave,5)=substring(clave.auxi_re13_clave,14,5))
    INNER JOIN dbn1_stg_dhyf_u.dbo.tbn1auxi_s7_r11 grupo ON (right(grupo.auxi_re11_clave,2)=substring(clave.auxi_re13_clave,14,2))
  )
  MERGE dbn1_norm_dhyf_u.dbo.tbn1_ot_grupos_subgrupos_subconceptos AS tbn1_ot_grupos_subgrupos_subconceptos
  USING query ON query.cod_grupo=tbn1_ot_grupos_subgrupos_subconceptos.cod_grupo AND query.cod_subgrupo=tbn1_ot_grupos_subgrupos_subconceptos.cod_subgrupo AND query.cod_subconcepto=tbn1_ot_grupos_subgrupos_subconceptos.cod_subconcepto
  WHEN MATCHED AND (tbn1_ot_grupos_subgrupos_subconceptos.es_listado=1 AND tbn1_ot_grupos_subgrupos_subconceptos.es_indefinido=0
                    AND (tbn1_ot_grupos_subgrupos_subconceptos.id_clave_ingreso<>query.id_clave_ingreso OR (tbn1_ot_grupos_subgrupos_subconceptos.id_clave_ingreso IS NULL AND query.id_clave_ingreso IS NOT NULL) OR  (tbn1_ot_grupos_subgrupos_subconceptos.id_clave_ingreso IS NOT NULL AND query.id_clave_ingreso IS NULL)
                    OR tbn1_ot_grupos_subgrupos_subconceptos.des_grupo<>query.des_grupo OR (tbn1_ot_grupos_subgrupos_subconceptos.des_grupo IS NULL AND query.des_grupo IS NOT NULL) OR  (tbn1_ot_grupos_subgrupos_subconceptos.des_grupo IS NOT NULL AND query.des_grupo IS NULL)
                    OR tbn1_ot_grupos_subgrupos_subconceptos.des_subgrupo<>query.des_subgrupo OR (tbn1_ot_grupos_subgrupos_subconceptos.des_subgrupo IS NULL AND query.des_subgrupo IS NOT NULL) OR  (tbn1_ot_grupos_subgrupos_subconceptos.des_subgrupo IS NOT NULL AND query.des_subgrupo IS NULL)
                    OR tbn1_ot_grupos_subgrupos_subconceptos.des_subconcepto<>query.des_subconcepto OR (tbn1_ot_grupos_subgrupos_subconceptos.des_subconcepto IS NULL AND query.des_subconcepto IS NOT NULL) OR  (tbn1_ot_grupos_subgrupos_subconceptos.des_subconcepto IS NOT NULL AND query.des_subconcepto IS NULL)
                    OR tbn1_ot_grupos_subgrupos_subconceptos.peso<>query.peso OR (tbn1_ot_grupos_subgrupos_subconceptos.peso IS NULL AND query.peso IS NOT NULL) OR  (tbn1_ot_grupos_subgrupos_subconceptos.peso IS NOT NULL AND query.peso IS NULL)
                    OR tbn1_ot_grupos_subgrupos_subconceptos.es_listado<>query.es_listado OR (tbn1_ot_grupos_subgrupos_subconceptos.es_listado IS NULL AND query.es_listado IS NOT NULL) OR  (tbn1_ot_grupos_subgrupos_subconceptos.es_listado IS NOT NULL AND query.es_listado IS NULL)
                    OR tbn1_ot_grupos_subgrupos_subconceptos.es_ingreso_del_presupuesto<>query.es_ingreso_del_presupuesto OR (tbn1_ot_grupos_subgrupos_subconceptos.es_ingreso_del_presupuesto IS NULL AND query.es_ingreso_del_presupuesto IS NOT NULL) OR  (tbn1_ot_grupos_subgrupos_subconceptos.es_ingreso_del_presupuesto IS NOT NULL AND query.es_ingreso_del_presupuesto IS NULL)
                    OR tbn1_ot_grupos_subgrupos_subconceptos.es_sancion<>query.es_sancion OR (tbn1_ot_grupos_subgrupos_subconceptos.es_sancion IS NULL AND query.es_sancion IS NOT NULL) OR  (tbn1_ot_grupos_subgrupos_subconceptos.es_sancion IS NOT NULL AND query.es_sancion IS NULL)
                    OR tbn1_ot_grupos_subgrupos_subconceptos.es_recargo<>query.es_recargo OR (tbn1_ot_grupos_subgrupos_subconceptos.es_recargo IS NULL AND query.es_recargo IS NOT NULL) OR  (tbn1_ot_grupos_subgrupos_subconceptos.es_recargo IS NOT NULL AND query.es_recargo IS NULL)
                    OR tbn1_ot_grupos_subgrupos_subconceptos.es_interes_demora<>query.es_interes_demora OR (tbn1_ot_grupos_subgrupos_subconceptos.es_interes_demora IS NULL AND query.es_interes_demora IS NOT NULL) OR  (tbn1_ot_grupos_subgrupos_subconceptos.es_interes_demora IS NOT NULL AND query.es_interes_demora IS NULL)
                    OR (fec_baja IS NOT NULL))) THEN
    UPDATE SET
      id_clave_ingreso=query.id_clave_ingreso,
      des_grupo=query.des_grupo,
      des_subgrupo=query.des_subgrupo,
      des_subconcepto=query.des_subconcepto,
      peso=query.peso,
      es_listado=query.es_listado,
      es_ingreso_del_presupuesto=query.es_ingreso_del_presupuesto,
      es_sancion=query.es_sancion,
      es_recargo=query.es_recargo,
      es_interes_demora=query.es_interes_demora,
      fec_modificacion=getdate(),
      fec_baja=null
  WHEN NOT MATCHED THEN
    INSERT (cod_grupo,cod_subgrupo,cod_subconcepto,id_clave_ingreso,des_grupo,des_subgrupo,des_subconcepto,peso,es_listado,es_ingreso_del_presupuesto,es_sancion,es_recargo,es_interes_demora,fec_alta,fec_modificacion) VALUES (
      query.cod_grupo,
      query.cod_subgrupo,
      query.cod_subconcepto,
      query.id_clave_ingreso,
      query.des_grupo,
      query.des_subgrupo,
      query.des_subconcepto,
      query.peso,
      query.es_listado,
      query.es_ingreso_del_presupuesto,
      query.es_sancion,
      query.es_recargo,
      query.es_interes_demora,
      getdate(),
      getdate())
  WHEN NOT MATCHED BY SOURCE AND (tbn1_ot_grupos_subgrupos_subconceptos.es_listado=1 AND tbn1_ot_grupos_subgrupos_subconceptos.es_indefinido=0
                                  AND fec_baja IS NULL) THEN
    UPDATE SET
      fec_baja=getdate(),
      fec_modificacion=getdate();

  EXECUTE dbn1_stg_dhyf_u.dbo.spn1_finalizar_log @log,@@ROWCOUNT;
   END TRY
  BEGIN CATCH
    EXECUTE dbn1_stg_dhyf_u.dbo.spn1_finalizar_log @log,null;
    UPDATE dbn1_norm_dhyf_u.audit.tbn1_logs SET
      mensaje_error=error_message(),
      procedimiento_error=error_procedure()
    WHERE
      id_log=@log;
    IF @continuar_en_caso_error=0 OR @logpadre IS NULL THROW
  END CATCH


END

GO

USE dbn1_stg_dhyf_u
GO

IF EXISTS (SELECT 1 FROM dbn1_stg_dhyf_u.INFORMATION_SCHEMA.ROUTINES WHERE ROUTINE_SCHEMA='dbo' AND ROUTINE_NAME='spn1_cargar_normalizado_ot_grupos_subgrupos_subconceptos_no_lista' AND ROUTINE_TYPE='PROCEDURE')
DROP PROCEDURE dbo.spn1_cargar_normalizado_ot_grupos_subgrupos_subconceptos_no_lista;
GO

CREATE PROCEDURE dbo.spn1_cargar_normalizado_ot_grupos_subgrupos_subconceptos_no_lista(@logpadre int) AS
BEGIN

  DECLARE @procedure_name varchar(100)='dbn1_stg_dhyf_u.dbo.spn1_cargar_normalizado_ot_grupos_subgrupos_subconceptos_no_lista'
  SET NOCOUNT ON;
  DECLARE @log int;
  EXECUTE @log = dbn1_stg_dhyf_u.dbo.spn1_apuntar_log @logpadre,@procedure_name;
  DECLARE @fecha_ultima_carga datetime=dbn1_stg_dhyf_u.dbo.fnn1_fecha_ultima_carga(@log);
  DECLARE @continuar_en_caso_error bit=0;
  IF @logpadre IS NOT NULL AND EXISTS (SELECT 1 AS expr1
  FROM dbn1_norm_dhyf_u.audit.tbn1_procedimientos_excluidos
  WHERE
    'dbn1_stg_dhyf_u.dbo.'+procedimiento=@procedure_name
    AND excluido=1
  ) BEGIN
    UPDATE dbn1_norm_dhyf_u.audit.tbn1_logs SET
      mensaje_error='EXCLUÍDO'
    WHERE
      id_log=@log;
    RETURN
  END
     BEGIN TRY

  ;WITH
  query AS (
    SELECT
      '' AS cod_grupo,
      '' AS cod_subgrupo,
      clave_ingreso.cod_clave_ingreso AS cod_subconcepto,
      clave_ingreso.id_clave_ingreso AS id_clave_ingreso,
      'Indefinido' AS des_grupo,
      'Indefinido' AS des_subgrupo,
      clave_ingreso.clave_ingreso AS des_subconcepto,
      1 AS peso,
      0 AS es_listado,
      clave_ingreso.es_ingreso_del_presupuesto AS es_ingreso_del_presupuesto
    FROM dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_ingreso clave_ingreso
    LEFT JOIN dbn1_stg_dhyf_u.dbo.tbn1auxi_s7_r13 clave ON (substring(clave.auxi_re13_clave,19,7)=clave_ingreso.cod_clave_ingreso)
    WHERE clave.auxi_re13_clave IS NULL
    GROUP BY
      clave_ingreso.cod_clave_ingreso,
      clave_ingreso.id_clave_ingreso,
      clave_ingreso.clave_ingreso,
      clave_ingreso.es_ingreso_del_presupuesto
  )
  MERGE dbn1_norm_dhyf_u.dbo.tbn1_ot_grupos_subgrupos_subconceptos AS tbn1_ot_grupos_subgrupos_subconceptos
  USING query ON query.cod_grupo=tbn1_ot_grupos_subgrupos_subconceptos.cod_grupo AND query.cod_subgrupo=tbn1_ot_grupos_subgrupos_subconceptos.cod_subgrupo AND query.cod_subconcepto=tbn1_ot_grupos_subgrupos_subconceptos.cod_subconcepto
  WHEN MATCHED AND (tbn1_ot_grupos_subgrupos_subconceptos.es_listado=0 AND tbn1_ot_grupos_subgrupos_subconceptos.es_indefinido=0
                    AND (tbn1_ot_grupos_subgrupos_subconceptos.id_clave_ingreso<>query.id_clave_ingreso OR (tbn1_ot_grupos_subgrupos_subconceptos.id_clave_ingreso IS NULL AND query.id_clave_ingreso IS NOT NULL) OR  (tbn1_ot_grupos_subgrupos_subconceptos.id_clave_ingreso IS NOT NULL AND query.id_clave_ingreso IS NULL)
                    OR tbn1_ot_grupos_subgrupos_subconceptos.des_grupo<>query.des_grupo OR (tbn1_ot_grupos_subgrupos_subconceptos.des_grupo IS NULL AND query.des_grupo IS NOT NULL) OR  (tbn1_ot_grupos_subgrupos_subconceptos.des_grupo IS NOT NULL AND query.des_grupo IS NULL)
                    OR tbn1_ot_grupos_subgrupos_subconceptos.des_subgrupo<>query.des_subgrupo OR (tbn1_ot_grupos_subgrupos_subconceptos.des_subgrupo IS NULL AND query.des_subgrupo IS NOT NULL) OR  (tbn1_ot_grupos_subgrupos_subconceptos.des_subgrupo IS NOT NULL AND query.des_subgrupo IS NULL)
                    OR tbn1_ot_grupos_subgrupos_subconceptos.des_subconcepto<>query.des_subconcepto OR (tbn1_ot_grupos_subgrupos_subconceptos.des_subconcepto IS NULL AND query.des_subconcepto IS NOT NULL) OR  (tbn1_ot_grupos_subgrupos_subconceptos.des_subconcepto IS NOT NULL AND query.des_subconcepto IS NULL)
                    OR tbn1_ot_grupos_subgrupos_subconceptos.peso<>query.peso OR (tbn1_ot_grupos_subgrupos_subconceptos.peso IS NULL AND query.peso IS NOT NULL) OR  (tbn1_ot_grupos_subgrupos_subconceptos.peso IS NOT NULL AND query.peso IS NULL)
                    OR tbn1_ot_grupos_subgrupos_subconceptos.es_listado<>query.es_listado OR (tbn1_ot_grupos_subgrupos_subconceptos.es_listado IS NULL AND query.es_listado IS NOT NULL) OR  (tbn1_ot_grupos_subgrupos_subconceptos.es_listado IS NOT NULL AND query.es_listado IS NULL)
                    OR tbn1_ot_grupos_subgrupos_subconceptos.es_ingreso_del_presupuesto<>query.es_ingreso_del_presupuesto OR (tbn1_ot_grupos_subgrupos_subconceptos.es_ingreso_del_presupuesto IS NULL AND query.es_ingreso_del_presupuesto IS NOT NULL) OR  (tbn1_ot_grupos_subgrupos_subconceptos.es_ingreso_del_presupuesto IS NOT NULL AND query.es_ingreso_del_presupuesto IS NULL)
                    OR (fec_baja IS NOT NULL))) THEN
    UPDATE SET
      id_clave_ingreso=query.id_clave_ingreso,
      des_grupo=query.des_grupo,
      des_subgrupo=query.des_subgrupo,
      des_subconcepto=query.des_subconcepto,
      peso=query.peso,
      es_listado=query.es_listado,
      es_ingreso_del_presupuesto=query.es_ingreso_del_presupuesto,
      fec_modificacion=getdate(),
      fec_baja=null
  WHEN NOT MATCHED THEN
    INSERT (cod_grupo,cod_subgrupo,cod_subconcepto,id_clave_ingreso,des_grupo,des_subgrupo,des_subconcepto,peso,es_listado,es_ingreso_del_presupuesto,fec_alta,fec_modificacion) VALUES (
      query.cod_grupo,
      query.cod_subgrupo,
      query.cod_subconcepto,
      query.id_clave_ingreso,
      query.des_grupo,
      query.des_subgrupo,
      query.des_subconcepto,
      query.peso,
      query.es_listado,
      query.es_ingreso_del_presupuesto,
      getdate(),
      getdate())
  WHEN NOT MATCHED BY SOURCE AND (tbn1_ot_grupos_subgrupos_subconceptos.es_listado=0 AND tbn1_ot_grupos_subgrupos_subconceptos.es_indefinido=0
                                  AND fec_baja IS NULL) THEN
    UPDATE SET
      fec_baja=getdate(),
      fec_modificacion=getdate();

  EXECUTE dbn1_stg_dhyf_u.dbo.spn1_finalizar_log @log,@@ROWCOUNT;
   END TRY
  BEGIN CATCH
    EXECUTE dbn1_stg_dhyf_u.dbo.spn1_finalizar_log @log,null;
    UPDATE dbn1_norm_dhyf_u.audit.tbn1_logs SET
      mensaje_error=error_message(),
      procedimiento_error=error_procedure()
    WHERE
      id_log=@log;
    IF @continuar_en_caso_error=0 OR @logpadre IS NULL THROW
  END CATCH


END

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_modos_ingreso')
CREATE TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_modos_ingreso(
  id_modo_ingreso int IDENTITY(1,1),
  modo_ingreso varchar(2) NOT NULL,
  des_modo_ingreso varchar(50) NOT NULL,
  es_indefinido bit,
  fec_alta datetime,
  fec_modificacion datetime,
  fec_baja datetime,
  CONSTRAINT uk_ot_modos_ingreso UNIQUE (modo_ingreso),
  CONSTRAINT PK_tbn1_ot_modos_ingreso PRIMARY KEY CLUSTERED (id_modo_ingreso)
)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_modos_ingreso' AND COLUMN_NAME='id_modo_ingreso')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_modos_ingreso ADD id_modo_ingreso int

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_modos_ingreso' AND COLUMN_NAME='modo_ingreso')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_modos_ingreso ADD modo_ingreso varchar(2)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_modos_ingreso' AND COLUMN_NAME='des_modo_ingreso')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_modos_ingreso ADD des_modo_ingreso varchar(50)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_modos_ingreso' AND COLUMN_NAME='es_indefinido')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_modos_ingreso ADD es_indefinido bit

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_modos_ingreso' AND COLUMN_NAME='fec_alta')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_modos_ingreso ADD fec_alta datetime

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_modos_ingreso' AND COLUMN_NAME='fec_modificacion')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_modos_ingreso ADD fec_modificacion datetime

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_modos_ingreso' AND COLUMN_NAME='fec_baja')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_modos_ingreso ADD fec_baja datetime

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_modos_ingreso' AND COLUMN_NAME='es_indefinido' AND COLUMN_DEFAULT IS NULL)
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_modos_ingreso ADD CONSTRAINT DF_DBO_TBN1_OT_MODOS_INGRESO_ES_INDEFINIDO DEFAULT 0 FOR es_indefinido

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_modos_ingreso' AND COLUMN_NAME='id_modo_ingreso' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_modos_ingreso ALTER COLUMN id_modo_ingreso int NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_modos_ingreso' AND COLUMN_NAME='modo_ingreso' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_modos_ingreso ALTER COLUMN modo_ingreso varchar(2) NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_modos_ingreso' AND COLUMN_NAME='des_modo_ingreso' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_modos_ingreso ALTER COLUMN des_modo_ingreso varchar(50) NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_modos_ingreso' AND COLUMN_NAME='es_indefinido' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_modos_ingreso ALTER COLUMN es_indefinido bit NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_modos_ingreso' AND COLUMN_NAME='fec_alta' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_modos_ingreso ALTER COLUMN fec_alta datetime NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_modos_ingreso' AND COLUMN_NAME='fec_modificacion' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_modos_ingreso ALTER COLUMN fec_modificacion datetime NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_modos_ingreso' AND COLUMN_NAME='fec_baja' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_modos_ingreso ALTER COLUMN fec_baja datetime NULL

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_modos_ingreso' AND CONSTRAINT_NAME='PK_tbn1_ot_modos_ingreso')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_modos_ingreso ADD CONSTRAINT PK_tbn1_ot_modos_ingreso PRIMARY KEY CLUSTERED (id_modo_ingreso)

GO

;WITH
query AS (
  SELECT 1 AS es_indefinido,'ZZ' AS modo_ingreso,'Indefinido' AS des_modo_ingreso
)
MERGE dbn1_norm_dhyf_u.dbo.tbn1_ot_modos_ingreso AS tbn1_ot_modos_ingreso
USING query ON query.es_indefinido=tbn1_ot_modos_ingreso.es_indefinido
WHEN MATCHED AND ((tbn1_ot_modos_ingreso.modo_ingreso<>query.modo_ingreso OR (tbn1_ot_modos_ingreso.modo_ingreso IS NULL AND query.modo_ingreso IS NOT NULL) OR  (tbn1_ot_modos_ingreso.modo_ingreso IS NOT NULL AND query.modo_ingreso IS NULL)
                  OR tbn1_ot_modos_ingreso.des_modo_ingreso<>query.des_modo_ingreso OR (tbn1_ot_modos_ingreso.des_modo_ingreso IS NULL AND query.des_modo_ingreso IS NOT NULL) OR  (tbn1_ot_modos_ingreso.des_modo_ingreso IS NOT NULL AND query.des_modo_ingreso IS NULL))) THEN
  UPDATE SET
    modo_ingreso=query.modo_ingreso,
    des_modo_ingreso=query.des_modo_ingreso
WHEN NOT MATCHED THEN
  INSERT (es_indefinido,modo_ingreso,des_modo_ingreso) VALUES (
    query.es_indefinido,
    query.modo_ingreso,
    query.des_modo_ingreso);
GO

USE dbn1_stg_dhyf_u
GO

IF EXISTS (SELECT 1 FROM dbn1_stg_dhyf_u.INFORMATION_SCHEMA.ROUTINES WHERE ROUTINE_SCHEMA='dbo' AND ROUTINE_NAME='spn1_cargar_normalizado_ot_modos_ingreso' AND ROUTINE_TYPE='PROCEDURE')
DROP PROCEDURE dbo.spn1_cargar_normalizado_ot_modos_ingreso;
GO

CREATE PROCEDURE dbo.spn1_cargar_normalizado_ot_modos_ingreso(@logpadre int) AS
BEGIN

  DECLARE @procedure_name varchar(100)='dbn1_stg_dhyf_u.dbo.spn1_cargar_normalizado_ot_modos_ingreso'
  SET NOCOUNT ON;
  DECLARE @log int;
  EXECUTE @log = dbn1_stg_dhyf_u.dbo.spn1_apuntar_log @logpadre,@procedure_name;
  DECLARE @fecha_ultima_carga datetime=dbn1_stg_dhyf_u.dbo.fnn1_fecha_ultima_carga(@log);
  DECLARE @continuar_en_caso_error bit=0;
  IF @logpadre IS NOT NULL AND EXISTS (SELECT 1 AS expr1
  FROM dbn1_norm_dhyf_u.audit.tbn1_procedimientos_excluidos
  WHERE
    'dbn1_stg_dhyf_u.dbo.'+procedimiento=@procedure_name
    AND excluido=1
  ) BEGIN
    UPDATE dbn1_norm_dhyf_u.audit.tbn1_logs SET
      mensaje_error='EXCLUÍDO'
    WHERE
      id_log=@log;
    RETURN
  END
     BEGIN TRY

  ;WITH
  query AS (
    SELECT
      right('0'+CAST(ming.modo_ingreso AS varchar),2) AS modo_ingreso,
      ming.des_modo_ingreso AS des_modo_ingreso
    FROM
      (SELECT 0 modo_ingreso,'Voluntario' des_modo_ingreso
       UNION ALL SELECT 1,'Forzoso compensación'
       UNION ALL SELECT 2,'Forzoso embargo'
       UNION ALL SELECT 8,'Remesas (voluntario)'
       UNION ALL SELECT 9,'Relacionado. No ingreso'
       UNION ALL SELECT 10,'Rectificado completo. No ingreso') ming
  )
  MERGE dbn1_norm_dhyf_u.dbo.tbn1_ot_modos_ingreso AS tbn1_ot_modos_ingreso
  USING query ON query.modo_ingreso=tbn1_ot_modos_ingreso.modo_ingreso
  WHEN MATCHED AND (tbn1_ot_modos_ingreso.es_indefinido=0
                    AND (tbn1_ot_modos_ingreso.des_modo_ingreso<>query.des_modo_ingreso OR (tbn1_ot_modos_ingreso.des_modo_ingreso IS NULL AND query.des_modo_ingreso IS NOT NULL) OR  (tbn1_ot_modos_ingreso.des_modo_ingreso IS NOT NULL AND query.des_modo_ingreso IS NULL)
                    OR (fec_baja IS NOT NULL))) THEN
    UPDATE SET
      des_modo_ingreso=query.des_modo_ingreso,
      fec_modificacion=getdate(),
      fec_baja=null
  WHEN NOT MATCHED THEN
    INSERT (modo_ingreso,des_modo_ingreso,fec_alta,fec_modificacion) VALUES (
      query.modo_ingreso,
      query.des_modo_ingreso,
      getdate(),
      getdate())
  WHEN NOT MATCHED BY SOURCE AND (tbn1_ot_modos_ingreso.es_indefinido=0
                                  AND fec_baja IS NULL) THEN
    UPDATE SET
      fec_baja=getdate(),
      fec_modificacion=getdate();

  EXECUTE dbn1_stg_dhyf_u.dbo.spn1_finalizar_log @log,@@ROWCOUNT;
   END TRY
  BEGIN CATCH
    EXECUTE dbn1_stg_dhyf_u.dbo.spn1_finalizar_log @log,null;
    UPDATE dbn1_norm_dhyf_u.audit.tbn1_logs SET
      mensaje_error=error_message(),
      procedimiento_error=error_procedure()
    WHERE
      id_log=@log;
    IF @continuar_en_caso_error=0 OR @logpadre IS NULL THROW
  END CATCH


END

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_situaciones')
CREATE TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_situaciones(
  id_situacion int IDENTITY(1,1),
  cod_situacion varchar(2),
  situacion varchar(50),
  cod_tipo_situacion int NOT NULL,
  tipo_situacion varchar(50),
  es_indefinido bit,
  fec_alta datetime,
  fec_modificacion datetime,
  fec_baja datetime,
  CONSTRAINT uk_ot_situaciones UNIQUE (cod_situacion),
  CONSTRAINT PK_tbn1_ot_situaciones PRIMARY KEY CLUSTERED (id_situacion)
)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_situaciones' AND COLUMN_NAME='id_situacion')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_situaciones ADD id_situacion int

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_situaciones' AND COLUMN_NAME='cod_situacion')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_situaciones ADD cod_situacion varchar(2)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_situaciones' AND COLUMN_NAME='situacion')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_situaciones ADD situacion varchar(50)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_situaciones' AND COLUMN_NAME='cod_tipo_situacion')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_situaciones ADD cod_tipo_situacion int

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_situaciones' AND COLUMN_NAME='tipo_situacion')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_situaciones ADD tipo_situacion varchar(50)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_situaciones' AND COLUMN_NAME='es_indefinido')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_situaciones ADD es_indefinido bit

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_situaciones' AND COLUMN_NAME='fec_alta')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_situaciones ADD fec_alta datetime

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_situaciones' AND COLUMN_NAME='fec_modificacion')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_situaciones ADD fec_modificacion datetime

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_situaciones' AND COLUMN_NAME='fec_baja')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_situaciones ADD fec_baja datetime

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_situaciones' AND COLUMN_NAME='cod_tipo_situacion' AND COLUMN_DEFAULT IS NULL)
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_situaciones ADD CONSTRAINT DF_DBO_TBN1_OT_SITUACIONES_COD_TIPO_SITUACION DEFAULT 0 FOR cod_tipo_situacion

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_situaciones' AND COLUMN_NAME='es_indefinido' AND COLUMN_DEFAULT IS NULL)
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_situaciones ADD CONSTRAINT DF_DBO_TBN1_OT_SITUACIONES_ES_INDEFINIDO DEFAULT 0 FOR es_indefinido

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_situaciones' AND COLUMN_NAME='id_situacion' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_situaciones ALTER COLUMN id_situacion int NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_situaciones' AND COLUMN_NAME='cod_situacion' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_situaciones ALTER COLUMN cod_situacion varchar(2) NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_situaciones' AND COLUMN_NAME='situacion' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_situaciones ALTER COLUMN situacion varchar(50) NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_situaciones' AND COLUMN_NAME='cod_tipo_situacion' AND IS_NULLABLE='YES')
BEGIN
  UPDATE dbn1_norm_dhyf_u.dbo.tbn1_ot_situaciones SET cod_tipo_situacion=0 WHERE cod_tipo_situacion IS NULL
  ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_situaciones ALTER COLUMN cod_tipo_situacion int NOT NULL
END

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_situaciones' AND COLUMN_NAME='tipo_situacion' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_situaciones ALTER COLUMN tipo_situacion varchar(50) NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_situaciones' AND COLUMN_NAME='es_indefinido' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_situaciones ALTER COLUMN es_indefinido bit NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_situaciones' AND COLUMN_NAME='fec_alta' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_situaciones ALTER COLUMN fec_alta datetime NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_situaciones' AND COLUMN_NAME='fec_modificacion' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_situaciones ALTER COLUMN fec_modificacion datetime NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_situaciones' AND COLUMN_NAME='fec_baja' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_situaciones ALTER COLUMN fec_baja datetime NULL

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_situaciones' AND CONSTRAINT_NAME='PK_tbn1_ot_situaciones')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_situaciones ADD CONSTRAINT PK_tbn1_ot_situaciones PRIMARY KEY CLUSTERED (id_situacion)

GO

;WITH
query AS (
  SELECT 1 AS es_indefinido,'ZZ' AS cod_situacion,'Otras' AS situacion,4 AS cod_tipo_situacion,'OTRAS SITUACIONES' AS tipo_situacion
)
MERGE dbn1_norm_dhyf_u.dbo.tbn1_ot_situaciones AS tbn1_ot_situaciones
USING query ON query.es_indefinido=tbn1_ot_situaciones.es_indefinido
WHEN MATCHED AND ((tbn1_ot_situaciones.cod_situacion<>query.cod_situacion OR (tbn1_ot_situaciones.cod_situacion IS NULL AND query.cod_situacion IS NOT NULL) OR  (tbn1_ot_situaciones.cod_situacion IS NOT NULL AND query.cod_situacion IS NULL)
                  OR tbn1_ot_situaciones.situacion<>query.situacion OR (tbn1_ot_situaciones.situacion IS NULL AND query.situacion IS NOT NULL) OR  (tbn1_ot_situaciones.situacion IS NOT NULL AND query.situacion IS NULL)
                  OR tbn1_ot_situaciones.cod_tipo_situacion<>query.cod_tipo_situacion OR (tbn1_ot_situaciones.cod_tipo_situacion IS NULL AND query.cod_tipo_situacion IS NOT NULL) OR  (tbn1_ot_situaciones.cod_tipo_situacion IS NOT NULL AND query.cod_tipo_situacion IS NULL)
                  OR tbn1_ot_situaciones.tipo_situacion<>query.tipo_situacion OR (tbn1_ot_situaciones.tipo_situacion IS NULL AND query.tipo_situacion IS NOT NULL) OR  (tbn1_ot_situaciones.tipo_situacion IS NOT NULL AND query.tipo_situacion IS NULL))) THEN
  UPDATE SET
    cod_situacion=query.cod_situacion,
    situacion=query.situacion,
    cod_tipo_situacion=query.cod_tipo_situacion,
    tipo_situacion=query.tipo_situacion
WHEN NOT MATCHED THEN
  INSERT (es_indefinido,cod_situacion,situacion,cod_tipo_situacion,tipo_situacion) VALUES (
    query.es_indefinido,
    query.cod_situacion,
    query.situacion,
    query.cod_tipo_situacion,
    query.tipo_situacion);
GO

USE dbn1_stg_dhyf_u
GO

IF EXISTS (SELECT 1 FROM dbn1_stg_dhyf_u.INFORMATION_SCHEMA.ROUTINES WHERE ROUTINE_SCHEMA='dbo' AND ROUTINE_NAME='spn1_cargar_normalizado_ot_situaciones' AND ROUTINE_TYPE='PROCEDURE')
DROP PROCEDURE dbo.spn1_cargar_normalizado_ot_situaciones;
GO

CREATE PROCEDURE dbo.spn1_cargar_normalizado_ot_situaciones(@logpadre int) AS
BEGIN

  DECLARE @procedure_name varchar(100)='dbn1_stg_dhyf_u.dbo.spn1_cargar_normalizado_ot_situaciones'
  SET NOCOUNT ON;
  DECLARE @log int;
  EXECUTE @log = dbn1_stg_dhyf_u.dbo.spn1_apuntar_log @logpadre,@procedure_name;
  DECLARE @fecha_ultima_carga datetime=dbn1_stg_dhyf_u.dbo.fnn1_fecha_ultima_carga(@log);
  DECLARE @continuar_en_caso_error bit=0;
  IF @logpadre IS NOT NULL AND EXISTS (SELECT 1 AS expr1
  FROM dbn1_norm_dhyf_u.audit.tbn1_procedimientos_excluidos
  WHERE
    'dbn1_stg_dhyf_u.dbo.'+procedimiento=@procedure_name
    AND excluido=1
  ) BEGIN
    UPDATE dbn1_norm_dhyf_u.audit.tbn1_logs SET
      mensaje_error='EXCLUÍDO'
    WHERE
      id_log=@log;
    RETURN
  END
     BEGIN TRY

  ;WITH
  query AS (
    SELECT
      cod_situacion,
      situacion.situacion AS situacion,
      cod_tipo_situacion,
      tipo_situacion
    FROM
      (SELECT 'AP' cod_situacion,'APLAZADA' situacion,1 cod_tipo_situacion,'APLAZADA' tipo_situacion
       UNION ALL SELECT 'DA','DENEGADO EL APLAZ. PENDIENTE NOTIFICAR',1,'APLAZADA'
       UNION ALL SELECT 'SA','SOLICITADO APLAZAMIENTO',1,'APLAZADA'
       UNION ALL SELECT 'PB','PREBAJA',2,'BAJA'
       UNION ALL SELECT 'SR','RECURSOS ESTIMADO PENDIENTE',2,'BAJA'
       UNION ALL SELECT 'AN','ANULADA',2,'BAJA'
       UNION ALL SELECT 'BA','BAJA',2,'BAJA'
       UNION ALL SELECT 'AY','DESCARGA ORIGEN',2,'BAJA'
       UNION ALL SELECT 'PR','PRESCRITA',2,'BAJA'
       UNION ALL SELECT 'CE','CONVENIO',3,'EN CONCURSO'
       UNION ALL SELECT 'CO','CONCURSAL- PROCEDIMIENTO CONCURSAL',3,'EN CONCURSO'
       UNION ALL SELECT 'PC','POSTCONCURSAL',3,'EN CONCURSO'
       UNION ALL SELECT 'SC','CONCURSAL CREDITO PARTICIPATIVO',3,'EN CONCURSO'
       UNION ALL SELECT 'SQ','CONCURSAL-QUITA',3,'EN CONCURSO'
       UNION ALL SELECT 'RP','RECARGO EJEC PENDIENTE DE CONTABILIZAR',4,'OTRAS SITUACIONES'
       UNION ALL SELECT 'SS','SUBDIVIDIDA',4,'OTRAS SITUACIONES'
       UNION ALL SELECT 'SB','SUSPENSIÓN DE LA APLICACIÓN HN MODELO B65',4,'OTRAS SITUACIONES'
       UNION ALL SELECT 'AC','ANULADA CARGO AL CONTADOR',4,'OTRAS SITUACIONES'
       UNION ALL SELECT 'FA','FALLIDO',4,'OTRAS SITUACIONES'
       UNION ALL SELECT 'PP','PAGADA SIN NOTIF. LA EJE + 10%',4,'OTRAS SITUACIONES'
       UNION ALL SELECT 'PQ','PREQUITA',4,'OTRAS SITUACIONES'
       UNION ALL SELECT 'SK','SUSPENSIÓN PARA APLICAR COMPENSACIÓN',4,'OTRAS SITUACIONES'
       UNION ALL SELECT 'SP','CONCURSAL APLAZADA',4,'OTRAS SITUACIONES'
       UNION ALL SELECT 'SZ','SOLICITADO APLAZAMIENTO SUSPENDIDO',4,'OTRAS SITUACIONES'
       UNION ALL SELECT 'B','INEXISTENTE',4,'OTRAS SITUACIONES'
       UNION ALL SELECT 'C0','INEXISTENTE',4,'OTRAS SITUACIONES'
       UNION ALL SELECT '0','INEXISTENTE',4,'OTRAS SITUACIONES'
       UNION ALL SELECT 'DO','DOMICILIACIONES RECONOCIMIENTOS DEUDA',5,'PAGADA'
       UNION ALL SELECT 'PE','PAGADA POR ENTREGA DE BIENES',5,'PAGADA'
       UNION ALL SELECT 'SO','COMPENSACIóN PENDIENTE ACTAS INSPECCION',5,'PAGADA'
       UNION ALL SELECT 'SV','LIQUIDACIóN PENDIENTE DE APLICAR',5,'PAGADA'
       UNION ALL SELECT 'AI','AUTOLIQUIDACION CON INGRESO',5,'PAGADA'
       UNION ALL SELECT '0D','IMPORTE CERO',5,'PAGADA'
       UNION ALL SELECT 'DF','FRACCIONADA EN GESTION',5,'PAGADA'
       UNION ALL SELECT 'PA','PAGADA',5,'PAGADA'
       UNION ALL SELECT 'FD','DOCUMENTO NIF FALLECIDO',6,'PENDIENTE'
       UNION ALL SELECT 'FN','FALLIDO DERIVADO',6,'PENDIENTE'
       UNION ALL SELECT 'IN','INCOBRABLE',6,'PENDIENTE'
       UNION ALL SELECT 'PF','PREFALLIDO',6,'PENDIENTE'
       UNION ALL SELECT '','PENDIENTE',6,'PENDIENTE'
       UNION ALL SELECT 'ST','PROCESO SUSPENSIóN. PENDIENTE FISCALIZAC',7,'SUSPENDIDA'
       UNION ALL SELECT 'SU','SUSPENDIDO',7,'SUSPENDIDA'
       UNION ALL SELECT 'SY','LEVANT.SUSPENSION PENDIENTE',7,'SUSPENDIDA'
       UNION ALL SELECT 'SX','SUSPENDIDA PROVISIONAL',7,'SUSPENDIDA') situacion
  )
  MERGE dbn1_norm_dhyf_u.dbo.tbn1_ot_situaciones AS tbn1_ot_situaciones
  USING query ON query.cod_situacion=tbn1_ot_situaciones.cod_situacion
  WHEN MATCHED AND (tbn1_ot_situaciones.es_indefinido=0
                    AND (tbn1_ot_situaciones.situacion<>query.situacion OR (tbn1_ot_situaciones.situacion IS NULL AND query.situacion IS NOT NULL) OR  (tbn1_ot_situaciones.situacion IS NOT NULL AND query.situacion IS NULL)
                    OR tbn1_ot_situaciones.cod_tipo_situacion<>query.cod_tipo_situacion OR (tbn1_ot_situaciones.cod_tipo_situacion IS NULL AND query.cod_tipo_situacion IS NOT NULL) OR  (tbn1_ot_situaciones.cod_tipo_situacion IS NOT NULL AND query.cod_tipo_situacion IS NULL)
                    OR tbn1_ot_situaciones.tipo_situacion<>query.tipo_situacion OR (tbn1_ot_situaciones.tipo_situacion IS NULL AND query.tipo_situacion IS NOT NULL) OR  (tbn1_ot_situaciones.tipo_situacion IS NOT NULL AND query.tipo_situacion IS NULL)
                    OR (fec_baja IS NOT NULL))) THEN
    UPDATE SET
      situacion=query.situacion,
      cod_tipo_situacion=query.cod_tipo_situacion,
      tipo_situacion=query.tipo_situacion,
      fec_modificacion=getdate(),
      fec_baja=null
  WHEN NOT MATCHED THEN
    INSERT (cod_situacion,situacion,cod_tipo_situacion,tipo_situacion,fec_alta,fec_modificacion) VALUES (
      query.cod_situacion,
      query.situacion,
      query.cod_tipo_situacion,
      query.tipo_situacion,
      getdate(),
      getdate())
  WHEN NOT MATCHED BY SOURCE AND (tbn1_ot_situaciones.es_indefinido=0
                                  AND fec_baja IS NULL) THEN
    UPDATE SET
      fec_baja=getdate(),
      fec_modificacion=getdate();

  EXECUTE dbn1_stg_dhyf_u.dbo.spn1_finalizar_log @log,@@ROWCOUNT;
   END TRY
  BEGIN CATCH
    EXECUTE dbn1_stg_dhyf_u.dbo.spn1_finalizar_log @log,null;
    UPDATE dbn1_norm_dhyf_u.audit.tbn1_logs SET
      mensaje_error=error_message(),
      procedimiento_error=error_procedure()
    WHERE
      id_log=@log;
    IF @continuar_en_caso_error=0 OR @logpadre IS NULL THROW
  END CATCH


END

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_codigos_operacion')
CREATE TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_codigos_operacion(
  id_codigo_operacion int IDENTITY(1,1),
  codigo_operacion varchar(4) NOT NULL,
  descripcion varchar(50) NOT NULL,
  signo int NULL,
  cod_signo varchar(1) NOT NULL,
  cuenta_para_pendiente bit NOT NULL,
  cod_tipo_movimiento int NOT NULL,
  tipo_movimiento varchar(20) NOT NULL,
  es_indefinido bit,
  clasificacion varchar(40) NOT NULL,
  cod_subclasificacion int NOT NULL,
  subclasificacion varchar(40) NOT NULL,
  estado varchar(2) NOT NULL,
  origen varchar(10) NOT NULL,
  fec_alta datetime,
  fec_modificacion datetime,
  fec_baja datetime,
  CONSTRAINT uk_ot_codigos_operación UNIQUE (codigo_operacion),
  CONSTRAINT PK_tbn1_ot_codigos_operacion PRIMARY KEY CLUSTERED (id_codigo_operacion)
)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_codigos_operacion' AND COLUMN_NAME='id_codigo_operacion')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_codigos_operacion ADD id_codigo_operacion int

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_codigos_operacion' AND COLUMN_NAME='codigo_operacion')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_codigos_operacion ADD codigo_operacion varchar(4)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_codigos_operacion' AND COLUMN_NAME='descripcion')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_codigos_operacion ADD descripcion varchar(50)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_codigos_operacion' AND COLUMN_NAME='signo')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_codigos_operacion ADD signo int

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_codigos_operacion' AND COLUMN_NAME='cod_signo')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_codigos_operacion ADD cod_signo varchar(1)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_codigos_operacion' AND COLUMN_NAME='cuenta_para_pendiente')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_codigos_operacion ADD cuenta_para_pendiente bit

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_codigos_operacion' AND COLUMN_NAME='cod_tipo_movimiento')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_codigos_operacion ADD cod_tipo_movimiento int

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_codigos_operacion' AND COLUMN_NAME='tipo_movimiento')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_codigos_operacion ADD tipo_movimiento varchar(20)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_codigos_operacion' AND COLUMN_NAME='es_indefinido')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_codigos_operacion ADD es_indefinido bit

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_codigos_operacion' AND COLUMN_NAME='clasificacion')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_codigos_operacion ADD clasificacion varchar(40)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_codigos_operacion' AND COLUMN_NAME='cod_subclasificacion')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_codigos_operacion ADD cod_subclasificacion int

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_codigos_operacion' AND COLUMN_NAME='subclasificacion')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_codigos_operacion ADD subclasificacion varchar(40)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_codigos_operacion' AND COLUMN_NAME='estado')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_codigos_operacion ADD estado varchar(2)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_codigos_operacion' AND COLUMN_NAME='origen')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_codigos_operacion ADD origen varchar(10)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_codigos_operacion' AND COLUMN_NAME='fec_alta')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_codigos_operacion ADD fec_alta datetime

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_codigos_operacion' AND COLUMN_NAME='fec_modificacion')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_codigos_operacion ADD fec_modificacion datetime

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_codigos_operacion' AND COLUMN_NAME='fec_baja')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_codigos_operacion ADD fec_baja datetime

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_codigos_operacion' AND COLUMN_NAME='cod_signo' AND COLUMN_DEFAULT IS NULL)
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_codigos_operacion ADD CONSTRAINT DF_DBO_TBN1_OT_CODIGOS_OPERACION_COD_SIGNO DEFAULT '' FOR cod_signo

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_codigos_operacion' AND COLUMN_NAME='cuenta_para_pendiente' AND COLUMN_DEFAULT IS NULL)
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_codigos_operacion ADD CONSTRAINT DF_DBO_TBN1_OT_CODIGOS_OPERACION_CUENTA_PARA_PENDIENTE DEFAULT 0 FOR cuenta_para_pendiente

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_codigos_operacion' AND COLUMN_NAME='cod_tipo_movimiento' AND COLUMN_DEFAULT IS NULL)
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_codigos_operacion ADD CONSTRAINT DF_DBO_TBN1_OT_CODIGOS_OPERACION_COD_TIPO_MOVIMIENTO DEFAULT 0 FOR cod_tipo_movimiento

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_codigos_operacion' AND COLUMN_NAME='tipo_movimiento' AND COLUMN_DEFAULT IS NULL)
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_codigos_operacion ADD CONSTRAINT DF_DBO_TBN1_OT_CODIGOS_OPERACION_TIPO_MOVIMIENTO DEFAULT '' FOR tipo_movimiento

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_codigos_operacion' AND COLUMN_NAME='es_indefinido' AND COLUMN_DEFAULT IS NULL)
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_codigos_operacion ADD CONSTRAINT DF_DBO_TBN1_OT_CODIGOS_OPERACION_ES_INDEFINIDO DEFAULT 0 FOR es_indefinido

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_codigos_operacion' AND COLUMN_NAME='clasificacion' AND COLUMN_DEFAULT IS NULL)
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_codigos_operacion ADD CONSTRAINT DF_DBO_TBN1_OT_CODIGOS_OPERACION_CLASIFICACION DEFAULT '' FOR clasificacion

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_codigos_operacion' AND COLUMN_NAME='cod_subclasificacion' AND COLUMN_DEFAULT IS NULL)
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_codigos_operacion ADD CONSTRAINT DF_DBO_TBN1_OT_CODIGOS_OPERACION_COD_SUBCLASIFICACION DEFAULT 0 FOR cod_subclasificacion

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_codigos_operacion' AND COLUMN_NAME='subclasificacion' AND COLUMN_DEFAULT IS NULL)
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_codigos_operacion ADD CONSTRAINT DF_DBO_TBN1_OT_CODIGOS_OPERACION_SUBCLASIFICACION DEFAULT '' FOR subclasificacion

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_codigos_operacion' AND COLUMN_NAME='estado' AND COLUMN_DEFAULT IS NULL)
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_codigos_operacion ADD CONSTRAINT DF_DBO_TBN1_OT_CODIGOS_OPERACION_ESTADO DEFAULT '' FOR estado

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_codigos_operacion' AND COLUMN_NAME='origen' AND COLUMN_DEFAULT IS NULL)
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_codigos_operacion ADD CONSTRAINT DF_DBO_TBN1_OT_CODIGOS_OPERACION_ORIGEN DEFAULT '' FOR origen

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_codigos_operacion' AND COLUMN_NAME='id_codigo_operacion' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_codigos_operacion ALTER COLUMN id_codigo_operacion int NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_codigos_operacion' AND COLUMN_NAME='codigo_operacion' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_codigos_operacion ALTER COLUMN codigo_operacion varchar(4) NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_codigos_operacion' AND COLUMN_NAME='descripcion' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_codigos_operacion ALTER COLUMN descripcion varchar(50) NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_codigos_operacion' AND COLUMN_NAME='signo' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_codigos_operacion ALTER COLUMN signo int NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_codigos_operacion' AND COLUMN_NAME='cod_signo' AND IS_NULLABLE='YES')
BEGIN
  UPDATE dbn1_norm_dhyf_u.dbo.tbn1_ot_codigos_operacion SET cod_signo='' WHERE cod_signo IS NULL
  ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_codigos_operacion ALTER COLUMN cod_signo varchar(1) NOT NULL
END

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_codigos_operacion' AND COLUMN_NAME='cuenta_para_pendiente' AND IS_NULLABLE='YES')
BEGIN
  UPDATE dbn1_norm_dhyf_u.dbo.tbn1_ot_codigos_operacion SET cuenta_para_pendiente=0 WHERE cuenta_para_pendiente IS NULL
  ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_codigos_operacion ALTER COLUMN cuenta_para_pendiente bit NOT NULL
END

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_codigos_operacion' AND COLUMN_NAME='cod_tipo_movimiento' AND IS_NULLABLE='YES')
BEGIN
  UPDATE dbn1_norm_dhyf_u.dbo.tbn1_ot_codigos_operacion SET cod_tipo_movimiento=0 WHERE cod_tipo_movimiento IS NULL
  ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_codigos_operacion ALTER COLUMN cod_tipo_movimiento int NOT NULL
END

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_codigos_operacion' AND COLUMN_NAME='tipo_movimiento' AND IS_NULLABLE='YES')
BEGIN
  UPDATE dbn1_norm_dhyf_u.dbo.tbn1_ot_codigos_operacion SET tipo_movimiento='' WHERE tipo_movimiento IS NULL
  ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_codigos_operacion ALTER COLUMN tipo_movimiento varchar(20) NOT NULL
END

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_codigos_operacion' AND COLUMN_NAME='es_indefinido' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_codigos_operacion ALTER COLUMN es_indefinido bit NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_codigos_operacion' AND COLUMN_NAME='clasificacion' AND IS_NULLABLE='YES')
BEGIN
  UPDATE dbn1_norm_dhyf_u.dbo.tbn1_ot_codigos_operacion SET clasificacion='' WHERE clasificacion IS NULL
  ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_codigos_operacion ALTER COLUMN clasificacion varchar(40) NOT NULL
END

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_codigos_operacion' AND COLUMN_NAME='cod_subclasificacion' AND IS_NULLABLE='YES')
BEGIN
  UPDATE dbn1_norm_dhyf_u.dbo.tbn1_ot_codigos_operacion SET cod_subclasificacion=0 WHERE cod_subclasificacion IS NULL
  ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_codigos_operacion ALTER COLUMN cod_subclasificacion int NOT NULL
END

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_codigos_operacion' AND COLUMN_NAME='subclasificacion' AND IS_NULLABLE='YES')
BEGIN
  UPDATE dbn1_norm_dhyf_u.dbo.tbn1_ot_codigos_operacion SET subclasificacion='' WHERE subclasificacion IS NULL
  ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_codigos_operacion ALTER COLUMN subclasificacion varchar(40) NOT NULL
END

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_codigos_operacion' AND COLUMN_NAME='estado' AND IS_NULLABLE='YES')
BEGIN
  UPDATE dbn1_norm_dhyf_u.dbo.tbn1_ot_codigos_operacion SET estado='' WHERE estado IS NULL
  ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_codigos_operacion ALTER COLUMN estado varchar(2) NOT NULL
END

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_codigos_operacion' AND COLUMN_NAME='origen' AND IS_NULLABLE='YES')
BEGIN
  UPDATE dbn1_norm_dhyf_u.dbo.tbn1_ot_codigos_operacion SET origen='' WHERE origen IS NULL
  ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_codigos_operacion ALTER COLUMN origen varchar(10) NOT NULL
END

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_codigos_operacion' AND COLUMN_NAME='fec_alta' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_codigos_operacion ALTER COLUMN fec_alta datetime NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_codigos_operacion' AND COLUMN_NAME='fec_modificacion' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_codigos_operacion ALTER COLUMN fec_modificacion datetime NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_codigos_operacion' AND COLUMN_NAME='fec_baja' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_codigos_operacion ALTER COLUMN fec_baja datetime NULL

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_codigos_operacion' AND CONSTRAINT_NAME='PK_tbn1_ot_codigos_operacion')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_codigos_operacion ADD CONSTRAINT PK_tbn1_ot_codigos_operacion PRIMARY KEY CLUSTERED (id_codigo_operacion)

GO

;WITH
query AS (
  SELECT 1 AS es_indefinido,'ZZZZ' AS codigo_operacion,'Indefinido' AS descripcion,1 AS signo,'' AS cod_signo,0 AS cuenta_para_pendiente,4 AS cod_tipo_movimiento,'RESTO' AS tipo_movimiento,'Indefinido' AS clasificacion,0 AS cod_subclasificacion,'Indefinido' AS subclasificacion,'' AS estado
)
MERGE dbn1_norm_dhyf_u.dbo.tbn1_ot_codigos_operacion AS tbn1_ot_codigos_operacion
USING query ON query.es_indefinido=tbn1_ot_codigos_operacion.es_indefinido
WHEN MATCHED AND ((tbn1_ot_codigos_operacion.codigo_operacion<>query.codigo_operacion OR (tbn1_ot_codigos_operacion.codigo_operacion IS NULL AND query.codigo_operacion IS NOT NULL) OR  (tbn1_ot_codigos_operacion.codigo_operacion IS NOT NULL AND query.codigo_operacion IS NULL)
                  OR tbn1_ot_codigos_operacion.descripcion<>query.descripcion OR (tbn1_ot_codigos_operacion.descripcion IS NULL AND query.descripcion IS NOT NULL) OR  (tbn1_ot_codigos_operacion.descripcion IS NOT NULL AND query.descripcion IS NULL)
                  OR tbn1_ot_codigos_operacion.signo<>query.signo OR (tbn1_ot_codigos_operacion.signo IS NULL AND query.signo IS NOT NULL) OR  (tbn1_ot_codigos_operacion.signo IS NOT NULL AND query.signo IS NULL)
                  OR tbn1_ot_codigos_operacion.cod_signo<>query.cod_signo OR (tbn1_ot_codigos_operacion.cod_signo IS NULL AND query.cod_signo IS NOT NULL) OR  (tbn1_ot_codigos_operacion.cod_signo IS NOT NULL AND query.cod_signo IS NULL)
                  OR tbn1_ot_codigos_operacion.cuenta_para_pendiente<>query.cuenta_para_pendiente OR (tbn1_ot_codigos_operacion.cuenta_para_pendiente IS NULL AND query.cuenta_para_pendiente IS NOT NULL) OR  (tbn1_ot_codigos_operacion.cuenta_para_pendiente IS NOT NULL AND query.cuenta_para_pendiente IS NULL)
                  OR tbn1_ot_codigos_operacion.cod_tipo_movimiento<>query.cod_tipo_movimiento OR (tbn1_ot_codigos_operacion.cod_tipo_movimiento IS NULL AND query.cod_tipo_movimiento IS NOT NULL) OR  (tbn1_ot_codigos_operacion.cod_tipo_movimiento IS NOT NULL AND query.cod_tipo_movimiento IS NULL)
                  OR tbn1_ot_codigos_operacion.tipo_movimiento<>query.tipo_movimiento OR (tbn1_ot_codigos_operacion.tipo_movimiento IS NULL AND query.tipo_movimiento IS NOT NULL) OR  (tbn1_ot_codigos_operacion.tipo_movimiento IS NOT NULL AND query.tipo_movimiento IS NULL)
                  OR tbn1_ot_codigos_operacion.clasificacion<>query.clasificacion OR (tbn1_ot_codigos_operacion.clasificacion IS NULL AND query.clasificacion IS NOT NULL) OR  (tbn1_ot_codigos_operacion.clasificacion IS NOT NULL AND query.clasificacion IS NULL)
                  OR tbn1_ot_codigos_operacion.cod_subclasificacion<>query.cod_subclasificacion OR (tbn1_ot_codigos_operacion.cod_subclasificacion IS NULL AND query.cod_subclasificacion IS NOT NULL) OR  (tbn1_ot_codigos_operacion.cod_subclasificacion IS NOT NULL AND query.cod_subclasificacion IS NULL)
                  OR tbn1_ot_codigos_operacion.subclasificacion<>query.subclasificacion OR (tbn1_ot_codigos_operacion.subclasificacion IS NULL AND query.subclasificacion IS NOT NULL) OR  (tbn1_ot_codigos_operacion.subclasificacion IS NOT NULL AND query.subclasificacion IS NULL)
                  OR tbn1_ot_codigos_operacion.estado<>query.estado OR (tbn1_ot_codigos_operacion.estado IS NULL AND query.estado IS NOT NULL) OR  (tbn1_ot_codigos_operacion.estado IS NOT NULL AND query.estado IS NULL))) THEN
  UPDATE SET
    codigo_operacion=query.codigo_operacion,
    descripcion=query.descripcion,
    signo=query.signo,
    cod_signo=query.cod_signo,
    cuenta_para_pendiente=query.cuenta_para_pendiente,
    cod_tipo_movimiento=query.cod_tipo_movimiento,
    tipo_movimiento=query.tipo_movimiento,
    clasificacion=query.clasificacion,
    cod_subclasificacion=query.cod_subclasificacion,
    subclasificacion=query.subclasificacion,
    estado=query.estado
WHEN NOT MATCHED THEN
  INSERT (es_indefinido,codigo_operacion,descripcion,signo,cod_signo,cuenta_para_pendiente,cod_tipo_movimiento,tipo_movimiento,clasificacion,cod_subclasificacion,subclasificacion,estado) VALUES (
    query.es_indefinido,
    query.codigo_operacion,
    query.descripcion,
    query.signo,
    query.cod_signo,
    query.cuenta_para_pendiente,
    query.cod_tipo_movimiento,
    query.tipo_movimiento,
    query.clasificacion,
    query.cod_subclasificacion,
    query.subclasificacion,
    query.estado);
GO

USE dbn1_stg_dhyf_u
GO

IF EXISTS (SELECT 1 FROM dbn1_stg_dhyf_u.INFORMATION_SCHEMA.ROUTINES WHERE ROUTINE_SCHEMA='dbo' AND ROUTINE_NAME='spn1_cargar_normalizado_ot_codigos_operacion' AND ROUTINE_TYPE='PROCEDURE')
DROP PROCEDURE dbo.spn1_cargar_normalizado_ot_codigos_operacion;
GO

CREATE PROCEDURE dbo.spn1_cargar_normalizado_ot_codigos_operacion(@logpadre int) AS
BEGIN

  DECLARE @procedure_name varchar(100)='dbn1_stg_dhyf_u.dbo.spn1_cargar_normalizado_ot_codigos_operacion'
  SET NOCOUNT ON;
  DECLARE @log int;
  EXECUTE @log = dbn1_stg_dhyf_u.dbo.spn1_apuntar_log @logpadre,@procedure_name;
  DECLARE @fecha_ultima_carga datetime=dbn1_stg_dhyf_u.dbo.fnn1_fecha_ultima_carga(@log);
  DECLARE @continuar_en_caso_error bit=0;
  IF @logpadre IS NOT NULL AND EXISTS (SELECT 1 AS expr1
  FROM dbn1_norm_dhyf_u.audit.tbn1_procedimientos_excluidos
  WHERE
    'dbn1_stg_dhyf_u.dbo.'+procedimiento=@procedure_name
    AND excluido=1
  ) BEGIN
    UPDATE dbn1_norm_dhyf_u.audit.tbn1_logs SET
      mensaje_error='EXCLUÍDO'
    WHERE
      id_log=@log;
    RETURN
  END
     BEGIN TRY

  ;WITH
  query AS (
    SELECT
      codigo_operacion,
      descripcion,
      coalesce(signo,'') AS signo,
      coalesce(cod_signo,'') AS cod_signo,
      coalesce(cuenta_para_pendiente,1) AS cuenta_para_pendiente,
      coalesce(tipo_movimiento,'') AS tipo_movimiento,
      coalesce(cod_tipo_movimiento,'') AS cod_tipo_movimiento,
      coalesce(clasificacion,'') AS clasificacion,
      coalesce(cod_subclasificacion,0) AS cod_subclasificacion,
      coalesce(subclasificacion,'') AS subclasificacion,
      coalesce(estado,'') AS estado,
      origen
    FROM
      (SELECT
         coalesce(maestro.codigo_operacion,movimientos.codigo_operacion) codigo_operacion,
         coalesce(maestro.descripcion,movimientos.descripcion) descripcion,
         maestro.signo signo,
         maestro.cod_signo cod_signo,
         coalesce(maestro.cuenta_para_pendiente,movimientos.cuenta_para_pendiente) cuenta_para_pendiente,
         coalesce(maestro.tipo_movimiento,movimientos.tipo_movimiento) tipo_movimiento,
         coalesce(maestro.cod_tipo_movimiento,movimientos.cod_tipo_movimiento) cod_tipo_movimiento,
         maestro.clasificacion clasificacion,
         maestro.cod_subclasificacion cod_subclasificacion,
         maestro.subclasificacion subclasificacion,
         maestro.estado estado,
         coalesce(maestro.origen,movimientos.origen) origen
       FROM
           (SELECT
             oper.opeoper AS codigo_operacion,
             oper.opedesc AS descripcion,
             CASE WHEN oper.opesign='R' THEN -1 ELSE 1 END AS signo,
             oper.opesign AS cod_signo,
             CASE WHEN oper.opesign IN ('R','S') OR opeoper='2005' THEN 1 ELSE 0 END AS cuenta_para_pendiente,
             CASE
                 WHEN left(oper.opeoper,1)='1' THEN 'Ingresado'
                 WHEN (left(oper.opeoper,1)='2' AND CASE WHEN oper.opesign IN ('R','S') OR opeoper='2005' THEN 1 ELSE 0 END=1) OR left(oper.opeoper,2)='40' THEN 'Contraído'
                 WHEN (left(oper.opeoper,1)='3' AND left(oper.opeoper,2)<>'39') OR left(oper.opeoper,2)='41' THEN 'Anulado'
                 ELSE 'Resto'
             END AS tipo_movimiento,
             CASE
                 WHEN CASE
                     WHEN left(oper.opeoper,1)='1' THEN 'Ingresado'
                     WHEN (left(oper.opeoper,1)='2' AND CASE WHEN oper.opesign IN ('R','S') OR opeoper='2005' THEN 1 ELSE 0 END=1) OR left(oper.opeoper,2)='40' THEN 'Contraído'
                     WHEN (left(oper.opeoper,1)='3' AND left(oper.opeoper,2)<>'39') OR left(oper.opeoper,2)='41' THEN 'Anulado'
                     ELSE 'Resto'
                 END='Ingresado' THEN 1
                 WHEN CASE
                     WHEN left(oper.opeoper,1)='1' THEN 'Ingresado'
                     WHEN (left(oper.opeoper,1)='2' AND CASE WHEN oper.opesign IN ('R','S') OR opeoper='2005' THEN 1 ELSE 0 END=1) OR left(oper.opeoper,2)='40' THEN 'Contraído'
                     WHEN (left(oper.opeoper,1)='3' AND left(oper.opeoper,2)<>'39') OR left(oper.opeoper,2)='41' THEN 'Anulado'
                     ELSE 'Resto'
                 END='Contraído' THEN 2
                 WHEN CASE
                     WHEN left(oper.opeoper,1)='1' THEN 'Ingresado'
                     WHEN (left(oper.opeoper,1)='2' AND CASE WHEN oper.opesign IN ('R','S') OR opeoper='2005' THEN 1 ELSE 0 END=1) OR left(oper.opeoper,2)='40' THEN 'Contraído'
                     WHEN (left(oper.opeoper,1)='3' AND left(oper.opeoper,2)<>'39') OR left(oper.opeoper,2)='41' THEN 'Anulado'
                     ELSE 'Resto'
                 END='Anulado' THEN 3
                 ELSE 4
             END AS cod_tipo_movimiento,
             coalesce(timo.clasificacion,'Indefinido') AS clasificacion,
             coalesce(timo.cod_subclasificacion,0) AS cod_subclasificacion,
             coalesce(timo.subclasificacion,'Indefinido') AS subclasificacion,
             coalesce(timo.estado,'') AS estado,
             'MAESTRO' AS origen
           FROM dbn1_stg_dhyf_u.dbo.tbn1oper_ti oper
           LEFT JOIN (SELECT 3001 cod_operacion,'TIA0 - BAJA POR ANULACION DE LIQ. VOLUNT' des_operacion,'LV' estado,'Anulación deuda' clasificacion,1 cod_subclasificacion,'Bajas Liquidación' subclasificacion
                      UNION ALL SELECT 3002,'TIA0 - BAJA POR ANULACION DE LIQ. EJECUT','LE','Anulación deuda',1,'Bajas Liquidación'
                      UNION ALL SELECT 3003,'TIA0 - BAJA POR ANULACION DE REC. VOLUNT','RV','Anulación deuda',1,'Bajas Liquidación'
                      UNION ALL SELECT 3004,'TIA0 - BAJA POR ANULACION DE REC. EJECUT','RE','Anulación deuda',1,'Bajas Liquidación'
                      UNION ALL SELECT 3902,'TIA0 - BAJA RECARGOS SIN PROV.APREMIO LI','LE','Anulación deuda',1,'Bajas Liquidación'
                      UNION ALL SELECT 3904,'TIA0 - BAJA RECARGOS SIN PROV.APREMIO RE','RE','Anulación deuda',1,'Bajas Liquidación'
                      UNION ALL SELECT 3905,'TIA0 - BAJA RECARGOS SIN PROV APR LIQ.IN','LE','Anulación deuda',1,'Bajas Liquidación'
                      UNION ALL SELECT 3906,'TIA0 - BAJA RECARGOS SIN PROV APREMIO RE','RE','Anulación deuda',1,'Bajas Liquidación'
                      UNION ALL SELECT 3101,'TIA0 - DATA POR INCOBRABLES DE LIQ. VOLU','LV','Anulación deuda',3,'Incobrables'
                      UNION ALL SELECT 3102,'TIA0 - DATA POR INCOBRABLES DE LIQ. EJEC','LE','Anulación deuda',3,'Incobrables'
                      UNION ALL SELECT 3103,'TIA0 - DATA POR INCOBRABLES DE REC.VOLUN','RV','Anulación deuda',3,'Incobrables'
                      UNION ALL SELECT 3104,'TIA0 - DATA POR INCOBRABLES REC. EJECUTI','RE','Anulación deuda',3,'Incobrables'
                      UNION ALL SELECT 3201,'TIA0 - BAJA POR PRESCRIPCION LIQ. VOLUNT','LV','Anulación deuda',5,'Prescripciones'
                      UNION ALL SELECT 3202,'TIA0 - BAJA POR PRESCRIPCION LIQ. EJECUT','LE','Anulación deuda',5,'Prescripciones'
                      UNION ALL SELECT 3203,'TIA0 - BAJA POR PRESCRIPCION REC. VOLUNT','RV','Anulación deuda',5,'Prescripciones'
                      UNION ALL SELECT 3204,'TIA0 - BAJA POR PRESCRIPCION REC. EJECUT','RE','Anulación deuda',5,'Prescripciones'
                      UNION ALL SELECT 3801,'TIA0 - DATA DE QUITA POR QUIEBRA LIQ.VOL','LV','Anulación deuda',6,'Quitas'
                      UNION ALL SELECT 3802,'TIA0 - DATA DE QUITA POR QUIEBRA LIQ. EJ','LE','Anulación deuda',6,'Quitas'
                      UNION ALL SELECT 3803,'TIA0 - DATA DE QUITA POR QUIEBRA REC.VOL','RV','Anulación deuda',6,'Quitas'
                      UNION ALL SELECT 3804,'TIA0 - DATA DE QUITA POR QUIEBRA REC. EJ','RE','Anulación deuda',6,'Quitas'
                      UNION ALL SELECT 3502,'TIA0 - BAJA POR ADJUDICACION DE LIQ. EJE','LE','Anulación deuda',2,'Daciones en pago / adjudicaciones'
                      UNION ALL SELECT 3504,'TIA0 - BAJA POR ADJUDICACION DE REC. EJE','RE','Anulación deuda',2,'Daciones en pago / adjudicaciones'
                      UNION ALL SELECT 3601,'TIA0 - BAJA POR DACION EN PAGO','LV','Anulación deuda',2,'Daciones en pago / adjudicaciones'
                      UNION ALL SELECT 3602,'TIA0 - BAJA POR DACION EN PAGO','LE','Anulación deuda',2,'Daciones en pago / adjudicaciones'
                      UNION ALL SELECT 3603,'TIA0 - BAJA POR DACION EN PAGO','RV','Anulación deuda',2,'Daciones en pago / adjudicaciones'
                      UNION ALL SELECT 3604,'TIA0 - BAJA POR DACION EN PAGO','RE','Anulación deuda',2,'Daciones en pago / adjudicaciones'
                      UNION ALL SELECT 3011,'TIA0 - BAJA POR IMPUTACION CONTABLE LIQ.','LV','Anulación deuda',4,'Otras'
                      UNION ALL SELECT 3012,'TIA0 - BAJA POR IMPUTACION CONTABLE LIQ.','LE','Anulación deuda',4,'Otras'
                      UNION ALL SELECT 3013,'TIA0 - BAJA POR IMPUTACION CONTABLE REC.','RV','Anulación deuda',4,'Otras'
                      UNION ALL SELECT 3014,'TIA0 - BAJA POR IMPUTACION CONTABLE REC.','RE','Anulación deuda',4,'Otras'
                      UNION ALL SELECT 3301,'TIA0 - DATA POR OTRAS CAUSAS LIQ. VOLUNT','LV','Anulación deuda',4,'Otras'
                      UNION ALL SELECT 3302,'TIA0 - DATA POR OTRAS CAUSAS LIQ. EJECUT','LE','Anulación deuda',4,'Otras'
                      UNION ALL SELECT 3303,'TIA0 - DATA POR OTRAS CAUSAS REC. VOLUNT','RV','Anulación deuda',4,'Otras'
                      UNION ALL SELECT 3304,'TIA0 - DATA POR OTRAS CAUSAS REC. EJECUT','RE','Anulación deuda',4,'Otras'
                      UNION ALL SELECT 3401,'TIA0 - BAJA POR MENOR IMPORTE LIQ. VOLUN','LV','Anulación deuda',4,'Otras'
                      UNION ALL SELECT 3402,'TIA0 - BAJA POR MENOR IMPORTE LIQ. EJECU','LE','Anulación deuda',4,'Otras'
                      UNION ALL SELECT 3403,'TIA0 - BAJA POR MENOR IMPORTE REC. VOLUN','RV','Anulación deuda',4,'Otras'
                      UNION ALL SELECT 3404,'TIA0 - BAJA POR MENOR IMPORTE REC. EJECU','RE','Anulación deuda',4,'Otras'
                      UNION ALL SELECT 3701,'TIA0 - DATA POR CARGO T/L AYTOS.LIQ.VOLU','LV','Anulación deuda',4,'Otras'
                      UNION ALL SELECT 3702,'TIA0 - DATA POR CARGO T/L. AYTOS. LIQ.EJ','LE','Anulación deuda',4,'Otras'
                      UNION ALL SELECT 3703,'TIA0 - DATA POR CARGO T/L. AYTOS.REC.VOL','RV','Anulación deuda',4,'Otras'
                      UNION ALL SELECT 3704,'TIA0 - DATA POR CARGO T/L. AYTOS.REC.EJE','RE','Anulación deuda',4,'Otras'
                      UNION ALL SELECT 4301,'TIA0 - ANULACION DE INCOBRABLE POR BAJA','LV','Anulación deuda',3,'Incobrables'
                      UNION ALL SELECT 4302,'TIA0 - ANULACION DE INCOBRABLE POR BAJA','LE','Anulación deuda',3,'Incobrables'
                      UNION ALL SELECT 4303,'TIA0 - ANULACION DE INCOBRABLE POR BAJA','RV','Anulación deuda',3,'Incobrables'
                      UNION ALL SELECT 4304,'TIA0 - ANULACION DE INCOBRABLE POR BAJA','RE','Anulación deuda',3,'Incobrables'
                      UNION ALL SELECT 4402,'TIA0 - ANULACION DE INCOBRABLE POR INGRE','LE','Anulación deuda',3,'Incobrables'
                      UNION ALL SELECT 4404,'TIA0 - ANULACION DE INCOBRABLE POR INGRE','RE','Anulación deuda',3,'Incobrables'
                      UNION ALL SELECT 4202,'TIA0 - ANULACION DE INCOBRABLE POR PRESC','LE','Anulación deuda',3,'Incobrables'
                      UNION ALL SELECT 4204,'TIA0 - ANULACION DE INCOBRABLE POR PRESC','RE','Anulación deuda',3,'Incobrables'
                      UNION ALL SELECT 4102,'TIA0 - REPOSICION EN VOLUNTARIA LIQ.EJECUTIVA','LE','Anulación deuda',7,'Reposición Recaudación'
                      UNION ALL SELECT 4104,'TIA0 - REPOSICION EN VOLUNTARIA REC.EJECUTIVA','LE','Anulación deuda',7,'Reposición Recaudación') timo ON CAST(timo.cod_operacion AS varchar)=oper.opeoper
           WHERE
             oper.opeenti='DF'
             AND oper.opeejer=(SELECT max(opeejer) AS expr1
             FROM dbn1_stg_dhyf_u.dbo.tbn1oper_ti
             )
           GROUP BY
             oper.opeoper,
             oper.opedesc,
             CASE WHEN oper.opesign='R' THEN -1 ELSE 1 END,
             oper.opesign,
             CASE WHEN oper.opesign IN ('R','S') OR opeoper='2005' THEN 1 ELSE 0 END,
             CASE
                 WHEN left(oper.opeoper,1)='1' THEN 'Ingresado'
                 WHEN (left(oper.opeoper,1)='2' AND CASE WHEN oper.opesign IN ('R','S') OR opeoper='2005' THEN 1 ELSE 0 END=1) OR left(oper.opeoper,2)='40' THEN 'Contraído'
                 WHEN (left(oper.opeoper,1)='3' AND left(oper.opeoper,2)<>'39') OR left(oper.opeoper,2)='41' THEN 'Anulado'
                 ELSE 'Resto'
             END,
             CASE
                 WHEN CASE
                     WHEN left(oper.opeoper,1)='1' THEN 'Ingresado'
                     WHEN (left(oper.opeoper,1)='2' AND CASE WHEN oper.opesign IN ('R','S') OR opeoper='2005' THEN 1 ELSE 0 END=1) OR left(oper.opeoper,2)='40' THEN 'Contraído'
                     WHEN (left(oper.opeoper,1)='3' AND left(oper.opeoper,2)<>'39') OR left(oper.opeoper,2)='41' THEN 'Anulado'
                     ELSE 'Resto'
                 END='Ingresado' THEN 1
                 WHEN CASE
                     WHEN left(oper.opeoper,1)='1' THEN 'Ingresado'
                     WHEN (left(oper.opeoper,1)='2' AND CASE WHEN oper.opesign IN ('R','S') OR opeoper='2005' THEN 1 ELSE 0 END=1) OR left(oper.opeoper,2)='40' THEN 'Contraído'
                     WHEN (left(oper.opeoper,1)='3' AND left(oper.opeoper,2)<>'39') OR left(oper.opeoper,2)='41' THEN 'Anulado'
                     ELSE 'Resto'
                 END='Contraído' THEN 2
                 WHEN CASE
                     WHEN left(oper.opeoper,1)='1' THEN 'Ingresado'
                     WHEN (left(oper.opeoper,1)='2' AND CASE WHEN oper.opesign IN ('R','S') OR opeoper='2005' THEN 1 ELSE 0 END=1) OR left(oper.opeoper,2)='40' THEN 'Contraído'
                     WHEN (left(oper.opeoper,1)='3' AND left(oper.opeoper,2)<>'39') OR left(oper.opeoper,2)='41' THEN 'Anulado'
                     ELSE 'Resto'
                 END='Anulado' THEN 3
                 ELSE 4
             END,
             coalesce(timo.clasificacion,'Indefinido'),
             coalesce(timo.cod_subclasificacion,0),
             coalesce(timo.subclasificacion,'Indefinido'),
             coalesce(timo.estado,'')) maestro
       FULL JOIN
           (SELECT
             mov.concoper AS codigo_operacion,
             'Código de operación faltante en Maestro' AS descripcion,
             1 AS cuenta_para_pendiente,
             CASE
                 WHEN left(mov.concoper,1)='1' THEN 'Ingresado'
                 WHEN (left(mov.concoper,1)='2' AND 1=1) OR left(mov.concoper,2)='40' THEN 'Contraído'
                 WHEN (left(mov.concoper,1)='3' AND left(mov.concoper,2)<>'39') OR left(mov.concoper,2)='41' THEN 'Anulado'
                 ELSE 'Resto'
             END AS tipo_movimiento,
             CASE
                 WHEN CASE
                     WHEN left(mov.concoper,1)='1' THEN 'Ingresado'
                     WHEN (left(mov.concoper,1)='2' AND 1=1) OR left(mov.concoper,2)='40' THEN 'Contraído'
                     WHEN (left(mov.concoper,1)='3' AND left(mov.concoper,2)<>'39') OR left(mov.concoper,2)='41' THEN 'Anulado'
                     ELSE 'Resto'
                 END='Ingresado' THEN 1
                 WHEN CASE
                     WHEN left(mov.concoper,1)='1' THEN 'Ingresado'
                     WHEN (left(mov.concoper,1)='2' AND 1=1) OR left(mov.concoper,2)='40' THEN 'Contraído'
                     WHEN (left(mov.concoper,1)='3' AND left(mov.concoper,2)<>'39') OR left(mov.concoper,2)='41' THEN 'Anulado'
                     ELSE 'Resto'
                 END='Contraído' THEN 2
                 WHEN CASE
                     WHEN left(mov.concoper,1)='1' THEN 'Ingresado'
                     WHEN (left(mov.concoper,1)='2' AND 1=1) OR left(mov.concoper,2)='40' THEN 'Contraído'
                     WHEN (left(mov.concoper,1)='3' AND left(mov.concoper,2)<>'39') OR left(mov.concoper,2)='41' THEN 'Anulado'
                     ELSE 'Resto'
                 END='Anulado' THEN 3
                 ELSE 4
             END AS cod_tipo_movimiento,
             'S1CONT' AS origen
           FROM dbn1_stg_dhyf_u.dbo.tbn1cont_s1 mov
           LEFT JOIN dbn1_stg_dhyf_u.dbo.tbn1oper_ti oper ON (oper.opeoper=mov.concoper AND opeenti='DF' AND opeejer=(SELECT max(opeejer) AS expr1
           FROM dbn1_stg_dhyf_u.dbo.tbn1oper_ti
           ))
           WHERE oper.opeoper IS NULL
           GROUP BY
             mov.concoper,
             CASE
                 WHEN left(mov.concoper,1)='1' THEN 'Ingresado'
                 WHEN (left(mov.concoper,1)='2' AND 1=1) OR left(mov.concoper,2)='40' THEN 'Contraído'
                 WHEN (left(mov.concoper,1)='3' AND left(mov.concoper,2)<>'39') OR left(mov.concoper,2)='41' THEN 'Anulado'
                 ELSE 'Resto'
             END,
             CASE
                 WHEN CASE
                     WHEN left(mov.concoper,1)='1' THEN 'Ingresado'
                     WHEN (left(mov.concoper,1)='2' AND 1=1) OR left(mov.concoper,2)='40' THEN 'Contraído'
                     WHEN (left(mov.concoper,1)='3' AND left(mov.concoper,2)<>'39') OR left(mov.concoper,2)='41' THEN 'Anulado'
                     ELSE 'Resto'
                 END='Ingresado' THEN 1
                 WHEN CASE
                     WHEN left(mov.concoper,1)='1' THEN 'Ingresado'
                     WHEN (left(mov.concoper,1)='2' AND 1=1) OR left(mov.concoper,2)='40' THEN 'Contraído'
                     WHEN (left(mov.concoper,1)='3' AND left(mov.concoper,2)<>'39') OR left(mov.concoper,2)='41' THEN 'Anulado'
                     ELSE 'Resto'
                 END='Contraído' THEN 2
                 WHEN CASE
                     WHEN left(mov.concoper,1)='1' THEN 'Ingresado'
                     WHEN (left(mov.concoper,1)='2' AND 1=1) OR left(mov.concoper,2)='40' THEN 'Contraído'
                     WHEN (left(mov.concoper,1)='3' AND left(mov.concoper,2)<>'39') OR left(mov.concoper,2)='41' THEN 'Anulado'
                     ELSE 'Resto'
                 END='Anulado' THEN 3
                 ELSE 4
             END) AS movimientos ON (maestro.codigo_operacion=movimientos.codigo_operacion)) a
  )
  MERGE dbn1_norm_dhyf_u.dbo.tbn1_ot_codigos_operacion AS tbn1_ot_codigos_operacion
  USING query ON query.codigo_operacion=tbn1_ot_codigos_operacion.codigo_operacion
  WHEN MATCHED AND (tbn1_ot_codigos_operacion.es_indefinido=0
                    AND (tbn1_ot_codigos_operacion.descripcion<>query.descripcion OR (tbn1_ot_codigos_operacion.descripcion IS NULL AND query.descripcion IS NOT NULL) OR  (tbn1_ot_codigos_operacion.descripcion IS NOT NULL AND query.descripcion IS NULL)
                    OR tbn1_ot_codigos_operacion.signo<>query.signo OR (tbn1_ot_codigos_operacion.signo IS NULL AND query.signo IS NOT NULL) OR  (tbn1_ot_codigos_operacion.signo IS NOT NULL AND query.signo IS NULL)
                    OR tbn1_ot_codigos_operacion.cod_signo<>query.cod_signo OR (tbn1_ot_codigos_operacion.cod_signo IS NULL AND query.cod_signo IS NOT NULL) OR  (tbn1_ot_codigos_operacion.cod_signo IS NOT NULL AND query.cod_signo IS NULL)
                    OR tbn1_ot_codigos_operacion.cuenta_para_pendiente<>query.cuenta_para_pendiente OR (tbn1_ot_codigos_operacion.cuenta_para_pendiente IS NULL AND query.cuenta_para_pendiente IS NOT NULL) OR  (tbn1_ot_codigos_operacion.cuenta_para_pendiente IS NOT NULL AND query.cuenta_para_pendiente IS NULL)
                    OR tbn1_ot_codigos_operacion.tipo_movimiento<>query.tipo_movimiento OR (tbn1_ot_codigos_operacion.tipo_movimiento IS NULL AND query.tipo_movimiento IS NOT NULL) OR  (tbn1_ot_codigos_operacion.tipo_movimiento IS NOT NULL AND query.tipo_movimiento IS NULL)
                    OR tbn1_ot_codigos_operacion.cod_tipo_movimiento<>query.cod_tipo_movimiento OR (tbn1_ot_codigos_operacion.cod_tipo_movimiento IS NULL AND query.cod_tipo_movimiento IS NOT NULL) OR  (tbn1_ot_codigos_operacion.cod_tipo_movimiento IS NOT NULL AND query.cod_tipo_movimiento IS NULL)
                    OR tbn1_ot_codigos_operacion.clasificacion<>query.clasificacion OR (tbn1_ot_codigos_operacion.clasificacion IS NULL AND query.clasificacion IS NOT NULL) OR  (tbn1_ot_codigos_operacion.clasificacion IS NOT NULL AND query.clasificacion IS NULL)
                    OR tbn1_ot_codigos_operacion.cod_subclasificacion<>query.cod_subclasificacion OR (tbn1_ot_codigos_operacion.cod_subclasificacion IS NULL AND query.cod_subclasificacion IS NOT NULL) OR  (tbn1_ot_codigos_operacion.cod_subclasificacion IS NOT NULL AND query.cod_subclasificacion IS NULL)
                    OR tbn1_ot_codigos_operacion.subclasificacion<>query.subclasificacion OR (tbn1_ot_codigos_operacion.subclasificacion IS NULL AND query.subclasificacion IS NOT NULL) OR  (tbn1_ot_codigos_operacion.subclasificacion IS NOT NULL AND query.subclasificacion IS NULL)
                    OR tbn1_ot_codigos_operacion.estado<>query.estado OR (tbn1_ot_codigos_operacion.estado IS NULL AND query.estado IS NOT NULL) OR  (tbn1_ot_codigos_operacion.estado IS NOT NULL AND query.estado IS NULL)
                    OR tbn1_ot_codigos_operacion.origen<>query.origen OR (tbn1_ot_codigos_operacion.origen IS NULL AND query.origen IS NOT NULL) OR  (tbn1_ot_codigos_operacion.origen IS NOT NULL AND query.origen IS NULL)
                    OR (fec_baja IS NOT NULL))) THEN
    UPDATE SET
      descripcion=query.descripcion,
      signo=query.signo,
      cod_signo=query.cod_signo,
      cuenta_para_pendiente=query.cuenta_para_pendiente,
      tipo_movimiento=query.tipo_movimiento,
      cod_tipo_movimiento=query.cod_tipo_movimiento,
      clasificacion=query.clasificacion,
      cod_subclasificacion=query.cod_subclasificacion,
      subclasificacion=query.subclasificacion,
      estado=query.estado,
      origen=query.origen,
      fec_modificacion=getdate(),
      fec_baja=null
  WHEN NOT MATCHED THEN
    INSERT (codigo_operacion,descripcion,signo,cod_signo,cuenta_para_pendiente,tipo_movimiento,cod_tipo_movimiento,clasificacion,cod_subclasificacion,subclasificacion,estado,origen,fec_alta,fec_modificacion) VALUES (
      query.codigo_operacion,
      query.descripcion,
      query.signo,
      query.cod_signo,
      query.cuenta_para_pendiente,
      query.tipo_movimiento,
      query.cod_tipo_movimiento,
      query.clasificacion,
      query.cod_subclasificacion,
      query.subclasificacion,
      query.estado,
      query.origen,
      getdate(),
      getdate())
  WHEN NOT MATCHED BY SOURCE AND (tbn1_ot_codigos_operacion.es_indefinido=0
                                  AND fec_baja IS NULL) THEN
    UPDATE SET
      fec_baja=getdate(),
      fec_modificacion=getdate();

  EXECUTE dbn1_stg_dhyf_u.dbo.spn1_finalizar_log @log,@@ROWCOUNT;
   END TRY
  BEGIN CATCH
    EXECUTE dbn1_stg_dhyf_u.dbo.spn1_finalizar_log @log,null;
    UPDATE dbn1_norm_dhyf_u.audit.tbn1_logs SET
      mensaje_error=error_message(),
      procedimiento_error=error_procedure()
    WHERE
      id_log=@log;
    IF @continuar_en_caso_error=0 OR @logpadre IS NULL THROW
  END CATCH


END

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_tipos_compensacion')
CREATE TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_compensacion(
  id_tipo_compensacion int IDENTITY(1,1),
  tipo_compensacion varchar(2) NOT NULL,
  des_tipo_compensacion varchar(50) NOT NULL,
  es_indefinido bit,
  fec_alta datetime,
  fec_modificacion datetime,
  fec_baja datetime,
  CONSTRAINT uk_ot_tipos_compensacion UNIQUE (tipo_compensacion),
  CONSTRAINT PK_tbn1_ot_tipos_compensacion PRIMARY KEY CLUSTERED (id_tipo_compensacion)
)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_tipos_compensacion' AND COLUMN_NAME='id_tipo_compensacion')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_compensacion ADD id_tipo_compensacion int

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_tipos_compensacion' AND COLUMN_NAME='tipo_compensacion')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_compensacion ADD tipo_compensacion varchar(2)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_tipos_compensacion' AND COLUMN_NAME='des_tipo_compensacion')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_compensacion ADD des_tipo_compensacion varchar(50)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_tipos_compensacion' AND COLUMN_NAME='es_indefinido')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_compensacion ADD es_indefinido bit

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_tipos_compensacion' AND COLUMN_NAME='fec_alta')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_compensacion ADD fec_alta datetime

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_tipos_compensacion' AND COLUMN_NAME='fec_modificacion')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_compensacion ADD fec_modificacion datetime

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_tipos_compensacion' AND COLUMN_NAME='fec_baja')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_compensacion ADD fec_baja datetime

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_tipos_compensacion' AND COLUMN_NAME='es_indefinido' AND COLUMN_DEFAULT IS NULL)
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_compensacion ADD CONSTRAINT DF_DBO_TBN1_OT_TIPOS_COMPENSACION_ES_INDEFINIDO DEFAULT 0 FOR es_indefinido

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_tipos_compensacion' AND COLUMN_NAME='id_tipo_compensacion' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_compensacion ALTER COLUMN id_tipo_compensacion int NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_tipos_compensacion' AND COLUMN_NAME='tipo_compensacion' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_compensacion ALTER COLUMN tipo_compensacion varchar(2) NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_tipos_compensacion' AND COLUMN_NAME='des_tipo_compensacion' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_compensacion ALTER COLUMN des_tipo_compensacion varchar(50) NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_tipos_compensacion' AND COLUMN_NAME='es_indefinido' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_compensacion ALTER COLUMN es_indefinido bit NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_tipos_compensacion' AND COLUMN_NAME='fec_alta' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_compensacion ALTER COLUMN fec_alta datetime NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_tipos_compensacion' AND COLUMN_NAME='fec_modificacion' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_compensacion ALTER COLUMN fec_modificacion datetime NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_tipos_compensacion' AND COLUMN_NAME='fec_baja' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_compensacion ALTER COLUMN fec_baja datetime NULL

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_tipos_compensacion' AND CONSTRAINT_NAME='PK_tbn1_ot_tipos_compensacion')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_compensacion ADD CONSTRAINT PK_tbn1_ot_tipos_compensacion PRIMARY KEY CLUSTERED (id_tipo_compensacion)

GO

;WITH
query AS (
  SELECT 1 AS es_indefinido,'ZZ' AS tipo_compensacion,'Indefinido' AS des_tipo_compensacion
)
MERGE dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_compensacion AS tbn1_ot_tipos_compensacion
USING query ON query.es_indefinido=tbn1_ot_tipos_compensacion.es_indefinido
WHEN MATCHED AND ((tbn1_ot_tipos_compensacion.tipo_compensacion<>query.tipo_compensacion OR (tbn1_ot_tipos_compensacion.tipo_compensacion IS NULL AND query.tipo_compensacion IS NOT NULL) OR  (tbn1_ot_tipos_compensacion.tipo_compensacion IS NOT NULL AND query.tipo_compensacion IS NULL)
                  OR tbn1_ot_tipos_compensacion.des_tipo_compensacion<>query.des_tipo_compensacion OR (tbn1_ot_tipos_compensacion.des_tipo_compensacion IS NULL AND query.des_tipo_compensacion IS NOT NULL) OR  (tbn1_ot_tipos_compensacion.des_tipo_compensacion IS NOT NULL AND query.des_tipo_compensacion IS NULL))) THEN
  UPDATE SET
    tipo_compensacion=query.tipo_compensacion,
    des_tipo_compensacion=query.des_tipo_compensacion
WHEN NOT MATCHED THEN
  INSERT (es_indefinido,tipo_compensacion,des_tipo_compensacion) VALUES (
    query.es_indefinido,
    query.tipo_compensacion,
    query.des_tipo_compensacion);
GO

USE dbn1_stg_dhyf_u
GO

IF EXISTS (SELECT 1 FROM dbn1_stg_dhyf_u.INFORMATION_SCHEMA.ROUTINES WHERE ROUTINE_SCHEMA='dbo' AND ROUTINE_NAME='spn1_cargar_normalizado_ot_tipos_compensacion' AND ROUTINE_TYPE='PROCEDURE')
DROP PROCEDURE dbo.spn1_cargar_normalizado_ot_tipos_compensacion;
GO

CREATE PROCEDURE dbo.spn1_cargar_normalizado_ot_tipos_compensacion(@logpadre int) AS
BEGIN

  DECLARE @procedure_name varchar(100)='dbn1_stg_dhyf_u.dbo.spn1_cargar_normalizado_ot_tipos_compensacion'
  SET NOCOUNT ON;
  DECLARE @log int;
  EXECUTE @log = dbn1_stg_dhyf_u.dbo.spn1_apuntar_log @logpadre,@procedure_name;
  DECLARE @fecha_ultima_carga datetime=dbn1_stg_dhyf_u.dbo.fnn1_fecha_ultima_carga(@log);
  DECLARE @continuar_en_caso_error bit=0;
  IF @logpadre IS NOT NULL AND EXISTS (SELECT 1 AS expr1
  FROM dbn1_norm_dhyf_u.audit.tbn1_procedimientos_excluidos
  WHERE
    'dbn1_stg_dhyf_u.dbo.'+procedimiento=@procedure_name
    AND excluido=1
  ) BEGIN
    UPDATE dbn1_norm_dhyf_u.audit.tbn1_logs SET
      mensaje_error='EXCLUÍDO'
    WHERE
      id_log=@log;
    RETURN
  END
     BEGIN TRY

  ;WITH
  query AS (
    SELECT
      right('0'+CAST(tcom.tipo_compensacion AS varchar),2) AS tipo_compensacion,
      tcom.des_tipo_compensacion AS des_tipo_compensacion
    FROM
      (SELECT 0 tipo_compensacion,'No tiene compensación' des_tipo_compensacion
       UNION ALL SELECT 10,'Tiene compensación'
       UNION ALL SELECT 20,'Embargo y Compensación'
       UNION ALL SELECT 30,'Embargo') tcom
  )
  MERGE dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_compensacion AS tbn1_ot_tipos_compensacion
  USING query ON query.tipo_compensacion=tbn1_ot_tipos_compensacion.tipo_compensacion
  WHEN MATCHED AND (tbn1_ot_tipos_compensacion.es_indefinido=0
                    AND (tbn1_ot_tipos_compensacion.des_tipo_compensacion<>query.des_tipo_compensacion OR (tbn1_ot_tipos_compensacion.des_tipo_compensacion IS NULL AND query.des_tipo_compensacion IS NOT NULL) OR  (tbn1_ot_tipos_compensacion.des_tipo_compensacion IS NOT NULL AND query.des_tipo_compensacion IS NULL)
                    OR (fec_baja IS NOT NULL))) THEN
    UPDATE SET
      des_tipo_compensacion=query.des_tipo_compensacion,
      fec_modificacion=getdate(),
      fec_baja=null
  WHEN NOT MATCHED THEN
    INSERT (tipo_compensacion,des_tipo_compensacion,fec_alta,fec_modificacion) VALUES (
      query.tipo_compensacion,
      query.des_tipo_compensacion,
      getdate(),
      getdate())
  WHEN NOT MATCHED BY SOURCE AND (tbn1_ot_tipos_compensacion.es_indefinido=0
                                  AND fec_baja IS NULL) THEN
    UPDATE SET
      fec_baja=getdate(),
      fec_modificacion=getdate();

  EXECUTE dbn1_stg_dhyf_u.dbo.spn1_finalizar_log @log,@@ROWCOUNT;
   END TRY
  BEGIN CATCH
    EXECUTE dbn1_stg_dhyf_u.dbo.spn1_finalizar_log @log,null;
    UPDATE dbn1_norm_dhyf_u.audit.tbn1_logs SET
      mensaje_error=error_message(),
      procedimiento_error=error_procedure()
    WHERE
      id_log=@log;
    IF @continuar_en_caso_error=0 OR @logpadre IS NULL THROW
  END CATCH


END

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_tipos_responsable')
CREATE TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_responsable(
  id_tipo_responsable int IDENTITY(1,1),
  tipo_responsable varchar(2) NOT NULL,
  des_tipo_responsable varchar(50) NOT NULL,
  es_indefinido bit,
  fec_alta datetime,
  fec_modificacion datetime,
  fec_baja datetime,
  CONSTRAINT uk_ot_tipos_responsable UNIQUE (tipo_responsable),
  CONSTRAINT PK_tbn1_ot_tipos_responsable PRIMARY KEY CLUSTERED (id_tipo_responsable)
)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_tipos_responsable' AND COLUMN_NAME='id_tipo_responsable')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_responsable ADD id_tipo_responsable int

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_tipos_responsable' AND COLUMN_NAME='tipo_responsable')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_responsable ADD tipo_responsable varchar(2)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_tipos_responsable' AND COLUMN_NAME='des_tipo_responsable')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_responsable ADD des_tipo_responsable varchar(50)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_tipos_responsable' AND COLUMN_NAME='es_indefinido')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_responsable ADD es_indefinido bit

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_tipos_responsable' AND COLUMN_NAME='fec_alta')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_responsable ADD fec_alta datetime

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_tipos_responsable' AND COLUMN_NAME='fec_modificacion')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_responsable ADD fec_modificacion datetime

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_tipos_responsable' AND COLUMN_NAME='fec_baja')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_responsable ADD fec_baja datetime

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_tipos_responsable' AND COLUMN_NAME='es_indefinido' AND COLUMN_DEFAULT IS NULL)
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_responsable ADD CONSTRAINT DF_DBO_TBN1_OT_TIPOS_RESPONSABLE_ES_INDEFINIDO DEFAULT 0 FOR es_indefinido

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_tipos_responsable' AND COLUMN_NAME='id_tipo_responsable' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_responsable ALTER COLUMN id_tipo_responsable int NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_tipos_responsable' AND COLUMN_NAME='tipo_responsable' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_responsable ALTER COLUMN tipo_responsable varchar(2) NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_tipos_responsable' AND COLUMN_NAME='des_tipo_responsable' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_responsable ALTER COLUMN des_tipo_responsable varchar(50) NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_tipos_responsable' AND COLUMN_NAME='es_indefinido' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_responsable ALTER COLUMN es_indefinido bit NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_tipos_responsable' AND COLUMN_NAME='fec_alta' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_responsable ALTER COLUMN fec_alta datetime NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_tipos_responsable' AND COLUMN_NAME='fec_modificacion' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_responsable ALTER COLUMN fec_modificacion datetime NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_tipos_responsable' AND COLUMN_NAME='fec_baja' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_responsable ALTER COLUMN fec_baja datetime NULL

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_tipos_responsable' AND CONSTRAINT_NAME='PK_tbn1_ot_tipos_responsable')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_responsable ADD CONSTRAINT PK_tbn1_ot_tipos_responsable PRIMARY KEY CLUSTERED (id_tipo_responsable)

GO

;WITH
query AS (
  SELECT 1 AS es_indefinido,'ZZ' AS tipo_responsable,'Indefinido' AS des_tipo_responsable
)
MERGE dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_responsable AS tbn1_ot_tipos_responsable
USING query ON query.es_indefinido=tbn1_ot_tipos_responsable.es_indefinido
WHEN MATCHED AND ((tbn1_ot_tipos_responsable.tipo_responsable<>query.tipo_responsable OR (tbn1_ot_tipos_responsable.tipo_responsable IS NULL AND query.tipo_responsable IS NOT NULL) OR  (tbn1_ot_tipos_responsable.tipo_responsable IS NOT NULL AND query.tipo_responsable IS NULL)
                  OR tbn1_ot_tipos_responsable.des_tipo_responsable<>query.des_tipo_responsable OR (tbn1_ot_tipos_responsable.des_tipo_responsable IS NULL AND query.des_tipo_responsable IS NOT NULL) OR  (tbn1_ot_tipos_responsable.des_tipo_responsable IS NOT NULL AND query.des_tipo_responsable IS NULL))) THEN
  UPDATE SET
    tipo_responsable=query.tipo_responsable,
    des_tipo_responsable=query.des_tipo_responsable
WHEN NOT MATCHED THEN
  INSERT (es_indefinido,tipo_responsable,des_tipo_responsable) VALUES (
    query.es_indefinido,
    query.tipo_responsable,
    query.des_tipo_responsable);
GO

USE dbn1_stg_dhyf_u
GO

IF EXISTS (SELECT 1 FROM dbn1_stg_dhyf_u.INFORMATION_SCHEMA.ROUTINES WHERE ROUTINE_SCHEMA='dbo' AND ROUTINE_NAME='spn1_cargar_normalizado_ot_tipos_responsable' AND ROUTINE_TYPE='PROCEDURE')
DROP PROCEDURE dbo.spn1_cargar_normalizado_ot_tipos_responsable;
GO

CREATE PROCEDURE dbo.spn1_cargar_normalizado_ot_tipos_responsable(@logpadre int) AS
BEGIN

  DECLARE @procedure_name varchar(100)='dbn1_stg_dhyf_u.dbo.spn1_cargar_normalizado_ot_tipos_responsable'
  SET NOCOUNT ON;
  DECLARE @log int;
  EXECUTE @log = dbn1_stg_dhyf_u.dbo.spn1_apuntar_log @logpadre,@procedure_name;
  DECLARE @fecha_ultima_carga datetime=dbn1_stg_dhyf_u.dbo.fnn1_fecha_ultima_carga(@log);
  DECLARE @continuar_en_caso_error bit=0;
  IF @logpadre IS NOT NULL AND EXISTS (SELECT 1 AS expr1
  FROM dbn1_norm_dhyf_u.audit.tbn1_procedimientos_excluidos
  WHERE
    'dbn1_stg_dhyf_u.dbo.'+procedimiento=@procedure_name
    AND excluido=1
  ) BEGIN
    UPDATE dbn1_norm_dhyf_u.audit.tbn1_logs SET
      mensaje_error='EXCLUÍDO'
    WHERE
      id_log=@log;
    RETURN
  END
     BEGIN TRY

  ;WITH
  query AS (
    SELECT
      right('0'+CAST(tres.tipo_responsable AS varchar),2) AS tipo_responsable,
      tres.des_tipo_responsable AS des_tipo_responsable
    FROM
      (SELECT 0 tipo_responsable,'Obligado' des_tipo_responsable
       UNION ALL SELECT 11,'Autoliquidacion conjunta en irpf'
       UNION ALL SELECT 12,'Grupos fiscales impuesto sobre sociedad'
       UNION ALL SELECT 13,'Régimen especial grupo sociedades en iva'
       UNION ALL SELECT 20,'Herencia yacente'
       UNION ALL SELECT 21,'Fallecimiento del obligado principal'
       UNION ALL SELECT 31,'Absorción de empresa'
       UNION ALL SELECT 32,'Régimen ganancial') tres
  )
  MERGE dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_responsable AS tbn1_ot_tipos_responsable
  USING query ON query.tipo_responsable=tbn1_ot_tipos_responsable.tipo_responsable
  WHEN MATCHED AND (tbn1_ot_tipos_responsable.es_indefinido=0
                    AND (tbn1_ot_tipos_responsable.des_tipo_responsable<>query.des_tipo_responsable OR (tbn1_ot_tipos_responsable.des_tipo_responsable IS NULL AND query.des_tipo_responsable IS NOT NULL) OR  (tbn1_ot_tipos_responsable.des_tipo_responsable IS NOT NULL AND query.des_tipo_responsable IS NULL)
                    OR (fec_baja IS NOT NULL))) THEN
    UPDATE SET
      des_tipo_responsable=query.des_tipo_responsable,
      fec_modificacion=getdate(),
      fec_baja=null
  WHEN NOT MATCHED THEN
    INSERT (tipo_responsable,des_tipo_responsable,fec_alta,fec_modificacion) VALUES (
      query.tipo_responsable,
      query.des_tipo_responsable,
      getdate(),
      getdate())
  WHEN NOT MATCHED BY SOURCE AND (tbn1_ot_tipos_responsable.es_indefinido=0
                                  AND fec_baja IS NULL) THEN
    UPDATE SET
      fec_baja=getdate(),
      fec_modificacion=getdate();

  EXECUTE dbn1_stg_dhyf_u.dbo.spn1_finalizar_log @log,@@ROWCOUNT;
   END TRY
  BEGIN CATCH
    EXECUTE dbn1_stg_dhyf_u.dbo.spn1_finalizar_log @log,null;
    UPDATE dbn1_norm_dhyf_u.audit.tbn1_logs SET
      mensaje_error=error_message(),
      procedimiento_error=error_procedure()
    WHERE
      id_log=@log;
    IF @continuar_en_caso_error=0 OR @logpadre IS NULL THROW
  END CATCH


END

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_fases_proceso')
CREATE TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_fases_proceso(
  id_fase_proceso int IDENTITY(1,1),
  fase_proceso varchar(2) NOT NULL,
  des_fase_proceso varchar(50) NOT NULL,
  es_indefinido bit,
  fec_alta datetime,
  fec_modificacion datetime,
  fec_baja datetime,
  CONSTRAINT uk_ot_fases_proceso UNIQUE (fase_proceso),
  CONSTRAINT PK_tbn1_ot_fases_proceso PRIMARY KEY CLUSTERED (id_fase_proceso)
)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_fases_proceso' AND COLUMN_NAME='id_fase_proceso')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_fases_proceso ADD id_fase_proceso int

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_fases_proceso' AND COLUMN_NAME='fase_proceso')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_fases_proceso ADD fase_proceso varchar(2)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_fases_proceso' AND COLUMN_NAME='des_fase_proceso')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_fases_proceso ADD des_fase_proceso varchar(50)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_fases_proceso' AND COLUMN_NAME='es_indefinido')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_fases_proceso ADD es_indefinido bit

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_fases_proceso' AND COLUMN_NAME='fec_alta')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_fases_proceso ADD fec_alta datetime

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_fases_proceso' AND COLUMN_NAME='fec_modificacion')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_fases_proceso ADD fec_modificacion datetime

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_fases_proceso' AND COLUMN_NAME='fec_baja')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_fases_proceso ADD fec_baja datetime

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_fases_proceso' AND COLUMN_NAME='es_indefinido' AND COLUMN_DEFAULT IS NULL)
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_fases_proceso ADD CONSTRAINT DF_DBO_TBN1_OT_FASES_PROCESO_ES_INDEFINIDO DEFAULT 0 FOR es_indefinido

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_fases_proceso' AND COLUMN_NAME='id_fase_proceso' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_fases_proceso ALTER COLUMN id_fase_proceso int NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_fases_proceso' AND COLUMN_NAME='fase_proceso' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_fases_proceso ALTER COLUMN fase_proceso varchar(2) NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_fases_proceso' AND COLUMN_NAME='des_fase_proceso' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_fases_proceso ALTER COLUMN des_fase_proceso varchar(50) NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_fases_proceso' AND COLUMN_NAME='es_indefinido' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_fases_proceso ALTER COLUMN es_indefinido bit NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_fases_proceso' AND COLUMN_NAME='fec_alta' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_fases_proceso ALTER COLUMN fec_alta datetime NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_fases_proceso' AND COLUMN_NAME='fec_modificacion' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_fases_proceso ALTER COLUMN fec_modificacion datetime NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_fases_proceso' AND COLUMN_NAME='fec_baja' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_fases_proceso ALTER COLUMN fec_baja datetime NULL

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_fases_proceso' AND CONSTRAINT_NAME='PK_tbn1_ot_fases_proceso')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_fases_proceso ADD CONSTRAINT PK_tbn1_ot_fases_proceso PRIMARY KEY CLUSTERED (id_fase_proceso)

GO

;WITH
query AS (
  SELECT 1 AS es_indefinido,'ZZ' AS fase_proceso,'Indefinido' AS des_fase_proceso
)
MERGE dbn1_norm_dhyf_u.dbo.tbn1_ot_fases_proceso AS tbn1_ot_fases_proceso
USING query ON query.es_indefinido=tbn1_ot_fases_proceso.es_indefinido
WHEN MATCHED AND ((tbn1_ot_fases_proceso.fase_proceso<>query.fase_proceso OR (tbn1_ot_fases_proceso.fase_proceso IS NULL AND query.fase_proceso IS NOT NULL) OR  (tbn1_ot_fases_proceso.fase_proceso IS NOT NULL AND query.fase_proceso IS NULL)
                  OR tbn1_ot_fases_proceso.des_fase_proceso<>query.des_fase_proceso OR (tbn1_ot_fases_proceso.des_fase_proceso IS NULL AND query.des_fase_proceso IS NOT NULL) OR  (tbn1_ot_fases_proceso.des_fase_proceso IS NOT NULL AND query.des_fase_proceso IS NULL))) THEN
  UPDATE SET
    fase_proceso=query.fase_proceso,
    des_fase_proceso=query.des_fase_proceso
WHEN NOT MATCHED THEN
  INSERT (es_indefinido,fase_proceso,des_fase_proceso) VALUES (
    query.es_indefinido,
    query.fase_proceso,
    query.des_fase_proceso);
GO

USE dbn1_stg_dhyf_u
GO

IF EXISTS (SELECT 1 FROM dbn1_stg_dhyf_u.INFORMATION_SCHEMA.ROUTINES WHERE ROUTINE_SCHEMA='dbo' AND ROUTINE_NAME='spn1_cargar_normalizado_ot_fases_proceso' AND ROUTINE_TYPE='PROCEDURE')
DROP PROCEDURE dbo.spn1_cargar_normalizado_ot_fases_proceso;
GO

CREATE PROCEDURE dbo.spn1_cargar_normalizado_ot_fases_proceso(@logpadre int) AS
BEGIN

  DECLARE @procedure_name varchar(100)='dbn1_stg_dhyf_u.dbo.spn1_cargar_normalizado_ot_fases_proceso'
  SET NOCOUNT ON;
  DECLARE @log int;
  EXECUTE @log = dbn1_stg_dhyf_u.dbo.spn1_apuntar_log @logpadre,@procedure_name;
  DECLARE @fecha_ultima_carga datetime=dbn1_stg_dhyf_u.dbo.fnn1_fecha_ultima_carga(@log);
  DECLARE @continuar_en_caso_error bit=0;
  IF @logpadre IS NOT NULL AND EXISTS (SELECT 1 AS expr1
  FROM dbn1_norm_dhyf_u.audit.tbn1_procedimientos_excluidos
  WHERE
    'dbn1_stg_dhyf_u.dbo.'+procedimiento=@procedure_name
    AND excluido=1
  ) BEGIN
    UPDATE dbn1_norm_dhyf_u.audit.tbn1_logs SET
      mensaje_error='EXCLUÍDO'
    WHERE
      id_log=@log;
    RETURN
  END
     BEGIN TRY

  ;WITH
  query AS (
    SELECT
      right('0'+CAST(fapr.fase_proceso AS varchar),2) AS fase_proceso,
      fapr.des_fase_proceso AS des_fase_proceso
    FROM
      (SELECT 10 fase_proceso,'Generados' des_fase_proceso
       UNION ALL SELECT 20,'Obligados'
       UNION ALL SELECT 90,'Finalizados') fapr
  )
  MERGE dbn1_norm_dhyf_u.dbo.tbn1_ot_fases_proceso AS tbn1_ot_fases_proceso
  USING query ON query.fase_proceso=tbn1_ot_fases_proceso.fase_proceso
  WHEN MATCHED AND (tbn1_ot_fases_proceso.es_indefinido=0
                    AND (tbn1_ot_fases_proceso.des_fase_proceso<>query.des_fase_proceso OR (tbn1_ot_fases_proceso.des_fase_proceso IS NULL AND query.des_fase_proceso IS NOT NULL) OR  (tbn1_ot_fases_proceso.des_fase_proceso IS NOT NULL AND query.des_fase_proceso IS NULL)
                    OR (fec_baja IS NOT NULL))) THEN
    UPDATE SET
      des_fase_proceso=query.des_fase_proceso,
      fec_modificacion=getdate(),
      fec_baja=null
  WHEN NOT MATCHED THEN
    INSERT (fase_proceso,des_fase_proceso,fec_alta,fec_modificacion) VALUES (
      query.fase_proceso,
      query.des_fase_proceso,
      getdate(),
      getdate())
  WHEN NOT MATCHED BY SOURCE AND (tbn1_ot_fases_proceso.es_indefinido=0
                                  AND fec_baja IS NULL) THEN
    UPDATE SET
      fec_baja=getdate(),
      fec_modificacion=getdate();

  EXECUTE dbn1_stg_dhyf_u.dbo.spn1_finalizar_log @log,@@ROWCOUNT;
   END TRY
  BEGIN CATCH
    EXECUTE dbn1_stg_dhyf_u.dbo.spn1_finalizar_log @log,null;
    UPDATE dbn1_norm_dhyf_u.audit.tbn1_logs SET
      mensaje_error=error_message(),
      procedimiento_error=error_procedure()
    WHERE
      id_log=@log;
    IF @continuar_en_caso_error=0 OR @logpadre IS NULL THROW
  END CATCH


END

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_estados')
CREATE TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_estados(
  id_estado int IDENTITY(1,1),
  cod_estado varchar(1) NOT NULL,
  des_estado varchar(20) NOT NULL,
  es_indefinido bit,
  fec_alta datetime,
  fec_modificacion datetime,
  fec_baja datetime,
  CONSTRAINT uk_ot_estados UNIQUE (cod_estado),
  CONSTRAINT PK_tbn1_ot_estados PRIMARY KEY CLUSTERED (id_estado)
)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_estados' AND COLUMN_NAME='id_estado')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_estados ADD id_estado int

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_estados' AND COLUMN_NAME='cod_estado')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_estados ADD cod_estado varchar(1)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_estados' AND COLUMN_NAME='des_estado')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_estados ADD des_estado varchar(20)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_estados' AND COLUMN_NAME='es_indefinido')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_estados ADD es_indefinido bit

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_estados' AND COLUMN_NAME='fec_alta')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_estados ADD fec_alta datetime

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_estados' AND COLUMN_NAME='fec_modificacion')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_estados ADD fec_modificacion datetime

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_estados' AND COLUMN_NAME='fec_baja')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_estados ADD fec_baja datetime

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_estados' AND COLUMN_NAME='es_indefinido' AND COLUMN_DEFAULT IS NULL)
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_estados ADD CONSTRAINT DF_DBO_TBN1_OT_ESTADOS_ES_INDEFINIDO DEFAULT 0 FOR es_indefinido

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_estados' AND COLUMN_NAME='id_estado' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_estados ALTER COLUMN id_estado int NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_estados' AND COLUMN_NAME='cod_estado' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_estados ALTER COLUMN cod_estado varchar(1) NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_estados' AND COLUMN_NAME='des_estado' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_estados ALTER COLUMN des_estado varchar(20) NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_estados' AND COLUMN_NAME='es_indefinido' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_estados ALTER COLUMN es_indefinido bit NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_estados' AND COLUMN_NAME='fec_alta' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_estados ALTER COLUMN fec_alta datetime NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_estados' AND COLUMN_NAME='fec_modificacion' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_estados ALTER COLUMN fec_modificacion datetime NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_estados' AND COLUMN_NAME='fec_baja' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_estados ALTER COLUMN fec_baja datetime NULL

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_estados' AND CONSTRAINT_NAME='PK_tbn1_ot_estados')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_estados ADD CONSTRAINT PK_tbn1_ot_estados PRIMARY KEY CLUSTERED (id_estado)

GO

;WITH
query AS (
  SELECT 1 AS es_indefinido,'Z' AS cod_estado,'No Informado' AS des_estado
)
MERGE dbn1_norm_dhyf_u.dbo.tbn1_ot_estados AS tbn1_ot_estados
USING query ON query.es_indefinido=tbn1_ot_estados.es_indefinido
WHEN MATCHED AND ((tbn1_ot_estados.cod_estado<>query.cod_estado OR (tbn1_ot_estados.cod_estado IS NULL AND query.cod_estado IS NOT NULL) OR  (tbn1_ot_estados.cod_estado IS NOT NULL AND query.cod_estado IS NULL)
                  OR tbn1_ot_estados.des_estado<>query.des_estado OR (tbn1_ot_estados.des_estado IS NULL AND query.des_estado IS NOT NULL) OR  (tbn1_ot_estados.des_estado IS NOT NULL AND query.des_estado IS NULL))) THEN
  UPDATE SET
    cod_estado=query.cod_estado,
    des_estado=query.des_estado
WHEN NOT MATCHED THEN
  INSERT (es_indefinido,cod_estado,des_estado) VALUES (
    query.es_indefinido,
    query.cod_estado,
    query.des_estado);
GO

USE dbn1_stg_dhyf_u
GO

IF EXISTS (SELECT 1 FROM dbn1_stg_dhyf_u.INFORMATION_SCHEMA.ROUTINES WHERE ROUTINE_SCHEMA='dbo' AND ROUTINE_NAME='spn1_cargar_normalizado_ot_estados' AND ROUTINE_TYPE='PROCEDURE')
DROP PROCEDURE dbo.spn1_cargar_normalizado_ot_estados;
GO

CREATE PROCEDURE dbo.spn1_cargar_normalizado_ot_estados(@logpadre int) AS
BEGIN

  DECLARE @procedure_name varchar(100)='dbn1_stg_dhyf_u.dbo.spn1_cargar_normalizado_ot_estados'
  SET NOCOUNT ON;
  DECLARE @log int;
  EXECUTE @log = dbn1_stg_dhyf_u.dbo.spn1_apuntar_log @logpadre,@procedure_name;
  DECLARE @fecha_ultima_carga datetime=dbn1_stg_dhyf_u.dbo.fnn1_fecha_ultima_carga(@log);
  DECLARE @continuar_en_caso_error bit=0;
  IF @logpadre IS NOT NULL AND EXISTS (SELECT 1 AS expr1
  FROM dbn1_norm_dhyf_u.audit.tbn1_procedimientos_excluidos
  WHERE
    'dbn1_stg_dhyf_u.dbo.'+procedimiento=@procedure_name
    AND excluido=1
  ) BEGIN
    UPDATE dbn1_norm_dhyf_u.audit.tbn1_logs SET
      mensaje_error='EXCLUÍDO'
    WHERE
      id_log=@log;
    RETURN
  END
     BEGIN TRY

  ;WITH
  query AS (
    SELECT
      est.cod_estado AS cod_estado,
      des_estado
    FROM
      (SELECT 'E' cod_estado,'Ejecutivo' des_estado
       UNION ALL SELECT 'V','Voluntario') est
    GROUP BY
      est.cod_estado,
      des_estado
  )
  MERGE dbn1_norm_dhyf_u.dbo.tbn1_ot_estados AS tbn1_ot_estados
  USING query ON query.cod_estado=tbn1_ot_estados.cod_estado
  WHEN MATCHED AND (tbn1_ot_estados.es_indefinido=0
                    AND (tbn1_ot_estados.des_estado<>query.des_estado OR (tbn1_ot_estados.des_estado IS NULL AND query.des_estado IS NOT NULL) OR  (tbn1_ot_estados.des_estado IS NOT NULL AND query.des_estado IS NULL)
                    OR (fec_baja IS NOT NULL))) THEN
    UPDATE SET
      des_estado=query.des_estado,
      fec_modificacion=getdate(),
      fec_baja=null
  WHEN NOT MATCHED THEN
    INSERT (cod_estado,des_estado,fec_alta,fec_modificacion) VALUES (
      query.cod_estado,
      query.des_estado,
      getdate(),
      getdate())
  WHEN NOT MATCHED BY SOURCE AND (tbn1_ot_estados.es_indefinido=0
                                  AND fec_baja IS NULL) THEN
    UPDATE SET
      fec_baja=getdate(),
      fec_modificacion=getdate();

  EXECUTE dbn1_stg_dhyf_u.dbo.spn1_finalizar_log @log,@@ROWCOUNT;
   END TRY
  BEGIN CATCH
    EXECUTE dbn1_stg_dhyf_u.dbo.spn1_finalizar_log @log,null;
    UPDATE dbn1_norm_dhyf_u.audit.tbn1_logs SET
      mensaje_error=error_message(),
      procedimiento_error=error_procedure()
    WHERE
      id_log=@log;
    IF @continuar_en_caso_error=0 OR @logpadre IS NULL THROW
  END CATCH


END

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_oficinas')
CREATE TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_oficinas(
  id_oficina int IDENTITY(1,1),
  cod_oficina varchar(4) NOT NULL,
  des_oficina varchar(50) NOT NULL,
  cod_grupo_oficina int NOT NULL,
  grupo_oficina varchar(30) NOT NULL,
  es_indefinido bit,
  fec_alta datetime,
  fec_modificacion datetime,
  fec_baja datetime,
  CONSTRAINT uk_ot_oficinas UNIQUE (cod_oficina),
  CONSTRAINT PK_tbn1_ot_oficinas PRIMARY KEY CLUSTERED (id_oficina)
)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_oficinas' AND COLUMN_NAME='id_oficina')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_oficinas ADD id_oficina int

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_oficinas' AND COLUMN_NAME='cod_oficina')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_oficinas ADD cod_oficina varchar(4)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_oficinas' AND COLUMN_NAME='des_oficina')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_oficinas ADD des_oficina varchar(50)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_oficinas' AND COLUMN_NAME='cod_grupo_oficina')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_oficinas ADD cod_grupo_oficina int

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_oficinas' AND COLUMN_NAME='grupo_oficina')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_oficinas ADD grupo_oficina varchar(30)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_oficinas' AND COLUMN_NAME='es_indefinido')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_oficinas ADD es_indefinido bit

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_oficinas' AND COLUMN_NAME='fec_alta')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_oficinas ADD fec_alta datetime

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_oficinas' AND COLUMN_NAME='fec_modificacion')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_oficinas ADD fec_modificacion datetime

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_oficinas' AND COLUMN_NAME='fec_baja')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_oficinas ADD fec_baja datetime

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_oficinas' AND COLUMN_NAME='cod_grupo_oficina' AND COLUMN_DEFAULT IS NULL)
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_oficinas ADD CONSTRAINT DF_DBO_TBN1_OT_OFICINAS_COD_GRUPO_OFICINA DEFAULT 0 FOR cod_grupo_oficina

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_oficinas' AND COLUMN_NAME='grupo_oficina' AND COLUMN_DEFAULT IS NULL)
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_oficinas ADD CONSTRAINT DF_DBO_TBN1_OT_OFICINAS_GRUPO_OFICINA DEFAULT '' FOR grupo_oficina

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_oficinas' AND COLUMN_NAME='es_indefinido' AND COLUMN_DEFAULT IS NULL)
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_oficinas ADD CONSTRAINT DF_DBO_TBN1_OT_OFICINAS_ES_INDEFINIDO DEFAULT 0 FOR es_indefinido

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_oficinas' AND COLUMN_NAME='id_oficina' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_oficinas ALTER COLUMN id_oficina int NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_oficinas' AND COLUMN_NAME='cod_oficina' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_oficinas ALTER COLUMN cod_oficina varchar(4) NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_oficinas' AND COLUMN_NAME='des_oficina' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_oficinas ALTER COLUMN des_oficina varchar(50) NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_oficinas' AND COLUMN_NAME='cod_grupo_oficina' AND IS_NULLABLE='YES')
BEGIN
  UPDATE dbn1_norm_dhyf_u.dbo.tbn1_ot_oficinas SET cod_grupo_oficina=0 WHERE cod_grupo_oficina IS NULL
  ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_oficinas ALTER COLUMN cod_grupo_oficina int NOT NULL
END

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_oficinas' AND COLUMN_NAME='grupo_oficina' AND IS_NULLABLE='YES')
BEGIN
  UPDATE dbn1_norm_dhyf_u.dbo.tbn1_ot_oficinas SET grupo_oficina='' WHERE grupo_oficina IS NULL
  ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_oficinas ALTER COLUMN grupo_oficina varchar(30) NOT NULL
END

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_oficinas' AND COLUMN_NAME='es_indefinido' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_oficinas ALTER COLUMN es_indefinido bit NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_oficinas' AND COLUMN_NAME='fec_alta' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_oficinas ALTER COLUMN fec_alta datetime NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_oficinas' AND COLUMN_NAME='fec_modificacion' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_oficinas ALTER COLUMN fec_modificacion datetime NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_oficinas' AND COLUMN_NAME='fec_baja' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_oficinas ALTER COLUMN fec_baja datetime NULL

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_oficinas' AND CONSTRAINT_NAME='PK_tbn1_ot_oficinas')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_oficinas ADD CONSTRAINT PK_tbn1_ot_oficinas PRIMARY KEY CLUSTERED (id_oficina)

GO

;WITH
query AS (
  SELECT 1 AS es_indefinido,'ZZZZ' AS cod_oficina,'Otras' AS des_oficina,0 AS cod_grupo_oficina,'OTRAS' AS grupo_oficina
)
MERGE dbn1_norm_dhyf_u.dbo.tbn1_ot_oficinas AS tbn1_ot_oficinas
USING query ON query.es_indefinido=tbn1_ot_oficinas.es_indefinido
WHEN MATCHED AND ((tbn1_ot_oficinas.cod_oficina<>query.cod_oficina OR (tbn1_ot_oficinas.cod_oficina IS NULL AND query.cod_oficina IS NOT NULL) OR  (tbn1_ot_oficinas.cod_oficina IS NOT NULL AND query.cod_oficina IS NULL)
                  OR tbn1_ot_oficinas.des_oficina<>query.des_oficina OR (tbn1_ot_oficinas.des_oficina IS NULL AND query.des_oficina IS NOT NULL) OR  (tbn1_ot_oficinas.des_oficina IS NOT NULL AND query.des_oficina IS NULL)
                  OR tbn1_ot_oficinas.cod_grupo_oficina<>query.cod_grupo_oficina OR (tbn1_ot_oficinas.cod_grupo_oficina IS NULL AND query.cod_grupo_oficina IS NOT NULL) OR  (tbn1_ot_oficinas.cod_grupo_oficina IS NOT NULL AND query.cod_grupo_oficina IS NULL)
                  OR tbn1_ot_oficinas.grupo_oficina<>query.grupo_oficina OR (tbn1_ot_oficinas.grupo_oficina IS NULL AND query.grupo_oficina IS NOT NULL) OR  (tbn1_ot_oficinas.grupo_oficina IS NOT NULL AND query.grupo_oficina IS NULL))) THEN
  UPDATE SET
    cod_oficina=query.cod_oficina,
    des_oficina=query.des_oficina,
    cod_grupo_oficina=query.cod_grupo_oficina,
    grupo_oficina=query.grupo_oficina
WHEN NOT MATCHED THEN
  INSERT (es_indefinido,cod_oficina,des_oficina,cod_grupo_oficina,grupo_oficina) VALUES (
    query.es_indefinido,
    query.cod_oficina,
    query.des_oficina,
    query.cod_grupo_oficina,
    query.grupo_oficina);
GO

USE dbn1_stg_dhyf_u
GO

IF EXISTS (SELECT 1 FROM dbn1_stg_dhyf_u.INFORMATION_SCHEMA.ROUTINES WHERE ROUTINE_SCHEMA='dbo' AND ROUTINE_NAME='spn1_cargar_normalizado_ot_oficinas' AND ROUTINE_TYPE='PROCEDURE')
DROP PROCEDURE dbo.spn1_cargar_normalizado_ot_oficinas;
GO

CREATE PROCEDURE dbo.spn1_cargar_normalizado_ot_oficinas(@logpadre int) AS
BEGIN

  DECLARE @procedure_name varchar(100)='dbn1_stg_dhyf_u.dbo.spn1_cargar_normalizado_ot_oficinas'
  SET NOCOUNT ON;
  DECLARE @log int;
  EXECUTE @log = dbn1_stg_dhyf_u.dbo.spn1_apuntar_log @logpadre,@procedure_name;
  DECLARE @fecha_ultima_carga datetime=dbn1_stg_dhyf_u.dbo.fnn1_fecha_ultima_carga(@log);
  DECLARE @continuar_en_caso_error bit=0;
  IF @logpadre IS NOT NULL AND EXISTS (SELECT 1 AS expr1
  FROM dbn1_norm_dhyf_u.audit.tbn1_procedimientos_excluidos
  WHERE
    'dbn1_stg_dhyf_u.dbo.'+procedimiento=@procedure_name
    AND excluido=1
  ) BEGIN
    UPDATE dbn1_norm_dhyf_u.audit.tbn1_logs SET
      mensaje_error='EXCLUÍDO'
    WHERE
      id_log=@log;
    RETURN
  END
     BEGIN TRY

  ;WITH
  query AS (
    SELECT
      ofi.equiequipo AS cod_oficina,
      ofi.equidesc AS des_oficina,
      coalesce(grof.cod_grupo_oficina,0) AS cod_grupo_oficina,
      coalesce(grof.grupo_oficina,'OTRAS') AS grupo_oficina
    FROM dbn1_stg_dhyf_u.dbo.tbn1equi_z3 ofi
    LEFT JOIN (SELECT 0 cod_oficina,4 cod_grupo_oficina,'GESTION RECAUDATORIA' grupo_oficina
               UNION ALL SELECT 100,7,'UNIDAD EJECUTIVA'
               UNION ALL SELECT 200,7,'UNIDAD EJECUTIVA'
               UNION ALL SELECT 300,7,'UNIDAD EJECUTIVA'
               UNION ALL SELECT 301,7,'UNIDAD EJECUTIVA'
               UNION ALL SELECT 302,7,'UNIDAD EJECUTIVA'
               UNION ALL SELECT 400,0,'OTRAS'
               UNION ALL SELECT 401,7,'UNIDAD EJECUTIVA'
               UNION ALL SELECT 402,7,'UNIDAD EJECUTIVA'
               UNION ALL SELECT 500,7,'UNIDAD EJECUTIVA'
               UNION ALL SELECT 600,7,'UNIDAD EJECUTIVA'
               UNION ALL SELECT 601,7,'UNIDAD EJECUTIVA'
               UNION ALL SELECT 602,7,'UNIDAD EJECUTIVA'
               UNION ALL SELECT 700,7,'UNIDAD EJECUTIVA'
               UNION ALL SELECT 900,7,'UNIDAD EJECUTIVA'
               UNION ALL SELECT 1111,4,'GESTION RECAUDATORIA'
               UNION ALL SELECT 2100,7,'UNIDAD EJECUTIVA'
               UNION ALL SELECT 2200,7,'UNIDAD EJECUTIVA'
               UNION ALL SELECT 2300,7,'UNIDAD EJECUTIVA'
               UNION ALL SELECT 2301,7,'UNIDAD EJECUTIVA'
               UNION ALL SELECT 2400,7,'UNIDAD EJECUTIVA'
               UNION ALL SELECT 2500,7,'UNIDAD EJECUTIVA'
               UNION ALL SELECT 2501,7,'UNIDAD EJECUTIVA'
               UNION ALL SELECT 2502,7,'UNIDAD EJECUTIVA'
               UNION ALL SELECT 2503,7,'UNIDAD EJECUTIVA'
               UNION ALL SELECT 2504,7,'UNIDAD EJECUTIVA'
               UNION ALL SELECT 2505,7,'UNIDAD EJECUTIVA'
               UNION ALL SELECT 3100,7,'UNIDAD EJECUTIVA'
               UNION ALL SELECT 3101,4,'GESTION RECAUDATORIA'
               UNION ALL SELECT 4100,3,'CONCURSALES'
               UNION ALL SELECT 4200,2,'APLAZAMIENTOS'
               UNION ALL SELECT 4300,1,'ACTUACIONES ESPECIALES'
               UNION ALL SELECT 4301,1,'ACTUACIONES ESPECIALES'
               UNION ALL SELECT 4400,4,'GESTION RECAUDATORIA'
               UNION ALL SELECT 4401,4,'GESTION RECAUDATORIA'
               UNION ALL SELECT 4500,4,'GESTION RECAUDATORIA'
               UNION ALL SELECT 4600,5,'INSPECCION RECAUDATORIA'
               UNION ALL SELECT 4700,6,'SERVICIO DE RECAUDACION'
               UNION ALL SELECT 4900,7,'UNIDAD EJECUTIVA'
               UNION ALL SELECT 4901,7,'UNIDAD EJECUTIVA'
               UNION ALL SELECT 4904,6,'SERVICIO DE RECAUDACION'
               UNION ALL SELECT 4905,4,'GESTION RECAUDATORIA'
               UNION ALL SELECT 4906,7,'UNIDAD EJECUTIVA'
               UNION ALL SELECT 4907,7,'UNIDAD EJECUTIVA'
               UNION ALL SELECT 5000,7,'UNIDAD EJECUTIVA') grof ON right('000'+CAST(grof.cod_oficina AS varchar),4)=ofi.equiequipo
    GROUP BY
      ofi.equiequipo,
      ofi.equidesc,
      coalesce(grof.cod_grupo_oficina,0),
      coalesce(grof.grupo_oficina,'OTRAS')
  )
  MERGE dbn1_norm_dhyf_u.dbo.tbn1_ot_oficinas AS tbn1_ot_oficinas
  USING query ON query.cod_oficina=tbn1_ot_oficinas.cod_oficina
  WHEN MATCHED AND ((tbn1_ot_oficinas.des_oficina<>query.des_oficina OR (tbn1_ot_oficinas.des_oficina IS NULL AND query.des_oficina IS NOT NULL) OR  (tbn1_ot_oficinas.des_oficina IS NOT NULL AND query.des_oficina IS NULL)
                    OR tbn1_ot_oficinas.cod_grupo_oficina<>query.cod_grupo_oficina OR (tbn1_ot_oficinas.cod_grupo_oficina IS NULL AND query.cod_grupo_oficina IS NOT NULL) OR  (tbn1_ot_oficinas.cod_grupo_oficina IS NOT NULL AND query.cod_grupo_oficina IS NULL)
                    OR tbn1_ot_oficinas.grupo_oficina<>query.grupo_oficina OR (tbn1_ot_oficinas.grupo_oficina IS NULL AND query.grupo_oficina IS NOT NULL) OR  (tbn1_ot_oficinas.grupo_oficina IS NOT NULL AND query.grupo_oficina IS NULL)
                    OR (fec_baja IS NOT NULL))) THEN
    UPDATE SET
      des_oficina=query.des_oficina,
      cod_grupo_oficina=query.cod_grupo_oficina,
      grupo_oficina=query.grupo_oficina,
      fec_modificacion=getdate(),
      fec_baja=null
  WHEN NOT MATCHED THEN
    INSERT (cod_oficina,des_oficina,cod_grupo_oficina,grupo_oficina,fec_alta,fec_modificacion) VALUES (
      query.cod_oficina,
      query.des_oficina,
      query.cod_grupo_oficina,
      query.grupo_oficina,
      getdate(),
      getdate())
  WHEN NOT MATCHED BY SOURCE AND (fec_baja IS NULL) THEN
    UPDATE SET
      fec_baja=getdate(),
      fec_modificacion=getdate();

  EXECUTE dbn1_stg_dhyf_u.dbo.spn1_finalizar_log @log,@@ROWCOUNT;
   END TRY
  BEGIN CATCH
    EXECUTE dbn1_stg_dhyf_u.dbo.spn1_finalizar_log @log,null;
    UPDATE dbn1_norm_dhyf_u.audit.tbn1_logs SET
      mensaje_error=error_message(),
      procedimiento_error=error_procedure()
    WHERE
      id_log=@log;
    IF @continuar_en_caso_error=0 OR @logpadre IS NULL THROW
  END CATCH


END

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_antiguedad_contraido')
CREATE TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_antiguedad_contraido(
  id_antiguedad int IDENTITY(1,1),
  cod_antiguedad int NOT NULL,
  des_antiguedad varchar(20) NOT NULL,
  es_indefinido bit,
  fec_alta datetime,
  fec_modificacion datetime,
  fec_baja datetime,
  CONSTRAINT uk_ot_antiguedad UNIQUE (cod_antiguedad),
  CONSTRAINT PK_tbn1_ot_antiguedad_contraido PRIMARY KEY CLUSTERED (id_antiguedad)
)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_antiguedad_contraido' AND COLUMN_NAME='id_antiguedad')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_antiguedad_contraido ADD id_antiguedad int

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_antiguedad_contraido' AND COLUMN_NAME='cod_antiguedad')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_antiguedad_contraido ADD cod_antiguedad int

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_antiguedad_contraido' AND COLUMN_NAME='des_antiguedad')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_antiguedad_contraido ADD des_antiguedad varchar(20)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_antiguedad_contraido' AND COLUMN_NAME='es_indefinido')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_antiguedad_contraido ADD es_indefinido bit

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_antiguedad_contraido' AND COLUMN_NAME='fec_alta')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_antiguedad_contraido ADD fec_alta datetime

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_antiguedad_contraido' AND COLUMN_NAME='fec_modificacion')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_antiguedad_contraido ADD fec_modificacion datetime

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_antiguedad_contraido' AND COLUMN_NAME='fec_baja')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_antiguedad_contraido ADD fec_baja datetime

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_antiguedad_contraido' AND COLUMN_NAME='es_indefinido' AND COLUMN_DEFAULT IS NULL)
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_antiguedad_contraido ADD CONSTRAINT DF_DBO_TBN1_OT_ANTIGUEDAD_CONTRAIDO_ES_INDEFINIDO DEFAULT 0 FOR es_indefinido

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_antiguedad_contraido' AND COLUMN_NAME='id_antiguedad' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_antiguedad_contraido ALTER COLUMN id_antiguedad int NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_antiguedad_contraido' AND COLUMN_NAME='cod_antiguedad' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_antiguedad_contraido ALTER COLUMN cod_antiguedad int NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_antiguedad_contraido' AND COLUMN_NAME='des_antiguedad' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_antiguedad_contraido ALTER COLUMN des_antiguedad varchar(20) NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_antiguedad_contraido' AND COLUMN_NAME='es_indefinido' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_antiguedad_contraido ALTER COLUMN es_indefinido bit NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_antiguedad_contraido' AND COLUMN_NAME='fec_alta' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_antiguedad_contraido ALTER COLUMN fec_alta datetime NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_antiguedad_contraido' AND COLUMN_NAME='fec_modificacion' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_antiguedad_contraido ALTER COLUMN fec_modificacion datetime NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_antiguedad_contraido' AND COLUMN_NAME='fec_baja' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_antiguedad_contraido ALTER COLUMN fec_baja datetime NULL

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_antiguedad_contraido' AND CONSTRAINT_NAME='PK_tbn1_ot_antiguedad_contraido')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_antiguedad_contraido ADD CONSTRAINT PK_tbn1_ot_antiguedad_contraido PRIMARY KEY CLUSTERED (id_antiguedad)

GO

;WITH
query AS (
  SELECT 1 AS es_indefinido,99 AS cod_antiguedad,'Otra' AS des_antiguedad
)
MERGE dbn1_norm_dhyf_u.dbo.tbn1_ot_antiguedad_contraido AS tbn1_ot_antiguedad_contraido
USING query ON query.es_indefinido=tbn1_ot_antiguedad_contraido.es_indefinido
WHEN MATCHED AND ((tbn1_ot_antiguedad_contraido.cod_antiguedad<>query.cod_antiguedad OR (tbn1_ot_antiguedad_contraido.cod_antiguedad IS NULL AND query.cod_antiguedad IS NOT NULL) OR  (tbn1_ot_antiguedad_contraido.cod_antiguedad IS NOT NULL AND query.cod_antiguedad IS NULL)
                  OR tbn1_ot_antiguedad_contraido.des_antiguedad<>query.des_antiguedad OR (tbn1_ot_antiguedad_contraido.des_antiguedad IS NULL AND query.des_antiguedad IS NOT NULL) OR  (tbn1_ot_antiguedad_contraido.des_antiguedad IS NOT NULL AND query.des_antiguedad IS NULL))) THEN
  UPDATE SET
    cod_antiguedad=query.cod_antiguedad,
    des_antiguedad=query.des_antiguedad
WHEN NOT MATCHED THEN
  INSERT (es_indefinido,cod_antiguedad,des_antiguedad) VALUES (
    query.es_indefinido,
    query.cod_antiguedad,
    query.des_antiguedad);
GO

USE dbn1_stg_dhyf_u
GO

IF EXISTS (SELECT 1 FROM dbn1_stg_dhyf_u.INFORMATION_SCHEMA.ROUTINES WHERE ROUTINE_SCHEMA='dbo' AND ROUTINE_NAME='spn1_cargar_normalizado_ot_antiguedad_contraido' AND ROUTINE_TYPE='PROCEDURE')
DROP PROCEDURE dbo.spn1_cargar_normalizado_ot_antiguedad_contraido;
GO

CREATE PROCEDURE dbo.spn1_cargar_normalizado_ot_antiguedad_contraido(@logpadre int) AS
BEGIN

  DECLARE @procedure_name varchar(100)='dbn1_stg_dhyf_u.dbo.spn1_cargar_normalizado_ot_antiguedad_contraido'
  SET NOCOUNT ON;
  DECLARE @log int;
  EXECUTE @log = dbn1_stg_dhyf_u.dbo.spn1_apuntar_log @logpadre,@procedure_name;
  DECLARE @fecha_ultima_carga datetime=dbn1_stg_dhyf_u.dbo.fnn1_fecha_ultima_carga(@log);
  DECLARE @continuar_en_caso_error bit=0;
  IF @logpadre IS NOT NULL AND EXISTS (SELECT 1 AS expr1
  FROM dbn1_norm_dhyf_u.audit.tbn1_procedimientos_excluidos
  WHERE
    'dbn1_stg_dhyf_u.dbo.'+procedimiento=@procedure_name
    AND excluido=1
  ) BEGIN
    UPDATE dbn1_norm_dhyf_u.audit.tbn1_logs SET
      mensaje_error='EXCLUÍDO'
    WHERE
      id_log=@log;
    RETURN
  END
     BEGIN TRY

  ;WITH
  query AS (
    SELECT
      antig.cod_antiguedad AS cod_antiguedad,
      antig.des_antiguedad AS des_antiguedad
    FROM
      (SELECT 0 cod_antiguedad,'Menos de 1 año' des_antiguedad
       UNION ALL SELECT 1,'Entre 1 y 2 años'
       UNION ALL SELECT 2,'Entre 2 y 3 años'
       UNION ALL SELECT 3,'Entre 3 y 4 años'
       UNION ALL SELECT 4,'Entre 4 y 5 años'
       UNION ALL SELECT 5,'Más de 5 años') antig
    GROUP BY
      antig.cod_antiguedad,
      antig.des_antiguedad
  )
  MERGE dbn1_norm_dhyf_u.dbo.tbn1_ot_antiguedad_contraido AS tbn1_ot_antiguedad_contraido
  USING query ON query.cod_antiguedad=tbn1_ot_antiguedad_contraido.cod_antiguedad
  WHEN MATCHED AND (tbn1_ot_antiguedad_contraido.es_indefinido=0
                    AND (tbn1_ot_antiguedad_contraido.des_antiguedad<>query.des_antiguedad OR (tbn1_ot_antiguedad_contraido.des_antiguedad IS NULL AND query.des_antiguedad IS NOT NULL) OR  (tbn1_ot_antiguedad_contraido.des_antiguedad IS NOT NULL AND query.des_antiguedad IS NULL)
                    OR (fec_baja IS NOT NULL))) THEN
    UPDATE SET
      des_antiguedad=query.des_antiguedad,
      fec_modificacion=getdate(),
      fec_baja=null
  WHEN NOT MATCHED THEN
    INSERT (cod_antiguedad,des_antiguedad,fec_alta,fec_modificacion) VALUES (
      query.cod_antiguedad,
      query.des_antiguedad,
      getdate(),
      getdate())
  WHEN NOT MATCHED BY SOURCE AND (tbn1_ot_antiguedad_contraido.es_indefinido=0
                                  AND fec_baja IS NULL) THEN
    UPDATE SET
      fec_baja=getdate(),
      fec_modificacion=getdate();

  EXECUTE dbn1_stg_dhyf_u.dbo.spn1_finalizar_log @log,@@ROWCOUNT;
   END TRY
  BEGIN CATCH
    EXECUTE dbn1_stg_dhyf_u.dbo.spn1_finalizar_log @log,null;
    UPDATE dbn1_norm_dhyf_u.audit.tbn1_logs SET
      mensaje_error=error_message(),
      procedimiento_error=error_procedure()
    WHERE
      id_log=@log;
    IF @continuar_en_caso_error=0 OR @logpadre IS NULL THROW
  END CATCH


END

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_formatos_ingreso')
CREATE TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_formatos_ingreso(
  id_formato_ingreso int IDENTITY(1,1),
  cod_formato_ingreso nvarchar(4) NOT NULL,
  des_formato_ingreso nvarchar(40) NOT NULL,
  cod_agrupacion_formato_ingreso int NOT NULL,
  des_agrupacion_formato_ingreso nvarchar(40) NOT NULL,
  es_indefinido bit,
  fec_alta datetime,
  fec_modificacion datetime,
  fec_baja datetime,
  CONSTRAINT uk_ot_formatos_ingreso UNIQUE (cod_formato_ingreso),
  CONSTRAINT PK_tbn1_ot_formatos_ingreso PRIMARY KEY CLUSTERED (id_formato_ingreso)
)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_formatos_ingreso' AND COLUMN_NAME='id_formato_ingreso')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_formatos_ingreso ADD id_formato_ingreso int

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_formatos_ingreso' AND COLUMN_NAME='cod_formato_ingreso')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_formatos_ingreso ADD cod_formato_ingreso nvarchar(4)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_formatos_ingreso' AND COLUMN_NAME='des_formato_ingreso')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_formatos_ingreso ADD des_formato_ingreso nvarchar(40)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_formatos_ingreso' AND COLUMN_NAME='cod_agrupacion_formato_ingreso')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_formatos_ingreso ADD cod_agrupacion_formato_ingreso int

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_formatos_ingreso' AND COLUMN_NAME='des_agrupacion_formato_ingreso')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_formatos_ingreso ADD des_agrupacion_formato_ingreso nvarchar(40)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_formatos_ingreso' AND COLUMN_NAME='es_indefinido')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_formatos_ingreso ADD es_indefinido bit

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_formatos_ingreso' AND COLUMN_NAME='fec_alta')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_formatos_ingreso ADD fec_alta datetime

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_formatos_ingreso' AND COLUMN_NAME='fec_modificacion')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_formatos_ingreso ADD fec_modificacion datetime

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_formatos_ingreso' AND COLUMN_NAME='fec_baja')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_formatos_ingreso ADD fec_baja datetime

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_formatos_ingreso' AND COLUMN_NAME='cod_agrupacion_formato_ingreso' AND COLUMN_DEFAULT IS NULL)
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_formatos_ingreso ADD CONSTRAINT DF_DBO_TBN1_OT_FORMATOS_INGRESO_COD_AGRUPACION_FORMATO_INGRESO DEFAULT 1 FOR cod_agrupacion_formato_ingreso

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_formatos_ingreso' AND COLUMN_NAME='des_agrupacion_formato_ingreso' AND COLUMN_DEFAULT IS NULL)
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_formatos_ingreso ADD CONSTRAINT DF_DBO_TBN1_OT_FORMATOS_INGRESO_DES_AGRUPACION_FORMATO_INGRESO DEFAULT '' FOR des_agrupacion_formato_ingreso

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_formatos_ingreso' AND COLUMN_NAME='es_indefinido' AND COLUMN_DEFAULT IS NULL)
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_formatos_ingreso ADD CONSTRAINT DF_DBO_TBN1_OT_FORMATOS_INGRESO_ES_INDEFINIDO DEFAULT 0 FOR es_indefinido

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_formatos_ingreso' AND COLUMN_NAME='id_formato_ingreso' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_formatos_ingreso ALTER COLUMN id_formato_ingreso int NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_formatos_ingreso' AND COLUMN_NAME='cod_formato_ingreso' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_formatos_ingreso ALTER COLUMN cod_formato_ingreso nvarchar(4) NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_formatos_ingreso' AND COLUMN_NAME='des_formato_ingreso' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_formatos_ingreso ALTER COLUMN des_formato_ingreso nvarchar(40) NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_formatos_ingreso' AND COLUMN_NAME='cod_agrupacion_formato_ingreso' AND IS_NULLABLE='YES')
BEGIN
  UPDATE dbn1_norm_dhyf_u.dbo.tbn1_ot_formatos_ingreso SET cod_agrupacion_formato_ingreso=1 WHERE cod_agrupacion_formato_ingreso IS NULL
  ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_formatos_ingreso ALTER COLUMN cod_agrupacion_formato_ingreso int NOT NULL
END

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_formatos_ingreso' AND COLUMN_NAME='des_agrupacion_formato_ingreso' AND IS_NULLABLE='YES')
BEGIN
  UPDATE dbn1_norm_dhyf_u.dbo.tbn1_ot_formatos_ingreso SET des_agrupacion_formato_ingreso='' WHERE des_agrupacion_formato_ingreso IS NULL
  ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_formatos_ingreso ALTER COLUMN des_agrupacion_formato_ingreso nvarchar(40) NOT NULL
END

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_formatos_ingreso' AND COLUMN_NAME='es_indefinido' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_formatos_ingreso ALTER COLUMN es_indefinido bit NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_formatos_ingreso' AND COLUMN_NAME='fec_alta' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_formatos_ingreso ALTER COLUMN fec_alta datetime NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_formatos_ingreso' AND COLUMN_NAME='fec_modificacion' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_formatos_ingreso ALTER COLUMN fec_modificacion datetime NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_formatos_ingreso' AND COLUMN_NAME='fec_baja' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_formatos_ingreso ALTER COLUMN fec_baja datetime NULL

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_formatos_ingreso' AND CONSTRAINT_NAME='PK_tbn1_ot_formatos_ingreso')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_formatos_ingreso ADD CONSTRAINT PK_tbn1_ot_formatos_ingreso PRIMARY KEY CLUSTERED (id_formato_ingreso)

GO

;WITH
query AS (
  SELECT 1 AS es_indefinido,'ZZZZ' AS cod_formato_ingreso,'Indefinido' AS des_formato_ingreso,0 AS cod_agrupacion_formato_ingreso,'INDEFINIDO' AS des_agrupacion_formato_ingreso
)
MERGE dbn1_norm_dhyf_u.dbo.tbn1_ot_formatos_ingreso AS tbn1_ot_formatos_ingreso
USING query ON query.es_indefinido=tbn1_ot_formatos_ingreso.es_indefinido
WHEN MATCHED AND ((tbn1_ot_formatos_ingreso.cod_formato_ingreso<>query.cod_formato_ingreso OR (tbn1_ot_formatos_ingreso.cod_formato_ingreso IS NULL AND query.cod_formato_ingreso IS NOT NULL) OR  (tbn1_ot_formatos_ingreso.cod_formato_ingreso IS NOT NULL AND query.cod_formato_ingreso IS NULL)
                  OR tbn1_ot_formatos_ingreso.des_formato_ingreso<>query.des_formato_ingreso OR (tbn1_ot_formatos_ingreso.des_formato_ingreso IS NULL AND query.des_formato_ingreso IS NOT NULL) OR  (tbn1_ot_formatos_ingreso.des_formato_ingreso IS NOT NULL AND query.des_formato_ingreso IS NULL)
                  OR tbn1_ot_formatos_ingreso.cod_agrupacion_formato_ingreso<>query.cod_agrupacion_formato_ingreso OR (tbn1_ot_formatos_ingreso.cod_agrupacion_formato_ingreso IS NULL AND query.cod_agrupacion_formato_ingreso IS NOT NULL) OR  (tbn1_ot_formatos_ingreso.cod_agrupacion_formato_ingreso IS NOT NULL AND query.cod_agrupacion_formato_ingreso IS NULL)
                  OR tbn1_ot_formatos_ingreso.des_agrupacion_formato_ingreso<>query.des_agrupacion_formato_ingreso OR (tbn1_ot_formatos_ingreso.des_agrupacion_formato_ingreso IS NULL AND query.des_agrupacion_formato_ingreso IS NOT NULL) OR  (tbn1_ot_formatos_ingreso.des_agrupacion_formato_ingreso IS NOT NULL AND query.des_agrupacion_formato_ingreso IS NULL))) THEN
  UPDATE SET
    cod_formato_ingreso=query.cod_formato_ingreso,
    des_formato_ingreso=query.des_formato_ingreso,
    cod_agrupacion_formato_ingreso=query.cod_agrupacion_formato_ingreso,
    des_agrupacion_formato_ingreso=query.des_agrupacion_formato_ingreso
WHEN NOT MATCHED THEN
  INSERT (es_indefinido,cod_formato_ingreso,des_formato_ingreso,cod_agrupacion_formato_ingreso,des_agrupacion_formato_ingreso) VALUES (
    query.es_indefinido,
    query.cod_formato_ingreso,
    query.des_formato_ingreso,
    query.cod_agrupacion_formato_ingreso,
    query.des_agrupacion_formato_ingreso);
GO

USE dbn1_stg_dhyf_u
GO

IF EXISTS (SELECT 1 FROM dbn1_stg_dhyf_u.INFORMATION_SCHEMA.ROUTINES WHERE ROUTINE_SCHEMA='dbo' AND ROUTINE_NAME='spn1_cargar_normalizado_ot_formatos_ingreso' AND ROUTINE_TYPE='PROCEDURE')
DROP PROCEDURE dbo.spn1_cargar_normalizado_ot_formatos_ingreso;
GO

CREATE PROCEDURE dbo.spn1_cargar_normalizado_ot_formatos_ingreso(@logpadre int) AS
BEGIN

  DECLARE @procedure_name varchar(100)='dbn1_stg_dhyf_u.dbo.spn1_cargar_normalizado_ot_formatos_ingreso'
  SET NOCOUNT ON;
  DECLARE @log int;
  EXECUTE @log = dbn1_stg_dhyf_u.dbo.spn1_apuntar_log @logpadre,@procedure_name;
  DECLARE @fecha_ultima_carga datetime=dbn1_stg_dhyf_u.dbo.fnn1_fecha_ultima_carga(@log);
  DECLARE @continuar_en_caso_error bit=0;
  IF @logpadre IS NOT NULL AND EXISTS (SELECT 1 AS expr1
  FROM dbn1_norm_dhyf_u.audit.tbn1_procedimientos_excluidos
  WHERE
    'dbn1_stg_dhyf_u.dbo.'+procedimiento=@procedure_name
    AND excluido=1
  ) BEGIN
    UPDATE dbn1_norm_dhyf_u.audit.tbn1_logs SET
      mensaje_error='EXCLUÍDO'
    WHERE
      id_log=@log;
    RETURN
  END
     BEGIN TRY

  ;WITH
  query AS (
    SELECT
      substring(foin.auxi_re02_clave,22,4) AS cod_formato_ingreso,
      foin.auxi_re02_descr_c AS des_formato_ingreso,
      coalesce(grfo.cod_agrupacion_formato_ingreso,0) AS cod_agrupacion_formato_ingreso,
      coalesce(grfo.des_agrupacion_formato_ingreso,'INDEFINIDO') AS des_agrupacion_formato_ingreso
    FROM dbn1_stg_dhyf_u.dbo.tbn1auxi_s7_r02 foin
    LEFT JOIN (SELECT 'ZZZZ' cod_formato_ingreso,'ZZZZ - Indefinido' des_formato_ingreso,14 cod_agrupacion_formato_ingreso,'OTROS' des_agrupacion_formato_ingreso_larga,'OTROS' des_agrupacion_formato_ingreso
               UNION ALL SELECT '65','65 - Ingresos por NRC',1,'OTROS','IMPRESOS'
               UNION ALL SELECT 'APE','APE - Aplicacion ingreso forzoso',8,'INGRESO 3º','EMBARGO'
               UNION ALL SELECT 'APN','APN - Aplicación ingreso no forzoso',1,'AUTOLIQUIDACION_INGRESO','IMPRESOS'
               UNION ALL SELECT 'AUTO','AUTO - Autoliquidaciones',1,'AUTOLIQUIDACION_INGRESO','IMPRESOS'
               UNION ALL SELECT 'CF34','CF34 - complementaria Seguridad Social',8,'EMBARGO SEG. SOCIAL','EMBARGO'
               UNION ALL SELECT 'CF57','CF57 - Complementaria F57',3,'CARTA PAGO','CARTA PAGO'
               UNION ALL SELECT 'CF65','CF65 - complementaria F65A',1,'AUTOLIQUIDACION_INGRESO','IMPRESOS'
               UNION ALL SELECT 'CFN','CFN - Ingresos FEOGA',14,'EN CUENTA ORDINARIA/RECAUDACION','OTROS'
               UNION ALL SELECT 'CMA','CMA - Compensación aplazada',5,'COMPENSACIONES','COMPENSACIÓN'
               UNION ALL SELECT 'CME','CME - Compensación ejecutiva',5,'COMPENSACIONES','COMPENSACIÓN'
               UNION ALL SELECT 'CMI','CMI - Compensación instancia parte',5,'COMPENSACIONES','COMPENSACIÓN'
               UNION ALL SELECT 'CMIT','CMIT - COMPENSACION/EMBARGO DE C4',5,'COMPENSACIONES','COMPENSACIÓN'
               UNION ALL SELECT 'CMO','CMO - Compensación organismo públic.',5,'COMPENSACIONES','COMPENSACIÓN'
               UNION ALL SELECT 'COMP','COMP - Compensaciones',5,'COMPENSACIONES','COMPENSACIÓN'
               UNION ALL SELECT 'CORD','CORD - Complementaria AUTO en ordinaria',14,'EN CUENTA ORDINARIA/RECAUDACION','OTROS'
               UNION ALL SELECT 'CRE','CRE - Cuenta Reca Ingreso Forzosa',8,'INGRESO 3º','EMBARGO'
               UNION ALL SELECT 'CREA','CREA - Salidas directas V-39',8,'INGRESO 3º','EMBARGO'
               UNION ALL SELECT 'CREV','CREV - Ingresos rec. agrupacion V-39',8,'INGRESO 3º','EMBARGO'
               UNION ALL SELECT 'CRN','CRN - Cuenta reca ingreso del obligado',3,'EN CUENTA ORDINARIA/RECAUDACION','CARTA PAGO'
               UNION ALL SELECT 'CRNA','CRNA - Salidas directas V-39',14,'EN CUENTA ORDINARIA/RECAUDACION','OTROS'
               UNION ALL SELECT 'CRNV','CRNV - Ingresos rec. agrupacion V-39',14,'EN CUENTA ORDINARIA/RECAUDACION','OTROS'
               UNION ALL SELECT 'DEVO','DEVO - Devoluciones de EJ',14,'OTROS','OTROS'
               UNION ALL SELECT 'DSE','DSE - Desdata terceros',14,'OTROS','OTROS'
               UNION ALL SELECT 'DSFI','DSFI - Desdata de documentos',14,'OTROS','OTROS'
               UNION ALL SELECT 'DSN','DSN - Desdata ingreso obligado',14,'OTROS','OTROS'
               UNION ALL SELECT 'DSZ4','DSZ4 - DESDATAS DE Z4',14,'OTROS','OTROS'
               UNION ALL SELECT 'EJE2','EJE2 - AUTOLIQUIDACIONES RETENCIONES DE ',14,'OTROS','OTROS'
               UNION ALL SELECT 'EJS7','EJS7 - REINTEGROS PAGOS FALLIDOS. EECC',14,'OTROS','OTROS'
               UNION ALL SELECT 'EJYC','EJYC - SEÑALAMIENTO DE YCO(ANTICIPIO C4)',14,'OTROS','OTROS'
               UNION ALL SELECT 'EMB','EMB - Retención pago embargos',14,'OTROS','OTROS'
               UNION ALL SELECT 'F19L','F19L - Domiciliaciones',10,'DOMICILIACIÓN','DOMICILIACIÓN'
               UNION ALL SELECT 'F19R','F19R - Domiciliacion Recibos',10,'DOMICILIACIÓN','DOMICILIACIÓN'
               UNION ALL SELECT 'F34','F34 - Embargo de la S.S.',8,'EMBARGO SEG. SOCIAL','EMBARGO'
               UNION ALL SELECT 'F57','F57 - Cobros en ventanillo',3,'CARTA PAGO','CARTA PAGO'
               UNION ALL SELECT 'F57A','F57A - Cobro ventanillo (autoliquid)',3,'CARTA PAGO','CARTA PAGO'
               UNION ALL SELECT 'F57D','F57D - Formato 57 Declas (V47)',1,'AUTOLIQUIDACION_INGRESO','IMPRESOS'
               UNION ALL SELECT 'F57E','F57E - Cobro vantanilla Embargos',8,'INGRESO 3º','EMBARGO'
               UNION ALL SELECT 'F57O','F57O - F57 sufijo erróneo',8,'INGRESO 3º','EMBARGO'
               UNION ALL SELECT 'F57V','F57V - Ingresos de IBI del Gobierno Vasc',3,'EN CUENTA ORDINARIA/RECAUDACION','CARTA PAGO'
               UNION ALL SELECT 'F63','F63 - Embargos telematicos',8,'EMBARGO TELEMATICO','EMBARGO'
               UNION ALL SELECT 'F65','F65 - Ingresos por NRC',1,'AUTOLIQUIDACION_INGRESO','IMPRESOS'
               UNION ALL SELECT 'F65A','F65A - AUTOLIQUIDACIONES DE LOS BANCOS',1,'AUTOLIQUIDACION_INGRESO','IMPRESOS'
               UNION ALL SELECT 'FEGA','FEGA - Ingresos FEOGA',14,'OTROS','OTROS'
               UNION ALL SELECT 'FORM','FORM - Ingreso en Formalizacion',14,'OTROS','OTROS'
               UNION ALL SELECT 'FS1C','FS1C - Carga Inicial s1',14,'OTROS','OTROS'
               UNION ALL SELECT 'ICA0','ICA0 - Autoliquidaciones ICA0',14,'OTROS','OTROS'
               UNION ALL SELECT 'ICRE','ICRE - Rectificaciones de documentos de ',14,'OTROS','OTROS'
               UNION ALL SELECT 'ICS1','ICS1 - RECTIFICACIONES DOCUMENTOS IC',14,'OTROS','OTROS'
               UNION ALL SELECT 'INDF','INDF - DATA DE INDEBIDOS (FISCALIZACION)',14,'OTROS','OTROS'
               UNION ALL SELECT 'MF65','MF65 - Autoliq. F65A (manual)',1,'AUTOLIQUIDACION_INGRESO','IMPRESOS'
               UNION ALL SELECT 'MNRC','"MNRC - NRC con solic. devolución y ""no c"',14,'OTROS','OTROS'
               UNION ALL SELECT 'NOTI','NOTI - F57 cargado en cuenta declas',3,'CARTA PAGO','CARTA PAGO'
               UNION ALL SELECT 'ORDI','ORDI - ingresos en la ordinaria',14,'EN CUENTA ORDINARIA/RECAUDACION','OTROS'
               UNION ALL SELECT 'OTRO','OTRO - Otros formatos',14,'OTROS','OTROS'
               UNION ALL SELECT 'RCDA','RCDA - remesas cambio domicilio alava',15,'REMESAS','REMESAS'
               UNION ALL SELECT 'RCDE','RCDE - remesas cambio domicilio aeat',15,'REMESAS','REMESAS'
               UNION ALL SELECT 'RCDG','RCDG - remesas cambio domicilio gipuzkoa',15,'REMESAS','REMESAS'
               UNION ALL SELECT 'RECF','RECF - rectificaciones fiscalizacion',14,'OTROS','OTROS'
               UNION ALL SELECT 'RECT','RECT - Rectificaciones',14,'OTROS','OTROS'
               UNION ALL SELECT 'REEB','REEB - batch',14,'OTROS','OTROS'
               UNION ALL SELECT 'REEF','REEF - FORZOSO',14,'OTROS','OTROS'
               UNION ALL SELECT 'REEN','REEN - NO FORZOSO',14,'OTROS','OTROS'
               UNION ALL SELECT 'REIC','REIC - RECTIFICACIONES DE INGRESO DESDE ',14,'OTROS','OTROS'
               UNION ALL SELECT 'REMA','REMA - remesas alava',15,'REMESAS','REMESAS'
               UNION ALL SELECT 'REMC','REMC - remesas com. autonomas y otros',15,'REMESAS','REMESAS'
               UNION ALL SELECT 'REME','REME - REMESAS estado',15,'REMESAS','REMESAS'
               UNION ALL SELECT 'REMF','REMF - REMESAS LIQUIDACIONES formalizaci',15,'REMESAS','REMESAS'
               UNION ALL SELECT 'REMG','REMG - remesas gipuzkoa',15,'REMESAS','REMESAS'
               UNION ALL SELECT 'REMN','REMN - remesas navarra',15,'REMESAS','REMESAS'
               UNION ALL SELECT 'REMV','REMV - REMESAS AUTOLIQUIDACIONES formali',15,'REMESAS','REMESAS'
               UNION ALL SELECT 'RTN','RTN - Retención pagos',14,'OTROS','OTROS'
               UNION ALL SELECT 'S6A0','S6A0 - Errorores en la data S7/S6',14,'OTROS','OTROS'
               UNION ALL SELECT 'S8AI','S8AI - Devoluciones desde EJ',14,'OTROS','OTROS'
               UNION ALL SELECT 'S8DA','S8DA - DATAS DE S8  POR MVTOS POSTERIORE',14,'OTROS','OTROS'
               UNION ALL SELECT 'S8DS','S8DS - DESDATAS DE S8 POR MVTOS POST',14,'OTROS','OTROS'
               UNION ALL SELECT 'S8DV','S8DV - INDEBIDO POR DEVOLUCION S8 MVTOS ',14,'OTROS','OTROS'
               UNION ALL SELECT 'S8E2','S8E2 - DEVOLUCION DE LA DESDATA DE S8',14,'OTROS','OTROS'
               UNION ALL SELECT 'S8IN','S8IN - INGRESO POR DEVOLUCION DESDE S8 M',14,'OTROS','OTROS'
               UNION ALL SELECT 'VIE2','VIE2 - autoliquid. retenciones en OO.EE.',14,'OTROS','OTROS'
               UNION ALL SELECT 'VIS7','VIS7 - Señalamientos no facturados por V',14,'OTROS','OTROS'
               UNION ALL SELECT 'VNRC','VNRC - Envío a V89 de NRC''s sin presenta',14,'OTROS','OTROS'
               UNION ALL SELECT 'YCO','YCO - ANTICIPOS DE COMPENSACIONES',14,'OTROS','OTROS') grfo ON grfo.cod_formato_ingreso=substring(foin.auxi_re02_clave,22,4)
    GROUP BY
      substring(foin.auxi_re02_clave,22,4),
      foin.auxi_re02_descr_c,
      coalesce(grfo.cod_agrupacion_formato_ingreso,0),
      coalesce(grfo.des_agrupacion_formato_ingreso,'INDEFINIDO')
  )
  MERGE dbn1_norm_dhyf_u.dbo.tbn1_ot_formatos_ingreso AS tbn1_ot_formatos_ingreso
  USING query ON query.cod_formato_ingreso=tbn1_ot_formatos_ingreso.cod_formato_ingreso
  WHEN MATCHED AND (tbn1_ot_formatos_ingreso.es_indefinido=0
                    AND (tbn1_ot_formatos_ingreso.des_formato_ingreso<>query.des_formato_ingreso OR (tbn1_ot_formatos_ingreso.des_formato_ingreso IS NULL AND query.des_formato_ingreso IS NOT NULL) OR  (tbn1_ot_formatos_ingreso.des_formato_ingreso IS NOT NULL AND query.des_formato_ingreso IS NULL)
                    OR tbn1_ot_formatos_ingreso.cod_agrupacion_formato_ingreso<>query.cod_agrupacion_formato_ingreso OR (tbn1_ot_formatos_ingreso.cod_agrupacion_formato_ingreso IS NULL AND query.cod_agrupacion_formato_ingreso IS NOT NULL) OR  (tbn1_ot_formatos_ingreso.cod_agrupacion_formato_ingreso IS NOT NULL AND query.cod_agrupacion_formato_ingreso IS NULL)
                    OR tbn1_ot_formatos_ingreso.des_agrupacion_formato_ingreso<>query.des_agrupacion_formato_ingreso OR (tbn1_ot_formatos_ingreso.des_agrupacion_formato_ingreso IS NULL AND query.des_agrupacion_formato_ingreso IS NOT NULL) OR  (tbn1_ot_formatos_ingreso.des_agrupacion_formato_ingreso IS NOT NULL AND query.des_agrupacion_formato_ingreso IS NULL)
                    OR (fec_baja IS NOT NULL))) THEN
    UPDATE SET
      des_formato_ingreso=query.des_formato_ingreso,
      cod_agrupacion_formato_ingreso=query.cod_agrupacion_formato_ingreso,
      des_agrupacion_formato_ingreso=query.des_agrupacion_formato_ingreso,
      fec_modificacion=getdate(),
      fec_baja=null
  WHEN NOT MATCHED THEN
    INSERT (cod_formato_ingreso,des_formato_ingreso,cod_agrupacion_formato_ingreso,des_agrupacion_formato_ingreso,fec_alta,fec_modificacion) VALUES (
      query.cod_formato_ingreso,
      query.des_formato_ingreso,
      query.cod_agrupacion_formato_ingreso,
      query.des_agrupacion_formato_ingreso,
      getdate(),
      getdate())
  WHEN NOT MATCHED BY SOURCE AND (tbn1_ot_formatos_ingreso.es_indefinido=0
                                  AND fec_baja IS NULL) THEN
    UPDATE SET
      fec_baja=getdate(),
      fec_modificacion=getdate();

  EXECUTE dbn1_stg_dhyf_u.dbo.spn1_finalizar_log @log,@@ROWCOUNT;
   END TRY
  BEGIN CATCH
    EXECUTE dbn1_stg_dhyf_u.dbo.spn1_finalizar_log @log,null;
    UPDATE dbn1_norm_dhyf_u.audit.tbn1_logs SET
      mensaje_error=error_message(),
      procedimiento_error=error_procedure()
    WHERE
      id_log=@log;
    IF @continuar_en_caso_error=0 OR @logpadre IS NULL THROW
  END CATCH


END

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_aplicaciones_lote')
CREATE TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_aplicaciones_lote(
  id_aplicacion_lote int IDENTITY(1,1),
  cod_aplicacion_lote nvarchar(2) NOT NULL,
  des_aplicacion_lote nvarchar(30) NOT NULL,
  es_indefinido bit,
  fec_alta datetime,
  fec_modificacion datetime,
  fec_baja datetime,
  CONSTRAINT uk_ot_aplicacion_lote UNIQUE (cod_aplicacion_lote),
  CONSTRAINT PK_tbn1_ot_aplicaciones_lote PRIMARY KEY CLUSTERED (id_aplicacion_lote)
)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_aplicaciones_lote' AND COLUMN_NAME='id_aplicacion_lote')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_aplicaciones_lote ADD id_aplicacion_lote int

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_aplicaciones_lote' AND COLUMN_NAME='cod_aplicacion_lote')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_aplicaciones_lote ADD cod_aplicacion_lote nvarchar(2)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_aplicaciones_lote' AND COLUMN_NAME='des_aplicacion_lote')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_aplicaciones_lote ADD des_aplicacion_lote nvarchar(30)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_aplicaciones_lote' AND COLUMN_NAME='es_indefinido')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_aplicaciones_lote ADD es_indefinido bit

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_aplicaciones_lote' AND COLUMN_NAME='fec_alta')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_aplicaciones_lote ADD fec_alta datetime

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_aplicaciones_lote' AND COLUMN_NAME='fec_modificacion')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_aplicaciones_lote ADD fec_modificacion datetime

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_aplicaciones_lote' AND COLUMN_NAME='fec_baja')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_aplicaciones_lote ADD fec_baja datetime

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_aplicaciones_lote' AND COLUMN_NAME='es_indefinido' AND COLUMN_DEFAULT IS NULL)
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_aplicaciones_lote ADD CONSTRAINT DF_DBO_TBN1_OT_APLICACIONES_LOTE_ES_INDEFINIDO DEFAULT 0 FOR es_indefinido

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_aplicaciones_lote' AND COLUMN_NAME='id_aplicacion_lote' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_aplicaciones_lote ALTER COLUMN id_aplicacion_lote int NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_aplicaciones_lote' AND COLUMN_NAME='cod_aplicacion_lote' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_aplicaciones_lote ALTER COLUMN cod_aplicacion_lote nvarchar(2) NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_aplicaciones_lote' AND COLUMN_NAME='des_aplicacion_lote' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_aplicaciones_lote ALTER COLUMN des_aplicacion_lote nvarchar(30) NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_aplicaciones_lote' AND COLUMN_NAME='es_indefinido' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_aplicaciones_lote ALTER COLUMN es_indefinido bit NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_aplicaciones_lote' AND COLUMN_NAME='fec_alta' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_aplicaciones_lote ALTER COLUMN fec_alta datetime NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_aplicaciones_lote' AND COLUMN_NAME='fec_modificacion' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_aplicaciones_lote ALTER COLUMN fec_modificacion datetime NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_aplicaciones_lote' AND COLUMN_NAME='fec_baja' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_aplicaciones_lote ALTER COLUMN fec_baja datetime NULL

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_aplicaciones_lote' AND CONSTRAINT_NAME='PK_tbn1_ot_aplicaciones_lote')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_aplicaciones_lote ADD CONSTRAINT PK_tbn1_ot_aplicaciones_lote PRIMARY KEY CLUSTERED (id_aplicacion_lote)

GO

;WITH
query AS (
  SELECT 1 AS es_indefinido,'99' AS cod_aplicacion_lote,'Indefinido' AS des_aplicacion_lote
)
MERGE dbn1_norm_dhyf_u.dbo.tbn1_ot_aplicaciones_lote AS tbn1_ot_aplicaciones_lote
USING query ON query.es_indefinido=tbn1_ot_aplicaciones_lote.es_indefinido
WHEN MATCHED AND ((tbn1_ot_aplicaciones_lote.cod_aplicacion_lote<>query.cod_aplicacion_lote OR (tbn1_ot_aplicaciones_lote.cod_aplicacion_lote IS NULL AND query.cod_aplicacion_lote IS NOT NULL) OR  (tbn1_ot_aplicaciones_lote.cod_aplicacion_lote IS NOT NULL AND query.cod_aplicacion_lote IS NULL)
                  OR tbn1_ot_aplicaciones_lote.des_aplicacion_lote<>query.des_aplicacion_lote OR (tbn1_ot_aplicaciones_lote.des_aplicacion_lote IS NULL AND query.des_aplicacion_lote IS NOT NULL) OR  (tbn1_ot_aplicaciones_lote.des_aplicacion_lote IS NOT NULL AND query.des_aplicacion_lote IS NULL))) THEN
  UPDATE SET
    cod_aplicacion_lote=query.cod_aplicacion_lote,
    des_aplicacion_lote=query.des_aplicacion_lote
WHEN NOT MATCHED THEN
  INSERT (es_indefinido,cod_aplicacion_lote,des_aplicacion_lote) VALUES (
    query.es_indefinido,
    query.cod_aplicacion_lote,
    query.des_aplicacion_lote);
GO

USE dbn1_stg_dhyf_u
GO

IF EXISTS (SELECT 1 FROM dbn1_stg_dhyf_u.INFORMATION_SCHEMA.ROUTINES WHERE ROUTINE_SCHEMA='dbo' AND ROUTINE_NAME='spn1_cargar_normalizado_ot_aplicaciones_lote' AND ROUTINE_TYPE='PROCEDURE')
DROP PROCEDURE dbo.spn1_cargar_normalizado_ot_aplicaciones_lote;
GO

CREATE PROCEDURE dbo.spn1_cargar_normalizado_ot_aplicaciones_lote(@logpadre int) AS
BEGIN

  DECLARE @procedure_name varchar(100)='dbn1_stg_dhyf_u.dbo.spn1_cargar_normalizado_ot_aplicaciones_lote'
  SET NOCOUNT ON;
  DECLARE @log int;
  EXECUTE @log = dbn1_stg_dhyf_u.dbo.spn1_apuntar_log @logpadre,@procedure_name;
  DECLARE @fecha_ultima_carga datetime=dbn1_stg_dhyf_u.dbo.fnn1_fecha_ultima_carga(@log);
  DECLARE @continuar_en_caso_error bit=0;
  IF @logpadre IS NOT NULL AND EXISTS (SELECT 1 AS expr1
  FROM dbn1_norm_dhyf_u.audit.tbn1_procedimientos_excluidos
  WHERE
    'dbn1_stg_dhyf_u.dbo.'+procedimiento=@procedure_name
    AND excluido=1
  ) BEGIN
    UPDATE dbn1_norm_dhyf_u.audit.tbn1_logs SET
      mensaje_error='EXCLUÍDO'
    WHERE
      id_log=@log;
    RETURN
  END
     BEGIN TRY

  ;WITH
  query AS (
    SELECT
      right(aplo.aux1_r13_clave_reg,2) AS cod_aplicacion_lote,
      aplo.aux1_r13_nomapl_au AS des_aplicacion_lote
    FROM dbn1_stg_dhyf_u.dbo.tbn1aux1_tb_r13 aplo
    GROUP BY
      right(aplo.aux1_r13_clave_reg,2),
      aplo.aux1_r13_nomapl_au
  )
  MERGE dbn1_norm_dhyf_u.dbo.tbn1_ot_aplicaciones_lote AS tbn1_ot_aplicaciones_lote
  USING query ON query.cod_aplicacion_lote=tbn1_ot_aplicaciones_lote.cod_aplicacion_lote
  WHEN MATCHED AND (tbn1_ot_aplicaciones_lote.es_indefinido=0
                    AND (tbn1_ot_aplicaciones_lote.des_aplicacion_lote<>query.des_aplicacion_lote OR (tbn1_ot_aplicaciones_lote.des_aplicacion_lote IS NULL AND query.des_aplicacion_lote IS NOT NULL) OR  (tbn1_ot_aplicaciones_lote.des_aplicacion_lote IS NOT NULL AND query.des_aplicacion_lote IS NULL)
                    OR (fec_baja IS NOT NULL))) THEN
    UPDATE SET
      des_aplicacion_lote=query.des_aplicacion_lote,
      fec_modificacion=getdate(),
      fec_baja=null
  WHEN NOT MATCHED THEN
    INSERT (cod_aplicacion_lote,des_aplicacion_lote,fec_alta,fec_modificacion) VALUES (
      query.cod_aplicacion_lote,
      query.des_aplicacion_lote,
      getdate(),
      getdate())
  WHEN NOT MATCHED BY SOURCE AND (tbn1_ot_aplicaciones_lote.es_indefinido=0
                                  AND fec_baja IS NULL) THEN
    UPDATE SET
      fec_baja=getdate(),
      fec_modificacion=getdate();

  EXECUTE dbn1_stg_dhyf_u.dbo.spn1_finalizar_log @log,@@ROWCOUNT;
   END TRY
  BEGIN CATCH
    EXECUTE dbn1_stg_dhyf_u.dbo.spn1_finalizar_log @log,null;
    UPDATE dbn1_norm_dhyf_u.audit.tbn1_logs SET
      mensaje_error=error_message(),
      procedimiento_error=error_procedure()
    WHERE
      id_log=@log;
    IF @continuar_en_caso_error=0 OR @logpadre IS NULL THROW
  END CATCH


END

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_secciones')
CREATE TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_secciones(
  id_seccion int IDENTITY(1,1),
  cod_seccion nvarchar(2) NOT NULL,
  des_seccion nvarchar(50) NOT NULL,
  es_indefinido bit,
  fec_alta datetime,
  fec_modificacion datetime,
  fec_baja datetime,
  CONSTRAINT uk_ot_secciones UNIQUE (cod_seccion),
  CONSTRAINT PK_tbn1_ot_secciones PRIMARY KEY CLUSTERED (id_seccion)
)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_secciones' AND COLUMN_NAME='id_seccion')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_secciones ADD id_seccion int

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_secciones' AND COLUMN_NAME='cod_seccion')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_secciones ADD cod_seccion nvarchar(2)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_secciones' AND COLUMN_NAME='des_seccion')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_secciones ADD des_seccion nvarchar(50)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_secciones' AND COLUMN_NAME='es_indefinido')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_secciones ADD es_indefinido bit

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_secciones' AND COLUMN_NAME='fec_alta')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_secciones ADD fec_alta datetime

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_secciones' AND COLUMN_NAME='fec_modificacion')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_secciones ADD fec_modificacion datetime

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_secciones' AND COLUMN_NAME='fec_baja')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_secciones ADD fec_baja datetime

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_secciones' AND COLUMN_NAME='es_indefinido' AND COLUMN_DEFAULT IS NULL)
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_secciones ADD CONSTRAINT DF_DBO_TBN1_OT_SECCIONES_ES_INDEFINIDO DEFAULT 0 FOR es_indefinido

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_secciones' AND COLUMN_NAME='id_seccion' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_secciones ALTER COLUMN id_seccion int NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_secciones' AND COLUMN_NAME='cod_seccion' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_secciones ALTER COLUMN cod_seccion nvarchar(2) NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_secciones' AND COLUMN_NAME='des_seccion' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_secciones ALTER COLUMN des_seccion nvarchar(50) NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_secciones' AND COLUMN_NAME='es_indefinido' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_secciones ALTER COLUMN es_indefinido bit NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_secciones' AND COLUMN_NAME='fec_alta' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_secciones ALTER COLUMN fec_alta datetime NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_secciones' AND COLUMN_NAME='fec_modificacion' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_secciones ALTER COLUMN fec_modificacion datetime NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_secciones' AND COLUMN_NAME='fec_baja' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_secciones ALTER COLUMN fec_baja datetime NULL

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_secciones' AND CONSTRAINT_NAME='PK_tbn1_ot_secciones')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_secciones ADD CONSTRAINT PK_tbn1_ot_secciones PRIMARY KEY CLUSTERED (id_seccion)

GO

;WITH
query AS (
  SELECT 1 AS es_indefinido,'99' AS cod_seccion,'Indefinida' AS des_seccion
)
MERGE dbn1_norm_dhyf_u.dbo.tbn1_ot_secciones AS tbn1_ot_secciones
USING query ON query.es_indefinido=tbn1_ot_secciones.es_indefinido
WHEN MATCHED AND ((tbn1_ot_secciones.cod_seccion<>query.cod_seccion OR (tbn1_ot_secciones.cod_seccion IS NULL AND query.cod_seccion IS NOT NULL) OR  (tbn1_ot_secciones.cod_seccion IS NOT NULL AND query.cod_seccion IS NULL)
                  OR tbn1_ot_secciones.des_seccion<>query.des_seccion OR (tbn1_ot_secciones.des_seccion IS NULL AND query.des_seccion IS NOT NULL) OR  (tbn1_ot_secciones.des_seccion IS NOT NULL AND query.des_seccion IS NULL))) THEN
  UPDATE SET
    cod_seccion=query.cod_seccion,
    des_seccion=query.des_seccion
WHEN NOT MATCHED THEN
  INSERT (es_indefinido,cod_seccion,des_seccion) VALUES (
    query.es_indefinido,
    query.cod_seccion,
    query.des_seccion);
GO

USE dbn1_stg_dhyf_u
GO

IF EXISTS (SELECT 1 FROM dbn1_stg_dhyf_u.INFORMATION_SCHEMA.ROUTINES WHERE ROUTINE_SCHEMA='dbo' AND ROUTINE_NAME='spn1_cargar_normalizado_ot_secciones' AND ROUTINE_TYPE='PROCEDURE')
DROP PROCEDURE dbo.spn1_cargar_normalizado_ot_secciones;
GO

CREATE PROCEDURE dbo.spn1_cargar_normalizado_ot_secciones(@logpadre int) AS
BEGIN

  DECLARE @procedure_name varchar(100)='dbn1_stg_dhyf_u.dbo.spn1_cargar_normalizado_ot_secciones'
  SET NOCOUNT ON;
  DECLARE @log int;
  EXECUTE @log = dbn1_stg_dhyf_u.dbo.spn1_apuntar_log @logpadre,@procedure_name;
  DECLARE @fecha_ultima_carga datetime=dbn1_stg_dhyf_u.dbo.fnn1_fecha_ultima_carga(@log);
  DECLARE @continuar_en_caso_error bit=0;
  IF @logpadre IS NOT NULL AND EXISTS (SELECT 1 AS expr1
  FROM dbn1_norm_dhyf_u.audit.tbn1_procedimientos_excluidos
  WHERE
    'dbn1_stg_dhyf_u.dbo.'+procedimiento=@procedure_name
    AND excluido=1
  ) BEGIN
    UPDATE dbn1_norm_dhyf_u.audit.tbn1_logs SET
      mensaje_error='EXCLUÍDO'
    WHERE
      id_log=@log;
    RETURN
  END
     BEGIN TRY

  ;WITH
  query AS (
    SELECT
      right(aux1_r51_clave_reg,2) AS cod_seccion,
      sec.aux1_r51_nomc51_au AS des_seccion
    FROM dbn1_stg_dhyf_u.dbo.tbn1aux1_tb_r51 sec
    GROUP BY
      right(aux1_r51_clave_reg,2),
      sec.aux1_r51_nomc51_au
  )
  MERGE dbn1_norm_dhyf_u.dbo.tbn1_ot_secciones AS tbn1_ot_secciones
  USING query ON query.cod_seccion=tbn1_ot_secciones.cod_seccion
  WHEN MATCHED AND (tbn1_ot_secciones.es_indefinido=0
                    AND (tbn1_ot_secciones.des_seccion<>query.des_seccion OR (tbn1_ot_secciones.des_seccion IS NULL AND query.des_seccion IS NOT NULL) OR  (tbn1_ot_secciones.des_seccion IS NOT NULL AND query.des_seccion IS NULL)
                    OR (fec_baja IS NOT NULL))) THEN
    UPDATE SET
      des_seccion=query.des_seccion,
      fec_modificacion=getdate(),
      fec_baja=null
  WHEN NOT MATCHED THEN
    INSERT (cod_seccion,des_seccion,fec_alta,fec_modificacion) VALUES (
      query.cod_seccion,
      query.des_seccion,
      getdate(),
      getdate())
  WHEN NOT MATCHED BY SOURCE AND (tbn1_ot_secciones.es_indefinido=0
                                  AND fec_baja IS NULL) THEN
    UPDATE SET
      fec_baja=getdate(),
      fec_modificacion=getdate();

  EXECUTE dbn1_stg_dhyf_u.dbo.spn1_finalizar_log @log,@@ROWCOUNT;
   END TRY
  BEGIN CATCH
    EXECUTE dbn1_stg_dhyf_u.dbo.spn1_finalizar_log @log,null;
    UPDATE dbn1_norm_dhyf_u.audit.tbn1_logs SET
      mensaje_error=error_message(),
      procedimiento_error=error_procedure()
    WHERE
      id_log=@log;
    IF @continuar_en_caso_error=0 OR @logpadre IS NULL THROW
  END CATCH


END

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_entidades')
CREATE TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_entidades(
  id_entidad int IDENTITY(1,1),
  entidad nvarchar(2) NOT NULL,
  des_entidad nvarchar(50) NOT NULL,
  es_indefinido bit,
  fec_alta datetime,
  fec_modificacion datetime,
  fec_baja datetime,
  CONSTRAINT uk_ot_entidades UNIQUE (entidad),
  CONSTRAINT PK_tbn1_ot_entidades PRIMARY KEY CLUSTERED (id_entidad)
)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_entidades' AND COLUMN_NAME='id_entidad')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_entidades ADD id_entidad int

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_entidades' AND COLUMN_NAME='entidad')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_entidades ADD entidad nvarchar(2)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_entidades' AND COLUMN_NAME='des_entidad')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_entidades ADD des_entidad nvarchar(50)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_entidades' AND COLUMN_NAME='es_indefinido')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_entidades ADD es_indefinido bit

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_entidades' AND COLUMN_NAME='fec_alta')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_entidades ADD fec_alta datetime

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_entidades' AND COLUMN_NAME='fec_modificacion')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_entidades ADD fec_modificacion datetime

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_entidades' AND COLUMN_NAME='fec_baja')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_entidades ADD fec_baja datetime

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_entidades' AND COLUMN_NAME='es_indefinido' AND COLUMN_DEFAULT IS NULL)
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_entidades ADD CONSTRAINT DF_DBO_TBN1_OT_ENTIDADES_ES_INDEFINIDO DEFAULT 0 FOR es_indefinido

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_entidades' AND COLUMN_NAME='id_entidad' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_entidades ALTER COLUMN id_entidad int NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_entidades' AND COLUMN_NAME='entidad' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_entidades ALTER COLUMN entidad nvarchar(2) NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_entidades' AND COLUMN_NAME='des_entidad' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_entidades ALTER COLUMN des_entidad nvarchar(50) NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_entidades' AND COLUMN_NAME='es_indefinido' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_entidades ALTER COLUMN es_indefinido bit NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_entidades' AND COLUMN_NAME='fec_alta' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_entidades ALTER COLUMN fec_alta datetime NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_entidades' AND COLUMN_NAME='fec_modificacion' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_entidades ALTER COLUMN fec_modificacion datetime NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_entidades' AND COLUMN_NAME='fec_baja' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_entidades ALTER COLUMN fec_baja datetime NULL

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_entidades' AND CONSTRAINT_NAME='PK_tbn1_ot_entidades')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_entidades ADD CONSTRAINT PK_tbn1_ot_entidades PRIMARY KEY CLUSTERED (id_entidad)

GO

;WITH
query AS (
  SELECT 1 AS es_indefinido,'ZZ' AS entidad,'Indefinida' AS des_entidad
)
MERGE dbn1_norm_dhyf_u.dbo.tbn1_ot_entidades AS tbn1_ot_entidades
USING query ON query.es_indefinido=tbn1_ot_entidades.es_indefinido
WHEN MATCHED AND ((tbn1_ot_entidades.entidad<>query.entidad OR (tbn1_ot_entidades.entidad IS NULL AND query.entidad IS NOT NULL) OR  (tbn1_ot_entidades.entidad IS NOT NULL AND query.entidad IS NULL)
                  OR tbn1_ot_entidades.des_entidad<>query.des_entidad OR (tbn1_ot_entidades.des_entidad IS NULL AND query.des_entidad IS NOT NULL) OR  (tbn1_ot_entidades.des_entidad IS NOT NULL AND query.des_entidad IS NULL))) THEN
  UPDATE SET
    entidad=query.entidad,
    des_entidad=query.des_entidad
WHEN NOT MATCHED THEN
  INSERT (es_indefinido,entidad,des_entidad) VALUES (
    query.es_indefinido,
    query.entidad,
    query.des_entidad);
GO

USE dbn1_stg_dhyf_u
GO

IF EXISTS (SELECT 1 FROM dbn1_stg_dhyf_u.INFORMATION_SCHEMA.ROUTINES WHERE ROUTINE_SCHEMA='dbo' AND ROUTINE_NAME='spn1_cargar_normalizado_ot_entidades' AND ROUTINE_TYPE='PROCEDURE')
DROP PROCEDURE dbo.spn1_cargar_normalizado_ot_entidades;
GO

CREATE PROCEDURE dbo.spn1_cargar_normalizado_ot_entidades(@logpadre int) AS
BEGIN

  DECLARE @procedure_name varchar(100)='dbn1_stg_dhyf_u.dbo.spn1_cargar_normalizado_ot_entidades'
  SET NOCOUNT ON;
  DECLARE @log int;
  EXECUTE @log = dbn1_stg_dhyf_u.dbo.spn1_apuntar_log @logpadre,@procedure_name;
  DECLARE @fecha_ultima_carga datetime=dbn1_stg_dhyf_u.dbo.fnn1_fecha_ultima_carga(@log);
  DECLARE @continuar_en_caso_error bit=0;
  IF @logpadre IS NOT NULL AND EXISTS (SELECT 1 AS expr1
  FROM dbn1_norm_dhyf_u.audit.tbn1_procedimientos_excluidos
  WHERE
    'dbn1_stg_dhyf_u.dbo.'+procedimiento=@procedure_name
    AND excluido=1
  ) BEGIN
    UPDATE dbn1_norm_dhyf_u.audit.tbn1_logs SET
      mensaje_error='EXCLUÍDO'
    WHERE
      id_log=@log;
    RETURN
  END
     BEGIN TRY

  ;WITH
  query AS (
    SELECT
      entidad,
      des_entidad
    FROM
      (SELECT 'IC' entidad,'Autoliquidacion Ingresada' des_entidad
       UNION ALL SELECT 'S1','Liquidaciones realizadas desde Gestion'
       UNION ALL SELECT 'ZN','Recibos cargados desde Censos (IBI, etc...)') a
    GROUP BY
      entidad,
      des_entidad
  )
  MERGE dbn1_norm_dhyf_u.dbo.tbn1_ot_entidades AS tbn1_ot_entidades
  USING query ON query.entidad=tbn1_ot_entidades.entidad
  WHEN MATCHED AND (tbn1_ot_entidades.es_indefinido=0
                    AND (tbn1_ot_entidades.des_entidad<>query.des_entidad OR (tbn1_ot_entidades.des_entidad IS NULL AND query.des_entidad IS NOT NULL) OR  (tbn1_ot_entidades.des_entidad IS NOT NULL AND query.des_entidad IS NULL)
                    OR (fec_baja IS NOT NULL))) THEN
    UPDATE SET
      des_entidad=query.des_entidad,
      fec_modificacion=getdate(),
      fec_baja=null
  WHEN NOT MATCHED THEN
    INSERT (entidad,des_entidad,fec_alta,fec_modificacion) VALUES (
      query.entidad,
      query.des_entidad,
      getdate(),
      getdate())
  WHEN NOT MATCHED BY SOURCE AND (tbn1_ot_entidades.es_indefinido=0
                                  AND fec_baja IS NULL) THEN
    UPDATE SET
      fec_baja=getdate(),
      fec_modificacion=getdate();

  EXECUTE dbn1_stg_dhyf_u.dbo.spn1_finalizar_log @log,@@ROWCOUNT;
   END TRY
  BEGIN CATCH
    EXECUTE dbn1_stg_dhyf_u.dbo.spn1_finalizar_log @log,null;
    UPDATE dbn1_norm_dhyf_u.audit.tbn1_logs SET
      mensaje_error=error_message(),
      procedimiento_error=error_procedure()
    WHERE
      id_log=@log;
    IF @continuar_en_caso_error=0 OR @logpadre IS NULL THROW
  END CATCH


END

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_origenes')
CREATE TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_origenes(
  id_origen_liquidacion int IDENTITY(1,1),
  cod_origen varchar(2) NOT NULL,
  des_origen varchar(30) NOT NULL,
  es_indefinido bit,
  fec_alta datetime,
  fec_modificacion datetime,
  fec_baja datetime,
  CONSTRAINT uk_ot_origenes UNIQUE (cod_origen),
  CONSTRAINT PK_tbn1_ot_origenes PRIMARY KEY CLUSTERED (id_origen_liquidacion)
)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_origenes' AND COLUMN_NAME='id_origen_liquidacion')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_origenes ADD id_origen_liquidacion int

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_origenes' AND COLUMN_NAME='cod_origen')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_origenes ADD cod_origen varchar(2)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_origenes' AND COLUMN_NAME='des_origen')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_origenes ADD des_origen varchar(30)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_origenes' AND COLUMN_NAME='es_indefinido')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_origenes ADD es_indefinido bit

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_origenes' AND COLUMN_NAME='fec_alta')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_origenes ADD fec_alta datetime

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_origenes' AND COLUMN_NAME='fec_modificacion')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_origenes ADD fec_modificacion datetime

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_origenes' AND COLUMN_NAME='fec_baja')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_origenes ADD fec_baja datetime

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_origenes' AND COLUMN_NAME='es_indefinido' AND COLUMN_DEFAULT IS NULL)
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_origenes ADD CONSTRAINT DF_DBO_TBN1_OT_ORIGENES_ES_INDEFINIDO DEFAULT 0 FOR es_indefinido

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_origenes' AND COLUMN_NAME='id_origen_liquidacion' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_origenes ALTER COLUMN id_origen_liquidacion int NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_origenes' AND COLUMN_NAME='cod_origen' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_origenes ALTER COLUMN cod_origen varchar(2) NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_origenes' AND COLUMN_NAME='des_origen' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_origenes ALTER COLUMN des_origen varchar(30) NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_origenes' AND COLUMN_NAME='es_indefinido' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_origenes ALTER COLUMN es_indefinido bit NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_origenes' AND COLUMN_NAME='fec_alta' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_origenes ALTER COLUMN fec_alta datetime NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_origenes' AND COLUMN_NAME='fec_modificacion' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_origenes ALTER COLUMN fec_modificacion datetime NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_origenes' AND COLUMN_NAME='fec_baja' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_origenes ALTER COLUMN fec_baja datetime NULL

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_origenes' AND CONSTRAINT_NAME='PK_tbn1_ot_origenes')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_origenes ADD CONSTRAINT PK_tbn1_ot_origenes PRIMARY KEY CLUSTERED (id_origen_liquidacion)

GO

;WITH
query AS (
  SELECT 1 AS es_indefinido,'' AS cod_origen,'Indefinido' AS des_origen
)
MERGE dbn1_norm_dhyf_u.dbo.tbn1_ot_origenes AS tbn1_ot_origenes
USING query ON query.es_indefinido=tbn1_ot_origenes.es_indefinido
WHEN MATCHED AND ((tbn1_ot_origenes.cod_origen<>query.cod_origen OR (tbn1_ot_origenes.cod_origen IS NULL AND query.cod_origen IS NOT NULL) OR  (tbn1_ot_origenes.cod_origen IS NOT NULL AND query.cod_origen IS NULL)
                  OR tbn1_ot_origenes.des_origen<>query.des_origen OR (tbn1_ot_origenes.des_origen IS NULL AND query.des_origen IS NOT NULL) OR  (tbn1_ot_origenes.des_origen IS NOT NULL AND query.des_origen IS NULL))) THEN
  UPDATE SET
    cod_origen=query.cod_origen,
    des_origen=query.des_origen
WHEN NOT MATCHED THEN
  INSERT (es_indefinido,cod_origen,des_origen) VALUES (
    query.es_indefinido,
    query.cod_origen,
    query.des_origen);
GO

USE dbn1_stg_dhyf_u
GO

IF EXISTS (SELECT 1 FROM dbn1_stg_dhyf_u.INFORMATION_SCHEMA.ROUTINES WHERE ROUTINE_SCHEMA='dbo' AND ROUTINE_NAME='spn1_cargar_normalizado_ot_origenes' AND ROUTINE_TYPE='PROCEDURE')
DROP PROCEDURE dbo.spn1_cargar_normalizado_ot_origenes;
GO

CREATE PROCEDURE dbo.spn1_cargar_normalizado_ot_origenes(@logpadre int) AS
BEGIN

  DECLARE @procedure_name varchar(100)='dbn1_stg_dhyf_u.dbo.spn1_cargar_normalizado_ot_origenes'
  SET NOCOUNT ON;
  DECLARE @log int;
  EXECUTE @log = dbn1_stg_dhyf_u.dbo.spn1_apuntar_log @logpadre,@procedure_name;
  DECLARE @fecha_ultima_carga datetime=dbn1_stg_dhyf_u.dbo.fnn1_fecha_ultima_carga(@log);
  DECLARE @continuar_en_caso_error bit=0;
  IF @logpadre IS NOT NULL AND EXISTS (SELECT 1 AS expr1
  FROM dbn1_norm_dhyf_u.audit.tbn1_procedimientos_excluidos
  WHERE
    'dbn1_stg_dhyf_u.dbo.'+procedimiento=@procedure_name
    AND excluido=1
  ) BEGIN
    UPDATE dbn1_norm_dhyf_u.audit.tbn1_logs SET
      mensaje_error='EXCLUÍDO'
    WHERE
      id_log=@log;
    RETURN
  END
     BEGIN TRY

  ;WITH
  query AS (
    SELECT
      cod_origen,
      des_origen
    FROM
      (SELECT 'SI' cod_origen,'Sanciones inspección' des_origen
       UNION ALL SELECT 'SG','Sanciones gestión'
       UNION ALL SELECT 'SO','Sanciones otros'
       UNION ALL SELECT 'LO','Liquidaciones otros'
       UNION ALL SELECT 'LI','Liquidaciones inspección'
       UNION ALL SELECT 'AU','Autoliquidaciones'
       UNION ALL SELECT 'LG','Liquidaciones gestión') a
    GROUP BY
      cod_origen,
      des_origen
  )
  MERGE dbn1_norm_dhyf_u.dbo.tbn1_ot_origenes AS tbn1_ot_origenes
  USING query ON query.cod_origen=tbn1_ot_origenes.cod_origen
  WHEN MATCHED AND (tbn1_ot_origenes.es_indefinido=0
                    AND (tbn1_ot_origenes.des_origen<>query.des_origen OR (tbn1_ot_origenes.des_origen IS NULL AND query.des_origen IS NOT NULL) OR  (tbn1_ot_origenes.des_origen IS NOT NULL AND query.des_origen IS NULL)
                    OR (fec_baja IS NOT NULL))) THEN
    UPDATE SET
      des_origen=query.des_origen,
      fec_modificacion=getdate(),
      fec_baja=null
  WHEN NOT MATCHED THEN
    INSERT (cod_origen,des_origen,fec_alta,fec_modificacion) VALUES (
      query.cod_origen,
      query.des_origen,
      getdate(),
      getdate())
  WHEN NOT MATCHED BY SOURCE AND (tbn1_ot_origenes.es_indefinido=0
                                  AND fec_baja IS NULL) THEN
    UPDATE SET
      fec_baja=getdate(),
      fec_modificacion=getdate();

  EXECUTE dbn1_stg_dhyf_u.dbo.spn1_finalizar_log @log,@@ROWCOUNT;
   END TRY
  BEGIN CATCH
    EXECUTE dbn1_stg_dhyf_u.dbo.spn1_finalizar_log @log,null;
    UPDATE dbn1_norm_dhyf_u.audit.tbn1_logs SET
      mensaje_error=error_message(),
      procedimiento_error=error_procedure()
    WHERE
      id_log=@log;
    IF @continuar_en_caso_error=0 OR @logpadre IS NULL THROW
  END CATCH


END

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_estado_situacion')
CREATE TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_estado_situacion(
  id_estado_situacion int IDENTITY(1,1),
  cod_estado_situacion varchar(2) NOT NULL,
  des_estado_situacion varchar(30) NOT NULL,
  es_indefinido bit,
  fec_alta datetime,
  fec_modificacion datetime,
  fec_baja datetime,
  CONSTRAINT uk_ot_estado_situacion UNIQUE (cod_estado_situacion),
  CONSTRAINT PK_tbn1_ot_estado_situacion PRIMARY KEY CLUSTERED (id_estado_situacion)
)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_estado_situacion' AND COLUMN_NAME='id_estado_situacion')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_estado_situacion ADD id_estado_situacion int

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_estado_situacion' AND COLUMN_NAME='cod_estado_situacion')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_estado_situacion ADD cod_estado_situacion varchar(2)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_estado_situacion' AND COLUMN_NAME='des_estado_situacion')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_estado_situacion ADD des_estado_situacion varchar(30)

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_estado_situacion' AND COLUMN_NAME='es_indefinido')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_estado_situacion ADD es_indefinido bit

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_estado_situacion' AND COLUMN_NAME='fec_alta')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_estado_situacion ADD fec_alta datetime

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_estado_situacion' AND COLUMN_NAME='fec_modificacion')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_estado_situacion ADD fec_modificacion datetime

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_estado_situacion' AND COLUMN_NAME='fec_baja')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_estado_situacion ADD fec_baja datetime

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_estado_situacion' AND COLUMN_NAME='es_indefinido' AND COLUMN_DEFAULT IS NULL)
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_estado_situacion ADD CONSTRAINT DF_DBO_TBN1_OT_ESTADO_SITUACION_ES_INDEFINIDO DEFAULT 0 FOR es_indefinido

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_estado_situacion' AND COLUMN_NAME='id_estado_situacion' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_estado_situacion ALTER COLUMN id_estado_situacion int NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_estado_situacion' AND COLUMN_NAME='cod_estado_situacion' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_estado_situacion ALTER COLUMN cod_estado_situacion varchar(2) NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_estado_situacion' AND COLUMN_NAME='des_estado_situacion' AND IS_NULLABLE='YES')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_estado_situacion ALTER COLUMN des_estado_situacion varchar(30) NOT NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_estado_situacion' AND COLUMN_NAME='es_indefinido' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_estado_situacion ALTER COLUMN es_indefinido bit NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_estado_situacion' AND COLUMN_NAME='fec_alta' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_estado_situacion ALTER COLUMN fec_alta datetime NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_estado_situacion' AND COLUMN_NAME='fec_modificacion' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_estado_situacion ALTER COLUMN fec_modificacion datetime NULL

GO

IF EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_estado_situacion' AND COLUMN_NAME='fec_baja' AND IS_NULLABLE='NO')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_estado_situacion ALTER COLUMN fec_baja datetime NULL

GO

IF NOT EXISTS (SELECT 1 FROM dbn1_norm_dhyf_u.INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='tbn1_ot_estado_situacion' AND CONSTRAINT_NAME='PK_tbn1_ot_estado_situacion')
ALTER TABLE dbn1_norm_dhyf_u.dbo.tbn1_ot_estado_situacion ADD CONSTRAINT PK_tbn1_ot_estado_situacion PRIMARY KEY CLUSTERED (id_estado_situacion)

GO

;WITH
query AS (
  SELECT 1 AS es_indefinido,'' AS cod_estado_situacion,'Otros' AS des_estado_situacion
)
MERGE dbn1_norm_dhyf_u.dbo.tbn1_ot_estado_situacion AS tbn1_ot_estado_situacion
USING query ON query.es_indefinido=tbn1_ot_estado_situacion.es_indefinido
WHEN MATCHED AND ((tbn1_ot_estado_situacion.cod_estado_situacion<>query.cod_estado_situacion OR (tbn1_ot_estado_situacion.cod_estado_situacion IS NULL AND query.cod_estado_situacion IS NOT NULL) OR  (tbn1_ot_estado_situacion.cod_estado_situacion IS NOT NULL AND query.cod_estado_situacion IS NULL)
                  OR tbn1_ot_estado_situacion.des_estado_situacion<>query.des_estado_situacion OR (tbn1_ot_estado_situacion.des_estado_situacion IS NULL AND query.des_estado_situacion IS NOT NULL) OR  (tbn1_ot_estado_situacion.des_estado_situacion IS NOT NULL AND query.des_estado_situacion IS NULL))) THEN
  UPDATE SET
    cod_estado_situacion=query.cod_estado_situacion,
    des_estado_situacion=query.des_estado_situacion
WHEN NOT MATCHED THEN
  INSERT (es_indefinido,cod_estado_situacion,des_estado_situacion) VALUES (
    query.es_indefinido,
    query.cod_estado_situacion,
    query.des_estado_situacion);
GO

USE dbn1_stg_dhyf_u
GO

IF EXISTS (SELECT 1 FROM dbn1_stg_dhyf_u.INFORMATION_SCHEMA.ROUTINES WHERE ROUTINE_SCHEMA='dbo' AND ROUTINE_NAME='spn1_cargar_normalizado_ot_estado_situacion' AND ROUTINE_TYPE='PROCEDURE')
DROP PROCEDURE dbo.spn1_cargar_normalizado_ot_estado_situacion;
GO

CREATE PROCEDURE dbo.spn1_cargar_normalizado_ot_estado_situacion(@logpadre int) AS
BEGIN

  DECLARE @procedure_name varchar(100)='dbn1_stg_dhyf_u.dbo.spn1_cargar_normalizado_ot_estado_situacion'
  SET NOCOUNT ON;
  DECLARE @log int;
  EXECUTE @log = dbn1_stg_dhyf_u.dbo.spn1_apuntar_log @logpadre,@procedure_name;
  DECLARE @fecha_ultima_carga datetime=dbn1_stg_dhyf_u.dbo.fnn1_fecha_ultima_carga(@log);
  DECLARE @continuar_en_caso_error bit=0;
  IF @logpadre IS NOT NULL AND EXISTS (SELECT 1 AS expr1
  FROM dbn1_norm_dhyf_u.audit.tbn1_procedimientos_excluidos
  WHERE
    'dbn1_stg_dhyf_u.dbo.'+procedimiento=@procedure_name
    AND excluido=1
  ) BEGIN
    UPDATE dbn1_norm_dhyf_u.audit.tbn1_logs SET
      mensaje_error='EXCLUÍDO'
    WHERE
      id_log=@log;
    RETURN
  END
     BEGIN TRY

  ;WITH
  query AS (
    SELECT
      cod_estado_situacion,
      des_estado_situacion
    FROM
      (SELECT 'EA' cod_estado_situacion,'Ejecutiva aplazada' des_estado_situacion
       UNION ALL SELECT 'EJ','Ejecutiva pendiente'
       UNION ALL SELECT 'ES','Ejecutiva suspendida'
       UNION ALL SELECT 'VA','Voluntaria aplazada'
       UNION ALL SELECT 'VO','Voluntaria pendiente'
       UNION ALL SELECT 'VS','Voluntaria suspendida') a
    GROUP BY
      cod_estado_situacion,
      des_estado_situacion
  )
  MERGE dbn1_norm_dhyf_u.dbo.tbn1_ot_estado_situacion AS tbn1_ot_estado_situacion
  USING query ON query.cod_estado_situacion=tbn1_ot_estado_situacion.cod_estado_situacion
  WHEN MATCHED AND (tbn1_ot_estado_situacion.es_indefinido=0
                    AND (tbn1_ot_estado_situacion.des_estado_situacion<>query.des_estado_situacion OR (tbn1_ot_estado_situacion.des_estado_situacion IS NULL AND query.des_estado_situacion IS NOT NULL) OR  (tbn1_ot_estado_situacion.des_estado_situacion IS NOT NULL AND query.des_estado_situacion IS NULL)
                    OR (fec_baja IS NOT NULL))) THEN
    UPDATE SET
      des_estado_situacion=query.des_estado_situacion,
      fec_modificacion=getdate(),
      fec_baja=null
  WHEN NOT MATCHED THEN
    INSERT (cod_estado_situacion,des_estado_situacion,fec_alta,fec_modificacion) VALUES (
      query.cod_estado_situacion,
      query.des_estado_situacion,
      getdate(),
      getdate())
  WHEN NOT MATCHED BY SOURCE AND (tbn1_ot_estado_situacion.es_indefinido=0
                                  AND fec_baja IS NULL) THEN
    UPDATE SET
      fec_baja=getdate(),
      fec_modificacion=getdate();

  EXECUTE dbn1_stg_dhyf_u.dbo.spn1_finalizar_log @log,@@ROWCOUNT;
   END TRY
  BEGIN CATCH
    EXECUTE dbn1_stg_dhyf_u.dbo.spn1_finalizar_log @log,null;
    UPDATE dbn1_norm_dhyf_u.audit.tbn1_logs SET
      mensaje_error=error_message(),
      procedimiento_error=error_procedure()
    WHERE
      id_log=@log;
    IF @continuar_en_caso_error=0 OR @logpadre IS NULL THROW
  END CATCH


END

GO

USE dbn1_stg_dhyf_u
GO

IF EXISTS (SELECT 1 FROM dbn1_stg_dhyf_u.INFORMATION_SCHEMA.ROUTINES WHERE ROUTINE_SCHEMA='dbo' AND ROUTINE_NAME='spn1_cargar_normalizado_maestros' AND ROUTINE_TYPE='PROCEDURE')
DROP PROCEDURE dbo.spn1_cargar_normalizado_maestros;
GO

CREATE PROCEDURE dbo.spn1_cargar_normalizado_maestros(@logpadre int) AS
BEGIN

  DECLARE @procedure_name varchar(100)='dbn1_stg_dhyf_u.dbo.spn1_cargar_normalizado_maestros'
  SET NOCOUNT ON;
  DECLARE @log int;
  EXECUTE @log = dbn1_stg_dhyf_u.dbo.spn1_apuntar_log @logpadre,@procedure_name;
  DECLARE @fecha_ultima_carga datetime=dbn1_stg_dhyf_u.dbo.fnn1_fecha_ultima_carga(@log);
  DECLARE @continuar_en_caso_error bit=0;
  IF @logpadre IS NOT NULL AND EXISTS (SELECT 1 AS expr1
  FROM dbn1_norm_dhyf_u.audit.tbn1_procedimientos_excluidos
  WHERE
    'dbn1_stg_dhyf_u.dbo.'+procedimiento=@procedure_name
    AND excluido=1
  ) BEGIN
    UPDATE dbn1_norm_dhyf_u.audit.tbn1_logs SET
      mensaje_error='EXCLUÍDO'
    WHERE
      id_log=@log;
    RETURN
  END
     BEGIN TRY

  EXECUTE dbn1_stg_dhyf_u.dbo.spn1_cargar_normalizado_ot_tipos_ingreso @log;
  EXECUTE dbn1_stg_dhyf_u.dbo.spn1_cargar_normalizado_ot_claves_ingreso @log;
  EXECUTE dbn1_stg_dhyf_u.dbo.spn1_cargar_normalizado_ot_claves_contables @log;
  EXECUTE dbn1_stg_dhyf_u.dbo.spn1_cargar_normalizado_ot_grupos_subgrupos_subconceptos_lista @log;
  EXECUTE dbn1_stg_dhyf_u.dbo.spn1_cargar_normalizado_ot_grupos_subgrupos_subconceptos_no_lista @log;
  EXECUTE dbn1_stg_dhyf_u.dbo.spn1_cargar_normalizado_ot_modos_ingreso @log;
  EXECUTE dbn1_stg_dhyf_u.dbo.spn1_cargar_normalizado_ot_situaciones @log;
  EXECUTE dbn1_stg_dhyf_u.dbo.spn1_cargar_normalizado_ot_codigos_operacion @log;
  EXECUTE dbn1_stg_dhyf_u.dbo.spn1_cargar_normalizado_ot_tipos_compensacion @log;
  EXECUTE dbn1_stg_dhyf_u.dbo.spn1_cargar_normalizado_ot_tipos_responsable @log;
  EXECUTE dbn1_stg_dhyf_u.dbo.spn1_cargar_normalizado_ot_fases_proceso @log;
  EXECUTE dbn1_stg_dhyf_u.dbo.spn1_cargar_normalizado_ot_estados @log;
  EXECUTE dbn1_stg_dhyf_u.dbo.spn1_cargar_normalizado_ot_oficinas @log;
  EXECUTE dbn1_stg_dhyf_u.dbo.spn1_cargar_normalizado_ot_antiguedad_contraido @log;
  EXECUTE dbn1_stg_dhyf_u.dbo.spn1_cargar_normalizado_ot_formatos_ingreso @log;
  EXECUTE dbn1_stg_dhyf_u.dbo.spn1_cargar_normalizado_ot_aplicaciones_lote @log;
  EXECUTE dbn1_stg_dhyf_u.dbo.spn1_cargar_normalizado_ot_secciones @log;
  EXECUTE dbn1_stg_dhyf_u.dbo.spn1_cargar_normalizado_ot_entidades @log;
  EXECUTE dbn1_stg_dhyf_u.dbo.spn1_cargar_normalizado_ot_origenes @log;
  EXECUTE dbn1_stg_dhyf_u.dbo.spn1_cargar_normalizado_ot_estado_situacion @log;

  EXECUTE dbn1_stg_dhyf_u.dbo.spn1_finalizar_log @log,@@ROWCOUNT;
   END TRY
  BEGIN CATCH
    EXECUTE dbn1_stg_dhyf_u.dbo.spn1_finalizar_log @log,null;
    UPDATE dbn1_norm_dhyf_u.audit.tbn1_logs SET
      mensaje_error=error_message(),
      procedimiento_error=error_procedure()
    WHERE
      id_log=@log;
    IF @continuar_en_caso_error=0 OR @logpadre IS NULL THROW
  END CATCH


END

GO

;WITH
query AS (
  SELECT
    1 AS es_indefinido,
    situacion.id_situacion AS id_situacion,
    tipo_ingreso.id_tipo_ingreso AS id_tipo_ingreso,
    codigo_operacion.id_codigo_operacion AS id_codigo_operacion,
    tipo_compensacion.id_tipo_compensacion AS id_tipo_compensacion,
    tipo_responsable.id_tipo_responsable AS id_tipo_responsable,
    modo_ingreso.id_modo_ingreso AS id_modo_ingreso,
    fase_proceso.id_fase_proceso AS id_fase_proceso,
    clave_contable.id_clave_contable AS id_clave_contable,
    subcon.id_grupo_subgrupo_subconcepto AS id_grupo_subgrupo_subconcepto,
    antig.id_antiguedad AS id_antiguedad,
    ofi.id_oficina AS id_oficina,
    est.id_estado AS id_estado,
    foin.id_formato_ingreso AS id_formato_ingreso,
    aplo.id_aplicacion_lote AS id_aplicacion_lote,
    sec.id_seccion AS id_seccion,
    ent.id_entidad AS id_entidad,
    clin.id_clave_ingreso AS id_clave_ingreso,
    orig.id_origen_liquidacion AS id_origen_liquidacion,
    estsit.id_estado_situacion AS id_estado_situacion
  FROM dbn1_norm_dhyf_u.dbo.tbn1_tipos_documento tipos_documento
  CROSS JOIN dbn1_norm_dhyf_u.dbo.tbn1_ot_situaciones situacion
  CROSS JOIN dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_ingreso tipo_ingreso
  CROSS JOIN dbn1_norm_dhyf_u.dbo.tbn1_ot_codigos_operacion codigo_operacion
  CROSS JOIN dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_compensacion tipo_compensacion
  CROSS JOIN dbn1_norm_dhyf_u.dbo.tbn1_ot_tipos_responsable tipo_responsable
  CROSS JOIN dbn1_norm_dhyf_u.dbo.tbn1_ot_modos_ingreso modo_ingreso
  CROSS JOIN dbn1_norm_dhyf_u.dbo.tbn1_ot_fases_proceso fase_proceso
  CROSS JOIN dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_contables clave_contable
  CROSS JOIN dbn1_norm_dhyf_u.dbo.tbn1_ot_grupos_subgrupos_subconceptos subcon
  CROSS JOIN dbn1_norm_dhyf_u.dbo.tbn1_ot_antiguedad_contraido antig
  CROSS JOIN dbn1_norm_dhyf_u.dbo.tbn1_ot_oficinas ofi
  CROSS JOIN dbn1_norm_dhyf_u.dbo.tbn1_ot_estados est
  CROSS JOIN dbn1_norm_dhyf_u.dbo.tbn1_ot_formatos_ingreso foin
  CROSS JOIN dbn1_norm_dhyf_u.dbo.tbn1_ot_aplicaciones_lote aplo
  CROSS JOIN dbn1_norm_dhyf_u.dbo.tbn1_ot_secciones sec
  CROSS JOIN dbn1_norm_dhyf_u.dbo.tbn1_ot_entidades ent
  CROSS JOIN dbn1_norm_dhyf_u.dbo.tbn1_ot_claves_ingreso clin
  CROSS JOIN dbn1_norm_dhyf_u.dbo.tbn1_ot_origenes orig
  CROSS JOIN dbn1_norm_dhyf_u.dbo.tbn1_ot_estado_situacion estsit
  WHERE
    tipos_documento.es_indefinido=1
    AND situacion.es_indefinido=1
    AND tipo_ingreso.es_indefinido=1
    AND codigo_operacion.es_indefinido=1
    AND tipo_compensacion.es_indefinido=1
    AND tipo_responsable.es_indefinido=1
    AND modo_ingreso.es_indefinido=1
    AND fase_proceso.es_indefinido=1
    AND clave_contable.es_indefinido=1
    AND subcon.es_indefinido=1
    AND antig.es_indefinido=1
    AND ofi.es_indefinido=1
    AND est.es_indefinido=1
    AND foin.es_indefinido=1
    AND aplo.es_indefinido=1
    AND sec.es_indefinido=1
    AND ent.es_indefinido=1
    AND clin.es_indefinido=1
    AND orig.es_indefinido=1
    AND estsit.es_indefinido=1
)
MERGE dbn1_norm_dhyf_u.dbo.tbn1_indefinidos AS tbn1_indefinidos
USING query ON query.es_indefinido=tbn1_indefinidos.es_indefinido
WHEN MATCHED AND ((tbn1_indefinidos.id_situacion<>query.id_situacion OR (tbn1_indefinidos.id_situacion IS NULL AND query.id_situacion IS NOT NULL) OR  (tbn1_indefinidos.id_situacion IS NOT NULL AND query.id_situacion IS NULL)
                  OR tbn1_indefinidos.id_tipo_ingreso<>query.id_tipo_ingreso OR (tbn1_indefinidos.id_tipo_ingreso IS NULL AND query.id_tipo_ingreso IS NOT NULL) OR  (tbn1_indefinidos.id_tipo_ingreso IS NOT NULL AND query.id_tipo_ingreso IS NULL)
                  OR tbn1_indefinidos.id_codigo_operacion<>query.id_codigo_operacion OR (tbn1_indefinidos.id_codigo_operacion IS NULL AND query.id_codigo_operacion IS NOT NULL) OR  (tbn1_indefinidos.id_codigo_operacion IS NOT NULL AND query.id_codigo_operacion IS NULL)
                  OR tbn1_indefinidos.id_tipo_compensacion<>query.id_tipo_compensacion OR (tbn1_indefinidos.id_tipo_compensacion IS NULL AND query.id_tipo_compensacion IS NOT NULL) OR  (tbn1_indefinidos.id_tipo_compensacion IS NOT NULL AND query.id_tipo_compensacion IS NULL)
                  OR tbn1_indefinidos.id_tipo_responsable<>query.id_tipo_responsable OR (tbn1_indefinidos.id_tipo_responsable IS NULL AND query.id_tipo_responsable IS NOT NULL) OR  (tbn1_indefinidos.id_tipo_responsable IS NOT NULL AND query.id_tipo_responsable IS NULL)
                  OR tbn1_indefinidos.id_modo_ingreso<>query.id_modo_ingreso OR (tbn1_indefinidos.id_modo_ingreso IS NULL AND query.id_modo_ingreso IS NOT NULL) OR  (tbn1_indefinidos.id_modo_ingreso IS NOT NULL AND query.id_modo_ingreso IS NULL)
                  OR tbn1_indefinidos.id_fase_proceso<>query.id_fase_proceso OR (tbn1_indefinidos.id_fase_proceso IS NULL AND query.id_fase_proceso IS NOT NULL) OR  (tbn1_indefinidos.id_fase_proceso IS NOT NULL AND query.id_fase_proceso IS NULL)
                  OR tbn1_indefinidos.id_clave_contable<>query.id_clave_contable OR (tbn1_indefinidos.id_clave_contable IS NULL AND query.id_clave_contable IS NOT NULL) OR  (tbn1_indefinidos.id_clave_contable IS NOT NULL AND query.id_clave_contable IS NULL)
                  OR tbn1_indefinidos.id_grupo_subgrupo_subconcepto<>query.id_grupo_subgrupo_subconcepto OR (tbn1_indefinidos.id_grupo_subgrupo_subconcepto IS NULL AND query.id_grupo_subgrupo_subconcepto IS NOT NULL) OR  (tbn1_indefinidos.id_grupo_subgrupo_subconcepto IS NOT NULL AND query.id_grupo_subgrupo_subconcepto IS NULL)
                  OR tbn1_indefinidos.id_antiguedad<>query.id_antiguedad OR (tbn1_indefinidos.id_antiguedad IS NULL AND query.id_antiguedad IS NOT NULL) OR  (tbn1_indefinidos.id_antiguedad IS NOT NULL AND query.id_antiguedad IS NULL)
                  OR tbn1_indefinidos.id_oficina<>query.id_oficina OR (tbn1_indefinidos.id_oficina IS NULL AND query.id_oficina IS NOT NULL) OR  (tbn1_indefinidos.id_oficina IS NOT NULL AND query.id_oficina IS NULL)
                  OR tbn1_indefinidos.id_estado<>query.id_estado OR (tbn1_indefinidos.id_estado IS NULL AND query.id_estado IS NOT NULL) OR  (tbn1_indefinidos.id_estado IS NOT NULL AND query.id_estado IS NULL)
                  OR tbn1_indefinidos.id_formato_ingreso<>query.id_formato_ingreso OR (tbn1_indefinidos.id_formato_ingreso IS NULL AND query.id_formato_ingreso IS NOT NULL) OR  (tbn1_indefinidos.id_formato_ingreso IS NOT NULL AND query.id_formato_ingreso IS NULL)
                  OR tbn1_indefinidos.id_aplicacion_lote<>query.id_aplicacion_lote OR (tbn1_indefinidos.id_aplicacion_lote IS NULL AND query.id_aplicacion_lote IS NOT NULL) OR  (tbn1_indefinidos.id_aplicacion_lote IS NOT NULL AND query.id_aplicacion_lote IS NULL)
                  OR tbn1_indefinidos.id_seccion<>query.id_seccion OR (tbn1_indefinidos.id_seccion IS NULL AND query.id_seccion IS NOT NULL) OR  (tbn1_indefinidos.id_seccion IS NOT NULL AND query.id_seccion IS NULL)
                  OR tbn1_indefinidos.id_entidad<>query.id_entidad OR (tbn1_indefinidos.id_entidad IS NULL AND query.id_entidad IS NOT NULL) OR  (tbn1_indefinidos.id_entidad IS NOT NULL AND query.id_entidad IS NULL)
                  OR tbn1_indefinidos.id_clave_ingreso<>query.id_clave_ingreso OR (tbn1_indefinidos.id_clave_ingreso IS NULL AND query.id_clave_ingreso IS NOT NULL) OR  (tbn1_indefinidos.id_clave_ingreso IS NOT NULL AND query.id_clave_ingreso IS NULL)
                  OR tbn1_indefinidos.id_origen_liquidacion<>query.id_origen_liquidacion OR (tbn1_indefinidos.id_origen_liquidacion IS NULL AND query.id_origen_liquidacion IS NOT NULL) OR  (tbn1_indefinidos.id_origen_liquidacion IS NOT NULL AND query.id_origen_liquidacion IS NULL)
                  OR tbn1_indefinidos.id_estado_situacion<>query.id_estado_situacion OR (tbn1_indefinidos.id_estado_situacion IS NULL AND query.id_estado_situacion IS NOT NULL) OR  (tbn1_indefinidos.id_estado_situacion IS NOT NULL AND query.id_estado_situacion IS NULL))) THEN
  UPDATE SET
    id_situacion=query.id_situacion,
    id_tipo_ingreso=query.id_tipo_ingreso,
    id_codigo_operacion=query.id_codigo_operacion,
    id_tipo_compensacion=query.id_tipo_compensacion,
    id_tipo_responsable=query.id_tipo_responsable,
    id_modo_ingreso=query.id_modo_ingreso,
    id_fase_proceso=query.id_fase_proceso,
    id_clave_contable=query.id_clave_contable,
    id_grupo_subgrupo_subconcepto=query.id_grupo_subgrupo_subconcepto,
    id_antiguedad=query.id_antiguedad,
    id_oficina=query.id_oficina,
    id_estado=query.id_estado,
    id_formato_ingreso=query.id_formato_ingreso,
    id_aplicacion_lote=query.id_aplicacion_lote,
    id_seccion=query.id_seccion,
    id_entidad=query.id_entidad,
    id_clave_ingreso=query.id_clave_ingreso,
    id_origen_liquidacion=query.id_origen_liquidacion,
    id_estado_situacion=query.id_estado_situacion
WHEN NOT MATCHED THEN
  INSERT (es_indefinido,id_situacion,id_tipo_ingreso,id_codigo_operacion,id_tipo_compensacion,id_tipo_responsable,id_modo_ingreso,id_fase_proceso,id_clave_contable,id_grupo_subgrupo_subconcepto,id_antiguedad,id_oficina,id_estado,id_formato_ingreso,id_aplicacion_lote,id_seccion,id_entidad,id_clave_ingreso,id_origen_liquidacion,id_estado_situacion) VALUES (
    query.es_indefinido,
    query.id_situacion,
    query.id_tipo_ingreso,
    query.id_codigo_operacion,
    query.id_tipo_compensacion,
    query.id_tipo_responsable,
    query.id_modo_ingreso,
    query.id_fase_proceso,
    query.id_clave_contable,
    query.id_grupo_subgrupo_subconcepto,
    query.id_antiguedad,
    query.id_oficina,
    query.id_estado,
    query.id_formato_ingreso,
    query.id_aplicacion_lote,
    query.id_seccion,
    query.id_entidad,
    query.id_clave_ingreso,
    query.id_origen_liquidacion,
    query.id_estado_situacion);
GO

