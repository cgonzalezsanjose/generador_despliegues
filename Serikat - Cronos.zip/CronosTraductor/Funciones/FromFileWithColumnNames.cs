﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CronosTraductor.Funciones
{
	public class FromFileWithColumnNames : FromFile
	{
		protected override bool TieneHeader { get { return true; } }

		internal override bool ContieneFuncion(string linea)
		{
			return linea.Contains(this.InicioFuncion, StringComparison.CurrentCultureIgnoreCase);
		}

		protected override string InicioFuncion
		{
			get
			{
				return "from file with column names";
			}
		}
	}
}
