﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using CronosTraductor.Destinos;

namespace CronosTraductor.Funciones
{
	public abstract class FuncionBase
	{
		internal abstract bool ContieneFuncion(string linea);

		internal abstract int CantidadLineasPrevia { get; }

		internal abstract int CantidadLineasPosterior { get; }

		public abstract Func<BD,string> ObtenerContenidoFuncion { get; }

		public abstract bool EncontradoFinFuncion(string linea);

		protected abstract string[] TraducirSintaxis(int linea, string[] lineasFuncion, string contenidoFuncion);

		internal Traduccion Traducir(int linea, string[] lineasScript, FuncionBase[] funcionesImplementadas, BD destino)
		{
			Traduccion retorno = new Traduccion() { LineasOrigen = lineasScript };
			int incremento = 0;
			int tope = 0;
			if(this.CantidadLineasPosterior > 0)
			{
				incremento = 1;
				tope = this.CantidadLineasPosterior;
			}
			else
			{
				incremento = -1;
				tope = this.CantidadLineasPrevia;
			}
			int posActual = linea + incremento;
			bool encontrado = false;
			List<string> buffer = new List<string>();
			int posFin = 0;
			while(!encontrado && posActual >= 0 && posActual < lineasScript.Length)
			{
				buffer.Add(lineasScript[posActual]);
				encontrado = EncontradoFinFuncion(lineasScript[posActual]);
				if(encontrado) posFin = posActual;
				posActual += incremento;
			}
			if(encontrado)
			{
				if(incremento == -1)
				{
					buffer.Reverse();
					buffer.Add(lineasScript[linea]);
				}
				else
				{
					buffer.Insert(0, lineasScript[linea]);
				}
				linea = linea - posFin;
				retorno.LineasTraducidas = TraducirSintaxis(linea, buffer.ToArray(), this.ObtenerContenidoFuncion(destino));
				if(retorno.LineasTraducidas.Length != 0)
				{
					int cantidadLineasTraducidas = retorno.LineasTraducidas.Length;
					List<string> nuevasLineas = new List<string>(lineasScript);
					int posEliminacion = (linea + posFin) < posFin ? (linea + posFin) : posFin;
					nuevasLineas.RemoveRange(posEliminacion, buffer.Count);
					nuevasLineas.InsertRange(posEliminacion, retorno.LineasTraducidas);
					retorno.LineasTraducidas = nuevasLineas.ToArray();
					retorno.LineaInicioTraduccion = posEliminacion;
					retorno.LineaFinTraduccion = posEliminacion + cantidadLineasTraducidas - 1;
				}
				
			}

			return retorno;
		}
	}
}
