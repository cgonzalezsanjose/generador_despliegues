﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Data.OleDb;
using System.Text.RegularExpressions;
using System.IO;
using System.Data;
using System.Collections.Specialized;
using CronosTraductor.Destinos;
using Microsoft.VisualBasic.FileIO;

namespace CronosTraductor.Funciones
{
	public class FromFile : FuncionBase
	{
		protected virtual bool TieneHeader { get { return false; } }
		protected string DelimitadorColumnas { get { return "Format=Delimited(;)"; } }
		protected virtual string InicioFuncion { get { return "from file"; } }


		private void ObtenerColumnNames()
		{
			
		}

		internal override bool ContieneFuncion(string linea)
		{
			return linea.Contains(this.InicioFuncion, StringComparison.CurrentCultureIgnoreCase) && !linea.Contains("from file with column names", StringComparison.CurrentCultureIgnoreCase);
		}

		internal override int CantidadLineasPrevia
		{
			get { return 30; }
		}

		internal override int CantidadLineasPosterior
		{
			get { return 0; }
		}

		public override Func<Destinos.BD, string> ObtenerContenidoFuncion
		{
			get { return p=> p.FromFileWithColumnNames; }
		}

		public override bool EncontradoFinFuncion(string linea)
		{
			return linea.Contains("select");
		}
	
		protected void GenerarExcepcionFormato()
		{
			throw new FormatException("Formato de '" + this.InicioFuncion + "': " + this.InicioFuncion + " 'fichero_csv.csv' alias");
		}

		private DataTable parsearFichero(string fileName, char delimitador = ';')
		{
			string[] contenidoFichero = File.ReadAllLines(fileName, Encoding.Default);
			List<string> lineasValidas = new List<string>();
			foreach(string lineaFichero in contenidoFichero)
			{
				if (!string.IsNullOrWhiteSpace(lineaFichero))
				{
					lineasValidas.Add(lineaFichero);
				}
				if(lineaFichero.Trim().StartsWith("--") && !lineaFichero.Contains(';')) lineasValidas.Clear();
			}
			DataTable retorno = new DataTable();
			for(int i = 0; i<lineasValidas.Count; i++)
			{
				string[] partesLinea = lineasValidas[i].Split(new char[] { delimitador });
				if(i == 0)
				{
					for (int j = 0; j < partesLinea.Length; j++)
					{
						retorno.Columns.Add(this.TieneHeader ? partesLinea[j] : string.Format("col{0}", j), typeof(string));
					}
					if (!this.TieneHeader)
					{
						retorno.Rows.Add(partesLinea);
					}	
				}
				else
				{
					if (partesLinea != null && partesLinea.Length != 0)
					{
						retorno.Rows.Add(partesLinea);
					}
				}
			}
			return retorno;
		}

		protected override string[]  TraducirSintaxis(int linea, string[] lineasFuncion, string contenidoFuncion)
		{
			string header = this.TieneHeader ? "HDR=Yes" : "HDR=No";
			Regex regexSentencia = new Regex(@"[\s\t]*" + InicioFuncion + @"[\s\t]+'([^']+)'(?:[\s\t]+([^\s\t]+))?", RegexOptions.IgnoreCase | RegexOptions.Singleline);
			Match coincidenciaSentencia = regexSentencia.Match(lineasFuncion[linea]);
			StringBuilder retorno = new StringBuilder();
			bool ok = false;
			if(coincidenciaSentencia.Success)
			{
				string fileName = coincidenciaSentencia.Groups[1].Value;
				if(fileName.Contains('/') || fileName.Contains('\\'))
				{
					fileName = fileName.Replace('/', Path.DirectorySeparatorChar).Replace('\\', Path.DirectorySeparatorChar);
				}
				string aliasTabla = coincidenciaSentencia.Groups[2].Value;				
				FileInfo info = new FileInfo(fileName);
				if(info.Exists)
				{
					NameValueCollection campos = new NameValueCollection();
					for(int i = 1; i < linea; i++)
					{
						Regex regexCampo = new Regex(@"([^\n]+)[\s\t]+#?([^\s\t,]+),?[\s\t]*$", RegexOptions.Singleline);
						if(!lineasFuncion[i].Trim().StartsWith("--"))
						{
							Match coincidenciaCampo = regexCampo.Match(lineasFuncion[i]);
							if (coincidenciaCampo.Success)
							{
								string colAlias = coincidenciaCampo.Groups[2].Value;
								string colOrigen = coincidenciaCampo.Groups[1].Value.Trim();
								campos.Add(colAlias, colOrigen);
							}
						}
					}
					string carpeta = info.DirectoryName;
					DataTable dtFichero = parsearFichero(info.FullName);
					retorno.AppendLine("(" + lineasFuncion[0].Replace("#", ""));
					for(int i = 0; i < campos.Keys.Count; i++)
					{
						retorno.AppendFormat("\t{0} {1}", campos[i], campos.Keys[i]);
						retorno.AppendLine((i < campos.Keys.Count - 1)? "," : "");
					}
					retorno.AppendLine(@"FROM
(");
					for(int i=0; i< dtFichero.Rows.Count; i++)
					{
						ok = true;
						for(int j = 0; j < dtFichero.Columns.Count; j++)
						{
							if( j == 0)
							{
								
								retorno.Append(i == 0?"\tSELECT " : "\tUNION ALL SELECT ");
							}
							retorno.Append("'" + dtFichero.Rows[i][j].ToString().Replace("'", "''") + "'");
							if( i == 0) retorno.Append(" AS " + dtFichero.Columns[j].ColumnName);
							if(j < dtFichero.Columns.Count - 1) retorno.Append(", ");
							else retorno.AppendLine("");
						}
					}
					retorno.AppendFormat(") {0})", aliasTabla);
				}
				else
				{
					throw new FileNotFoundException(string.Format("El fichero '{0}' no existe", fileName));
				}
			}
			else
			{
				GenerarExcepcionFormato();
			}
			if(ok)
			{
				return retorno.ToString().Split('\n');
			}
			else
			{
				return new string[]{};
			}
			
		}
}
}
