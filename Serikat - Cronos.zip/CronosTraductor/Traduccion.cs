﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CronosTraductor
{
	internal class Traduccion
	{
		internal string[] LineasOrigen { get; set; }
		internal int LineaInicioTraduccion { get; set; }
		internal int LineaFinTraduccion { get; set; }
		internal string[] LineasTraducidas { get; set; }
	}
}
