﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace CronosTraductor
{
	internal static class Extensiones
	{
		public static bool Contains(this string source, string toCheck, StringComparison comp)
		{
			return source.IndexOf(toCheck, comp) >= 0;
		}

		public static string ReplaceIgnoreCase(this string source, string toCheck, string toReplace)
		{
			return Regex.Replace(source, toCheck, toReplace, RegexOptions.IgnoreCase);
		}
	}
}
