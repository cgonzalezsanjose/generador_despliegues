﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CronosTraductor.Destinos
{
	public class SQLServer2008 : SQLServer2005
	{
		public override string Merge
		{
			get
			{
				return null;
			}
		}
	}
}
