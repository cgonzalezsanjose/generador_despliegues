﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CronosTraductor.Destinos
{
	public class BD
	{
		public virtual string FromFileWithColumnNames { get { return null; } }
		public virtual string Merge { get { return null; } }
		public virtual string IntegersBetween { get { return null; } }
		public virtual string If { get { return null; } }
		public virtual string ZeroIfNull { get { return null; } }
		public virtual string NullIfZero { get { return null; } }
		public virtual string Update { get { return null; } }
		public virtual string Insert { get { return null; } }
		public virtual string Top1OverPartition { get { return null; } }
		public virtual string Materialize { get { return null; } }
		public virtual string Combine { get { return null; } }
		public virtual string FilterEnColumna { get { return null; } }
		public virtual string FilterEnJoin { get { return null; } }
		public virtual string Compare { get { return null; } }
		public virtual string Using { get { return null; } }
		public virtual string LoadWithSCD1 { get { return null; } }
		public virtual string LoadWithSCD2 { get { return null; } }
		public virtual string LoadWithSnapshot { get { return null; } }
		public virtual string CombineWithUnionAll { get { return null; } }
		public virtual string CombineWithLeftJoin { get { return null; } }
		public virtual string CreateOrAlterTable { get { return null; } }
		public virtual string References { get { return null; } }
		public virtual string Default { get { return null; } }
		public virtual string CreateOrReplaceProcedure { get { return null; } }
		public virtual string DropTableIfExists { get { return null; } }
		public virtual string DropProcedureIfExists { get { return null; } }
		public virtual string CreateIndexIfNotExists { get { return null; } }
		public virtual string DropConstraintIfExists { get { return null; } }
		public virtual string DropColumnIfExists { get { return null; } }
		public virtual string StartsWith { get { return null; } }
		public virtual string CaseValueWhen { get { return null; } }
		public virtual string FilterColumnaFromSchema { get { return null; } }
	}
}
