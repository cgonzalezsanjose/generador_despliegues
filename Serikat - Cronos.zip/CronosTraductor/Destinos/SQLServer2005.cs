﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CronosTraductor.Destinos
{
	public class SQLServer2005 : BD
	{
		
	}
}
