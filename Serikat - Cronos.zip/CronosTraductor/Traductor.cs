﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using CronosTraductor.Funciones;
using CronosTraductor.Destinos;

namespace CronosTraductor
{
	public class Traductor
	{
		FuncionBase[] funcionesImplementadas = new FuncionBase[] 
		{
			new FromFile(), new FromFileWithColumnNames()
		};

		public string[] Traducir(string[] lineasScript, BD destino)
		{
			bool teniaFunciones = true;
			Traduccion traducido = null;
			while (teniaFunciones)
			{
				teniaFunciones = false;
				for (int posLinea = 0; posLinea < lineasScript.Length; posLinea++)
				{
					if(!lineasScript[posLinea].Trim().StartsWith("--"))
					{
						foreach (FuncionBase funcion in this.funcionesImplementadas)
						{
							//TODO Meter codigo para detectar funciones anidadas, por ejemplo References y Default en CreateOrAlterTable
							// Para ello implementar las funciones de una linea antes que las multilinea
							if (funcion.ContieneFuncion(lineasScript[posLinea]))
							{
								traducido = funcion.Traducir(posLinea, lineasScript, this.funcionesImplementadas, destino);
								lineasScript = traducido.LineasTraducidas;
								teniaFunciones = true;
								break;
							}
						}
						if (teniaFunciones) break;
					}
				}
			}
			return traducido.LineasTraducidas;
		}
	}
}
