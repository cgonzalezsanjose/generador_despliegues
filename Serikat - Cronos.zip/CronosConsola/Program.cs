﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.IO;
using System.Configuration;
using System.Text.RegularExpressions;

namespace CronosConsola
{
	class Program
	{
		static void Main(string[] args)
		{
			if(args == null || args.Length != 1)
			{
				ConsoleColor colorPrevio = Console.ForegroundColor;
				Console.ForegroundColor = ConsoleColor.Red;
				Console.Write("Ayuda:");
				Console.ForegroundColor = colorPrevio;
				Console.WriteLine("Llame a este ejecutable pasando únicamente como parametro el fichero a traducir");
				return;
			}
			CronosTraductor.Destinos.BD destino = null;
			string strDestino = ConfigurationManager.AppSettings["Destino"].ToLower();
			switch(strDestino)
			{
				case "sqlserver2008":
					destino = new CronosTraductor.Destinos.SQLServer2008();
					break;
				default:
					throw new ArgumentException("Tipo de base de datos no soportado aun :-(");
			}
			if (!File.Exists(args[0]))
			{
				throw new FileNotFoundException("No se encuentra el archivo que se desea convertir");
			}
			FileInfo infoOrigen = new FileInfo(args[0]);
			string nombreDestino = infoOrigen.Name.Replace(infoOrigen.Extension, "");
			nombreDestino = infoOrigen.DirectoryName + Path.DirectorySeparatorChar + string.Format(ConfigurationManager.AppSettings["formatoDestino"], nombreDestino);
			bool sobreescribir = false;
			if(File.Exists(nombreDestino))
			{
				ConsoleColor colorPrevio = Console.ForegroundColor;
				Console.ForegroundColor = ConsoleColor.Red;
				Console.Write("AVISO:");
				Console.ForegroundColor = colorPrevio;
				Console.Write(" El fichero que se va a generar ya existe, ¿desea sobrrescribirlo? (S/N): ");
				string respuesta = Console.ReadLine();
				if(!respuesta.Equals("S", StringComparison.CurrentCultureIgnoreCase))
				{
					return;
				}
				sobreescribir = true;
			}
			string[] contenidoScript = File.ReadAllLines(args[0], Encoding.UTF8);
			// Reemplazos de variables
			string filenameVariables = ConfigurationManager.AppSettings["CSV variables"];
			if (File.Exists(filenameVariables))
			{
				string[] lineasVariables = File.ReadAllLines(filenameVariables, Encoding.UTF8);
				foreach(string lineaVariable in lineasVariables)
				{
					string nombreVar = lineaVariable.Substring(0, lineaVariable.IndexOf(';'));
					string valorVar = lineaVariable.Substring(lineaVariable.IndexOf(';')+1);
					for(int i=0; i< contenidoScript.Length; i++)
					{
						if(contenidoScript[i].IndexOf(nombreVar, StringComparison.CurrentCultureIgnoreCase)!= -1)
						{
							contenidoScript[i] = Regex.Replace(contenidoScript[i], nombreVar, valorVar, RegexOptions.IgnoreCase);
						}
					}
				}
			}
			CronosTraductor.Traductor traductor = new CronosTraductor.Traductor();
			string[] contenidoTraducido = traductor.Traducir(contenidoScript, destino);
			if(sobreescribir) File.Delete(nombreDestino);
			File.WriteAllLines(nombreDestino, contenidoTraducido, Encoding.UTF8);
			Console.WriteLine(string.Format("Fichero generado en: {0}", nombreDestino));
		}
	}
}
