﻿morralla
select
     familia.cod_familia     #cod_familia,
	familia.desc_familia	desc_familia,
	familia.edad + familia.edad2	edades_familia
from file with column names '@@root\FromFileWithColumnNames\ejemploManual.csv' familia
mas morralla
linea
otra linea
otra mas
select
     cod_familia     #codigo,
	desc_familia	descripcion
from file with column names '@@root\FromFileWithColumnNames\ejemploManual.csv' familia
