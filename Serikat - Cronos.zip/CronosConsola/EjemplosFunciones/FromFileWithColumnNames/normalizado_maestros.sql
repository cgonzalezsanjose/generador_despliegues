﻿
CREATE OR ALTER TABLE @@norm.ot_tipos_ingreso(
	#id_tipo_ingreso 	int identity(1,1),
	tipo_ingreso 		varchar(1) NOT NULL,
	des_tipo_ingreso	varchar(50) NOT NULL,
	es_indefinido		bit DEFAULT 0,			
	fec_alta				datetime,
	fec_modificacion		datetime,
	fec_baja				datetime,
	CONSTRAINT uk_ot_tipos_ingreso UNIQUE (tipo_ingreso)
)
 
MERGE @@norm.ot_tipos_ingreso
SELECT 1 #es_indefinido, '9' tipo_ingreso, 'Otro' des_tipo_ingreso;

CREATE OR REPLACE PROCEDURE @@proc.cargar_normalizado_ot_tipos_ingreso(@logpadre int)
LOAD @@norm.ot_tipos_ingreso partition ( tbn1_ot_tipos_ingreso.es_indefinido=0 ) WITH SCD1 
select
  ting.tinting															#tipo_ingreso,
--  left(coalesce(ting.tinting + ' - ' + ting.tindesc, ting.tinting),50)  des_tipo_ingreso
   ting.tindesc															des_tipo_ingreso
from @@stg.ting_ti  ting
where ting.tinenti = 'DF' -- Solo aplican los Tipos de Ingreso de la Diputación Foral de Bizkaia, se excluyen las de otros organismos públicos presentes en esta tabla
and ting.tinejer = (select max(tinejer) from @@stg.ting_ti) -- Solo aplica el año actual, tomo el máximo existente en la tabla dado que tomar año actual de getdate() podría hacer que las primeras cargas de esta tabla al inicio de un año natural dieran de baja los registros en NORM si aun no han cargado ese ejercicio en el STG
group by all




CREATE OR ALTER TABLE @@norm.ot_claves_ingreso( --También llamado sub conceptos
	#id_clave_ingreso 		int identity(1,1),
	cod_clave_ingreso 		varchar(7) NOT NULL,
	clave_ingreso 			varchar(50) NOT NULL,
	ejercicio_descripcion 	smallint,  --Es el último año disponible y que detemrina el nombre.
	es_ingreso_del_presupuesto	bit default 0 NOT NULL,	
	es_indefinido			bit DEFAULT 0,			
	fec_alta				datetime,
	fec_modificacion		datetime,
	fec_baja				datetime,
	CONSTRAINT uk_ot_claves_ingreso UNIQUE (cod_clave_ingreso)
)

MERGE @@norm.ot_claves_ingreso
SELECT 1 #es_indefinido,'' cod_clave_ingreso, 'Indefinido' clave_ingreso;


CREATE OR REPLACE PROCEDURE @@proc.cargar_normalizado_ot_claves_ingreso(@logpadre int)
LOAD @@norm.ot_claves_ingreso partition ( tbn1_ot_claves_ingreso.es_indefinido=0 ) WITH SCD1
select top 1 over (partition by cod_clave_ingreso order by es_ingreso_del_presupuesto desc, ejercicio_descripcion  desc)
  ccoccon 				#cod_clave_ingreso,
  ccodesc 				clave_ingreso,
  ccoejer 				ejercicio_descripcion,
  IF(ccoting='I',1,0) 	es_ingreso_del_presupuesto -- Si una clave de ingreso existe para tipo de ingreso I - Ingresos del Presupuesto tomamos esa para el último año disponible, sino la del último año disponible para cualquiera del resto de tipos de ingreso
from @@stg.ccon_ti
where  ccoenti = 'DF'



CREATE OR ALTER TABLE @@norm.ot_claves_contables(
	#id_clave_contable int identity(1,1),
	anyo_contraido 		varchar(2) NOT NULL,
    id_tipo_ingreso		int NOT NULL REFERENCES @@norm.ot_tipos_ingreso,
	id_clave_ingreso	int NOT NULL DEFAULT 1 REFERENCES @@norm.ot_claves_ingreso,	
	tipo_ingreso		varchar(1) NOT NULL default '',
	clave_ingreso 		varchar(7) NOT NULL, --	REFERENCES  @@norm.ot_grupos_subgrupos_subconceptos(cod_subconcepto),
	descripcion 		varchar(50)	NOT NULL default '',
	concepto			varchar(20)		NOT NULL default '',
	es_indefinido		bit DEFAULT 0,	
	origen				varchar(10) not null default '',	
	fec_alta				datetime,
	fec_modificacion		datetime,
	fec_baja				datetime,
	CONSTRAINT uk_ot_claves_contables UNIQUE (anyo_contraido,tipo_ingreso,clave_ingreso)
) 

MERGE @@norm.ot_claves_contables
SELECT 1 #es_indefinido, '' anyo_contraido, 1 id_tipo_ingreso, '' clave_ingreso, 'Indefinido' descripcion;

--MAESTRO DE CLAVES CONTABLE
CREATE OR REPLACE PROCEDURE @@proc.cargar_normalizado_ot_claves_contables(@logpadre int)
LOAD @@norm.ot_claves_contables WITH SCD1 
select
  #anyo_contraido,
  #tipo_ingreso,
  #clave_ingreso,
  id_tipo_ingreso,
  id_clave_ingreso,
  descripcion,
  concepto,
  origen
from 
(  
COMBINE
maestro (
select 
  right(clco.ccoejer,2)													#anyo_contraido, 
  clco.ccoting															#tipo_ingreso,
  clco.ccoccon															#clave_ingreso, 
  coalesce(tipo_ingreso.id_tipo_ingreso,indefinidos.id_tipo_ingreso)   	id_tipo_ingreso,	  
  coalesce(clave_ingreso.id_clave_ingreso,1)							id_clave_ingreso,
  clco.ccodesc 															descripcion,
  case 
    VALUE 'RECARGO ' WHEN  clco.ccoccon='3920101' 
	VALUE 'INTERESES' WHEN left(clco.ccoccon,5)='39202' 
	ELSE 'CUOTA'
  END					concepto,
  'MAESTRO'				origen
from @@stg.ccon_ti clco 
left join @@norm.ot_tipos_ingreso tipo_ingreso on tipo_ingreso.tipo_ingreso = clco.ccoting
left join @@norm.ot_claves_ingreso clave_ingreso on clave_ingreso.cod_clave_ingreso=clco.ccoccon
cross join @@norm.indefinidos indefinidos
where 
  clco.ccoenti = 'DF' -- Solo aplican las claves contables de la Diputación Foral de Bizkaia, se excluyen las de otros organismos públicos presentes en en CCON_TI
  and clco.ccoejer<>'0000' --En producción existe un registro con este código que viola la UC.
group by all
)
movimientos(
select 	
  mov.conacont														#anyo_contraido,
  mov.contingr														#tipo_ingreso,
  mov.concingr														#clave_ingreso,	
  coalesce(tipo_ingreso.id_tipo_ingreso,indefinidos.id_tipo_ingreso)  id_tipo_ingreso,	  
  coalesce(clave_ingreso.id_clave_ingreso,1)							id_clave_ingreso,	
  'Clave contable faltante en Maestro'								descripcion,
  case 
    VALUE 'RECARGO ' WHEN  mov.concingr='3920101' 
	VALUE 'INTERESES' WHEN left(mov.concingr,5)='39202' 
	ELSE 'CUOTA'
  END					concepto,
  'S1CONT' origen
from @@stg.cont_s1 mov
left join @@norm.ot_tipos_ingreso tipo_ingreso on tipo_ingreso.tipo_ingreso = mov.contingr
left join @@norm.ot_claves_ingreso clave_ingreso on clave_ingreso.cod_clave_ingreso= mov.concingr	
cross join @@norm.indefinidos indefinidos
group by all
))




CREATE OR ALTER TABLE @@norm.ot_grupos_subgrupos_subconceptos(
	#id_grupo_subgrupo_subconcepto 	int identity(1,1),
	cod_grupo 						nvarchar(2) NOT NULL,
    cod_subgrupo					nvarchar(5) NOT NULL,	
	cod_subconcepto 				varchar(7) NOT NULL,
	des_grupo						varchar(40)	NOT NULL,
	des_subgrupo					varchar(40) NOT NULL,	
	des_subconcepto					varchar(40) NOT NULL,
	peso							decimal(5,4)	NOT NULL,
	es_listado						bit	default 0 NOT NULL,
	es_ingreso_del_presupuesto		bit default 0 NOT NULL,		
	id_clave_ingreso				int	NULL REFERENCES @@norm.ot_claves_ingreso,
	es_sancion						bit	default 0 NOT NULL,	
	es_recargo						bit	default 0 NOT NULL,	
	es_interes_demora				bit	default 0 NOT NULL,			
	es_indefinido					bit DEFAULT 0,		
	fec_alta						datetime,
	fec_modificacion				datetime,
	fec_baja						datetime,
	CONSTRAINT uk_grupo_subgrupo_subconcepto UNIQUE (cod_grupo,cod_subgrupo,cod_subconcepto)
)

MERGE @@norm.ot_grupos_subgrupos_subconceptos
SELECT 1 #es_indefinido, '' cod_grupo, '' cod_subgrupo, '' cod_subconcepto, 'Indefinido' des_grupo, 'Indefinido' des_subgrupo, 'Indefinido' des_subconcepto, 1 peso;

CREATE OR REPLACE PROCEDURE @@proc.cargar_normalizado_ot_grupos_subgrupos_subconceptos_lista(@logpadre int)
LOAD @@norm.ot_grupos_subgrupos_subconceptos partition ( tbn1_ot_grupos_subgrupos_subconceptos.es_listado=1 and tbn1_ot_grupos_subgrupos_subconceptos.es_indefinido=0 ) with SCD1
--select 
--	cast(cod_grupo as varchar)					#cod_grupo,
--	cast(cod_subgrupo as varchar) 				#cod_subgrupo,
--	cast(subconcepto as varchar)				#cod_subconcepto,
--	des_grupo									des_grupo,
--	des_subgrupo								des_subgrupo,
--	des_subconcepto								des_subconcepto,
--	if(peso<>'',cast(peso as decimal)/100,1) 	peso,
--	1 											es_listado
--from file with column names '@@root/data/OT_grupo_subgrupo.csv' grsu
select  substring(clave.auxi_re13_clave,14,2) 							#cod_grupo, 
        substring(clave.auxi_re13_clave,14,2) + substring(clave.auxi_re13_clave,16,3) 	#cod_subgrupo, 
		substring(clave.auxi_re13_clave,19,7) 							#cod_subconcepto, --También llamado "Clave de ingreso"
		clave_ingreso.id_clave_ingreso,		
		grupo.auxi_re11_descrg 											des_grupo,
		subgrupo.auxi_re12_descrg 										des_subgrupo,
		coalesce(clave_ingreso.clave_ingreso,'') 						des_subconcepto,
		clave.auxi_re13_porc/100										peso,
		1 																es_listado,
		coalesce(clave_ingreso.es_ingreso_del_presupuesto,0) 			es_ingreso_del_presupuesto,
		IF(upper(des_subgrupo) like '%SANCIONES%' 			,1,0)		es_sancion,
		IF(upper(des_subgrupo) like '%RECARGOS%' 			,1,0)		es_recargo,		
		IF(upper(des_subgrupo) like '%INTERESES DE DEMORA%'	,1,0)		es_interes_demora			
from @@stg.auxi_s7_r13 clave
left join @@norm.ot_claves_ingreso clave_ingreso on  clave_ingreso.cod_clave_ingreso = substring(clave.auxi_re13_clave,19,7)
inner join @@stg.auxi_s7_r12 subgrupo on right(subgrupo.auxi_re12_clave,5)= substring(clave.auxi_re13_clave,14,5)
inner join @@stg.auxi_s7_r11 grupo on right(grupo.auxi_re11_clave,2) = substring(clave.auxi_re13_clave,14,2)

CREATE OR REPLACE PROCEDURE @@proc.cargar_normalizado_ot_grupos_subgrupos_subconceptos_no_lista(@logpadre int)
LOAD @@norm.ot_grupos_subgrupos_subconceptos partition ( tbn1_ot_grupos_subgrupos_subconceptos.es_listado=0 and tbn1_ot_grupos_subgrupos_subconceptos.es_indefinido=0 ) with SCD1
select 
	''										#cod_grupo,
	''			 							#cod_subgrupo,
	clave_ingreso.cod_clave_ingreso			#cod_subconcepto,
	clave_ingreso.id_clave_ingreso,	
	'Indefinido'							des_grupo,
	'Indefinido'							des_subgrupo,
	clave_ingreso.clave_ingreso				des_subconcepto,
	1										peso,
	0 										es_listado,
	clave_ingreso.es_ingreso_del_presupuesto 	
--from @@stg.ccon_ti clco
--left join file with column names '@@root/data/OT_grupo_subgrupo.csv' grsu on cast(grsu.subconcepto as varchar) = clco.ccoccon
--where grsu.subconcepto is null
--group by all  
from @@norm.ot_claves_ingreso clave_ingreso
left join @@stg.auxi_s7_r13 clave on  substring(clave.auxi_re13_clave,19,7) = clave_ingreso.cod_clave_ingreso
where clave.auxi_re13_clave is null
group by all




CREATE OR ALTER TABLE @@norm.ot_modos_ingreso(
	#id_modo_ingreso		int identity(1,1),
	modo_ingreso 			varchar(2) NOT NULL,
	des_modo_ingreso		varchar(50) NOT NULL,
	es_indefinido			bit DEFAULT 0,			
	fec_alta				datetime,
	fec_modificacion		datetime,
	fec_baja				datetime,
	CONSTRAINT uk_ot_modos_ingreso UNIQUE (modo_ingreso)
)

MERGE @@norm.ot_modos_ingreso
SELECT 1 #es_indefinido, 'ZZ' modo_ingreso, 'Indefinido' des_modo_ingreso;


CREATE OR REPLACE PROCEDURE @@proc.cargar_normalizado_ot_modos_ingreso(@logpadre int)
LOAD @@norm.ot_modos_ingreso partition ( tbn1_ot_modos_ingreso.es_indefinido=0 ) with SCD1 
select 
	right('0'+cast(ming.modo_ingreso as varchar),2)	#modo_ingreso,
--    left(coalesce(modo_ingreso + ' - ' + ming.des_modo_ingreso, modo_ingreso),50) des_modo_ingreso
    ming.des_modo_ingreso							des_modo_ingreso
from file with column names '@@root/data/OT_modo_ingreso.csv' ming



  
CREATE OR alter TABLE @@norm.ot_situaciones(
		#id_situacion		int IDENTITY(1,1),
		cod_situacion		varchar(2),
		situacion	        varchar(50),
		cod_tipo_situacion	int not null default 0,		
		tipo_situacion		varchar(50),
		es_indefinido		bit DEFAULT 0,		
		fec_alta			datetime,
		fec_modificacion	datetime,
		fec_baja			datetime,
		CONSTRAINT uk_ot_situaciones UNIQUE (cod_situacion)
)     

MERGE @@norm.ot_situaciones
SELECT 1 #es_indefinido,'ZZ' cod_situacion,'Otras' situacion, 4 cod_tipo_situacion ,'OTRAS SITUACIONES' tipo_situacion;


CREATE OR ALTER TABLE @@norm.ot_codigos_operacion(
	#id_codigo_operacion 	int identity(1,1),
	codigo_operacion		varchar(4) NOT NULL,
	descripcion				varchar(50) NOT NULL,
	signo					int 	NULL,
	cod_signo				varchar(1) NOT NULL DEFAULT '',
	cuenta_para_pendiente	bit NOT NULL DEFAULT 0,
	cod_tipo_movimiento		int NOT NULL DEFAULT 0,	
	tipo_movimiento			varchar(20) NOT NULL DEFAULT '',
	es_indefinido			bit DEFAULT 0,		
	clasificacion			varchar(40) NOT NULL default '',
	cod_subclasificacion	int not null default 0,
	subclasificacion		varchar(40) NOT NULL default '',
	estado					varchar(2) NOT NULL default '',
	origen					varchar(10) not null default '',					
	fec_alta				datetime,
	fec_modificacion		datetime,
	fec_baja				datetime,
	CONSTRAINT uk_ot_codigos_operación UNIQUE (codigo_operacion)
)

MERGE @@norm.ot_codigos_operacion
SELECT 1 #es_indefinido, 'ZZZZ' codigo_operacion, 'Indefinido' descripcion,1 signo,'' cod_signo, 0 cuenta_para_pendiente, 4 cod_tipo_movimiento ,'RESTO' tipo_movimiento, 'Indefinido' clasificacion, 0 cod_subclasificacion, 'Indefinido' subclasificacion, '' estado;

CREATE OR REPLACE PROCEDURE @@proc.cargar_normalizado_ot_codigos_operacion(@logpadre int)
LOAD @@norm.ot_codigos_operacion partition ( tbn1_ot_codigos_operacion.es_indefinido=0 ) WITH SCD1 
select #codigo_operacion,
	   descripcion,
	   coalesce(signo,'') signo,
	   coalesce(cod_signo,'') cod_signo,
	   coalesce(cuenta_para_pendiente,1) cuenta_para_pendiente,
	   coalesce(tipo_movimiento,'') tipo_movimiento,
	   coalesce(cod_tipo_movimiento,'') cod_tipo_movimiento,
  	   coalesce(clasificacion,'') clasificacion,
  	   coalesce(cod_subclasificacion,0) cod_subclasificacion,  
  	   coalesce(subclasificacion,'') subclasificacion,
  	   coalesce(estado,'') estado,
  	   origen	   
from
(
combine 
maestro(
select 
  #oper.opeoper									codigo_operacion,
  oper.opedesc 									descripcion,
  if(oper.opesign='R',-1,1) 					signo,
  oper.opesign									cod_signo,
  if(oper.opesign IN ('R','S') OR opeoper='2005',1,0) cuenta_para_pendiente, --Indentifica los movimientos *solo* contables... pero que no afectan a la deuda pendiente.
  CASE 
    VALUE 'Ingresado' WHEN left(oper.opeoper,1)='1'
	VALUE 'Contraído' WHEN (left(oper.opeoper,1)='2' and cuenta_para_pendiente=1) or (left(oper.opeoper,2)='40') -- A petición de Pilar Merino (19/02 07:19) los 40 son Contraído, no Resto	
	VALUE 'Anulado'   WHEN (left(oper.opeoper,1)='3' and left(oper.opeoper,2)<>'39') or (left(oper.opeoper,2)='41') -- A petición de Pilar Merino (19/02 07:19) los 41 son Anulado, no Resto
	ELSE 'Resto' 
  END 											tipo_movimiento,
  CASE 
     VALUE 1 WHEN tipo_movimiento = 'Ingresado'
	 VALUE 2 WHEN tipo_movimiento = 'Contraído'
	 VALUE 3 WHEN tipo_movimiento = 'Anulado'
	 ELSE 4
  END 											cod_tipo_movimiento,
  coalesce(timo.clasificacion, 'Indefinido')	clasificacion,
  coalesce(timo.cod_subclasificacion, 0)		cod_subclasificacion,  
  coalesce(timo.subclasificacion, 'Indefinido')	subclasificacion,
  coalesce(timo.estado, '')						estado,
  'MAESTRO'										origen
from @@stg.oper_ti /*filter (opeoper <> '110I')*/    oper
left join file with column names '@@root/data/OT_motivos_baja.csv' timo on cast(timo.cod_operacion as varchar) = oper.opeoper
where oper.opeenti = 'DF' -- Solo aplican los Tipos de Ingreso de la Diputación Foral de Bizkaia, se excluyen las de otros organismos públicos presentes en esta tabla
and oper.opeejer = (select max(opeejer) from @@stg.oper_ti) 
group by all
)
movimientos(
 select #mov.concoper						codigo_operacion,
  'Código de operación faltante en Maestro' descripcion,
  1 										cuenta_para_pendiente,
  CASE 
    VALUE 'Ingresado' WHEN left(mov.concoper,1)='1'
	VALUE 'Contraído' WHEN (left(mov.concoper,1)='2' and cuenta_para_pendiente=1) or (left(mov.concoper,2)='40') -- A petición de Pilar Merino (19/02 07:19) los 40 son Contraído, no Resto	
	VALUE 'Anulado'   WHEN (left(mov.concoper,1)='3' and left(mov.concoper,2)<>'39') or (left(mov.concoper,2)='41') -- A petición de Pilar Merino (19/02 07:19) los 41 son Anulado, no Resto
	ELSE 'Resto' 
  END 											tipo_movimiento,
  CASE 
     VALUE 1 WHEN tipo_movimiento = 'Ingresado'
	 VALUE 2 WHEN tipo_movimiento = 'Contraído'
	 VALUE 3 WHEN tipo_movimiento = 'Anulado'
	 ELSE 4
  END 											cod_tipo_movimiento,  
  'S1CONT' origen  
from @@stg.cont_s1 mov
left join @@stg.oper_ti /*filter (opeoper <> '110I')*/ oper on oper.opeoper = mov.concoper and opeenti = 'DF' and opeejer = (select max(opeejer) from @@stg.oper_ti)
where oper.opeoper is null
group by all
)
)




CREATE OR ALTER TABLE @@norm.ot_tipos_compensacion(
	#id_tipo_compensacion	int identity(1,1),
	tipo_compensacion 		varchar(2) NOT NULL,
	des_tipo_compensacion	varchar(50) NOT NULL,
	es_indefinido			bit DEFAULT 0,			
	fec_alta				datetime,
	fec_modificacion		datetime,
	fec_baja				datetime,
	CONSTRAINT uk_ot_tipos_compensacion UNIQUE (tipo_compensacion)
)

MERGE @@norm.ot_tipos_compensacion
SELECT 1 #es_indefinido, 'ZZ' tipo_compensacion, 'Indefinido' des_tipo_compensacion;


CREATE OR ALTER TABLE @@norm.ot_tipos_responsable(
	#id_tipo_responsable	int identity(1,1),
	tipo_responsable 		varchar(2) NOT NULL,
	des_tipo_responsable	varchar(50) NOT NULL,
	es_indefinido			bit DEFAULT 0,			
	fec_alta				datetime,
	fec_modificacion		datetime,
	fec_baja				datetime,
	CONSTRAINT uk_ot_tipos_responsable UNIQUE (tipo_responsable)
)

MERGE @@norm.ot_tipos_responsable
SELECT 1 #es_indefinido, 'ZZ' tipo_responsable, 'Indefinido' des_tipo_responsable;


CREATE OR ALTER TABLE @@norm.ot_fases_proceso(
	#id_fase_proceso		int identity(1,1),
	fase_proceso 			varchar(2) NOT NULL,
	des_fase_proceso		varchar(50) NOT NULL,
	es_indefinido			bit DEFAULT 0,			
	fec_alta				datetime,
	fec_modificacion		datetime,
	fec_baja				datetime,
	CONSTRAINT uk_ot_fases_proceso UNIQUE (fase_proceso)
)

MERGE @@norm.ot_fases_proceso
SELECT 1 #es_indefinido, 'ZZ' fase_proceso, 'Indefinido' des_fase_proceso;	

CREATE OR REPLACE PROCEDURE @@proc.cargar_normalizado_ot_fases_proceso(@logpadre int)
LOAD @@norm.ot_fases_proceso partition ( tbn1_ot_fases_proceso.es_indefinido=0 ) with SCD1 
select 
	right('0'+cast(fapr.fase_proceso as varchar),2)	#fase_proceso,
	fapr.des_fase_proceso 							des_fase_proceso
from file with column names '@@root/data/OT_fase_proceso.csv' fapr




CREATE OR ALTER TABLE @@norm.ot_estados(
	#id_estado			int identity(1,1),
	cod_estado			varchar(1) NOT NULL,
	des_estado			varchar(20) NOT NULL,
	es_indefinido		bit DEFAULT 0,		
	fec_alta			datetime,
	fec_modificacion	datetime,
	fec_baja			datetime,
	CONSTRAINT uk_ot_estados UNIQUE (cod_estado)
)

MERGE @@norm.ot_estados
SELECT 1 #es_indefinido, 'Z' cod_estado, 'No Informado' des_estado;

CREATE OR REPLACE PROCEDURE @@proc.cargar_normalizado_ot_estados(@logpadre int)
LOAD @@norm.ot_estados partition ( tbn1_ot_estados.es_indefinido=0 ) with SCD1 
select 	est.cod_estado													#cod_estado, 
--		left(coalesce(cod_estado + ' - ' + des_estado, cod_estado), 20)	des_estado
		des_estado 														des_estado
from file with column names '@@root/data/OT_estados.csv' est 		
group by all




CREATE OR ALTER TABLE @@norm.ot_oficinas(
	#id_oficina			int identity(1,1),
	cod_oficina			varchar(4) NOT NULL,
	des_oficina			varchar(50) NOT NULL,
	cod_grupo_oficina	int			NOT NULL default 0,
	grupo_oficina		varchar(30) NOT NULL default '',
	es_indefinido		bit DEFAULT 0,	
	fec_alta			datetime,
	fec_modificacion	datetime,
	fec_baja			datetime,
	CONSTRAINT uk_ot_oficinas UNIQUE (cod_oficina)
)

MERGE @@norm.ot_oficinas
SELECT 1 #es_indefinido, 'ZZZZ' cod_oficina, 'Otras' des_oficina, 0 cod_grupo_oficina, 'OTRAS' grupo_oficina;

CREATE OR REPLACE PROCEDURE @@proc.cargar_normalizado_ot_oficinas(@logpadre int)
LOAD @@norm.ot_oficinas with SCD1
select 	--mov.conzona + mov.conszona										#cod_oficina,
		ofi.equiequipo														#cod_oficina,
--	    left(coalesce(cod_oficina + ' - ' + ofi.equidesc, cod_oficina), 50)	des_oficina,		
	    ofi.equidesc 														des_oficina,		
		coalesce(grof.cod_grupo_oficina,0)									cod_grupo_oficina,
		coalesce(grof.grupo_oficina, 'OTRAS')							grupo_oficina
--from @@tmp.cont mov
from @@stg.equi_z3 ofi
left join file with column names '@@root/data/OT_oficinas.csv' grof on right('000'+cast(grof.cod_oficina as varchar),4) = ofi.equiequipo
group by all




CREATE OR ALTER TABLE @@norm.ot_antiguedad_contraido(
	#id_antiguedad		int identity(1,1),
	cod_antiguedad		int NOT NULL,
	des_antiguedad		varchar(20) NOT NULL,
	es_indefinido		bit DEFAULT 0,		
	fec_alta			datetime,
	fec_modificacion	datetime,
	fec_baja			datetime,
	CONSTRAINT uk_ot_antiguedad UNIQUE (cod_antiguedad)
)

MERGE @@norm.ot_antiguedad_contraido
SELECT 1 #es_indefinido, 99 cod_antiguedad, 'Otra' des_antiguedad;

CREATE OR REPLACE PROCEDURE @@proc.cargar_normalizado_ot_antiguedad_contraido(@logpadre int)
LOAD @@norm.ot_antiguedad_contraido partition ( tbn1_ot_antiguedad_contraido.es_indefinido=0 ) with SCD1 
select 	antig.cod_antiguedad																											#cod_antiguedad,
--		left(coalesce(cast(antig.cod_antiguedad as varchar) + ' - ' + antig.des_antiguedad, cast(antig.cod_antiguedad as varchar)), 20)	des_antiguedad         
		antig.des_antiguedad																											des_antiguedad         
from file with column names '@@root/data/OT_antiguedad_contraido.csv' antig 		
group by all




CREATE OR ALTER TABLE @@norm.ot_formatos_ingreso(
	#id_formato_ingreso	int identity(1,1),
	cod_formato_ingreso	nvarchar(4) NOT NULL,
	des_formato_ingreso	nvarchar(40) NOT NULL,
	cod_agrupacion_formato_ingreso	int 			NOT NULL default 1,
	des_agrupacion_formato_ingreso 	nvarchar(40) 	NOT NULL default '',	
	es_indefinido		bit DEFAULT 0,		
	fec_alta			datetime,
	fec_modificacion	datetime,
	fec_baja			datetime,
	CONSTRAINT uk_ot_formatos_ingreso UNIQUE (cod_formato_ingreso)
)

MERGE @@norm.ot_formatos_ingreso
SELECT 1 #es_indefinido, 'ZZZZ' cod_formato_ingreso, 'Indefinido' des_formato_ingreso, 0 cod_agrupacion_formato_ingreso, 'INDEFINIDO' des_agrupacion_formato_ingreso;

CREATE OR REPLACE PROCEDURE @@proc.cargar_normalizado_ot_formatos_ingreso(@logpadre int)
LOAD @@norm.ot_formatos_ingreso partition ( tbn1_ot_formatos_ingreso.es_indefinido=0 ) with SCD1 
select 	substring(foin.auxi_re02_clave, 22,4) 						#cod_formato_ingreso, 
--		left(coalesce(cod_formato_ingreso + ' - ' + foin.auxi_re02_descr_c, cod_formato_ingreso), 40)	des_formato_ingreso,         
		foin.auxi_re02_descr_c										des_formato_ingreso,         
        coalesce(grfo.cod_agrupacion_formato_ingreso,0)				cod_agrupacion_formato_ingreso,
		coalesce(grfo.des_agrupacion_formato_ingreso,'INDEFINIDO')	des_agrupacion_formato_ingreso
from @@stg.auxi_s7_r02 	foin
left join file with column names '@@root/data/OT_formatos_ingreso.csv' grfo on grfo.cod_formato_ingreso = substring(foin.auxi_re02_clave, 22,4)
group by all




CREATE OR ALTER TABLE @@norm.ot_aplicaciones_lote(
	#id_aplicacion_lote	int identity(1,1),
	cod_aplicacion_lote	nvarchar(2) NOT NULL,
	des_aplicacion_lote	nvarchar(30) NOT NULL,
	es_indefinido		bit DEFAULT 0,		
	fec_alta			datetime,
	fec_modificacion	datetime,
	fec_baja			datetime,
	CONSTRAINT uk_ot_aplicacion_lote UNIQUE (cod_aplicacion_lote)
)

MERGE @@norm.ot_aplicaciones_lote
SELECT 1 #es_indefinido, '99' cod_aplicacion_lote, 'Indefinido' des_aplicacion_lote;

CREATE OR REPLACE PROCEDURE @@proc.cargar_normalizado_ot_aplicaciones_lote(@logpadre int)
LOAD @@norm.ot_aplicaciones_lote partition ( tbn1_ot_aplicaciones_lote.es_indefinido=0 ) with SCD1 
select 	right(aplo.aux1_r13_clave_reg,2) 			#cod_aplicacion_lote, 
--		left(coalesce(cod_aplicacion_lote + ' - ' + aplo.aux1_r13_nomapl_au, cod_aplicacion_lote), 30)	des_aplicacion_lote    
		aplo.aux1_r13_nomapl_au 					des_aplicacion_lote         												     												
from @@stg.aux1_tb_r13 	aplo
group by all



CREATE OR ALTER TABLE @@norm.ot_secciones(
	#id_seccion			int identity(1,1),
	cod_seccion			nvarchar(2) NOT NULL,
	des_seccion			nvarchar(50) NOT NULL,
	es_indefinido		bit DEFAULT 0,		
	fec_alta			datetime,
	fec_modificacion	datetime,
	fec_baja			datetime,
	CONSTRAINT uk_ot_secciones UNIQUE (cod_seccion)
)

MERGE @@norm.ot_secciones
SELECT 1 #es_indefinido, '99' cod_seccion, 'Indefinida' des_seccion;

CREATE OR REPLACE PROCEDURE @@proc.cargar_normalizado_ot_secciones(@logpadre int)
LOAD @@norm.ot_secciones partition ( tbn1_ot_secciones.es_indefinido=0 ) with SCD1 
select right(aux1_r51_clave_reg,2)					#cod_seccion, 
--	   left(coalesce(cod_seccion + ' - ' + sec.aux1_r51_nomc51_au, cod_seccion), 50)	des_seccion 											
	   sec.aux1_r51_nomc51_au						des_seccion 
from @@stg.aux1_tb_r51 	sec
group by all




CREATE OR ALTER TABLE @@norm.ot_entidades(
	#id_entidad			int identity(1,1),
	entidad				nvarchar(2) NOT NULL,
	des_entidad			nvarchar(50) NOT NULL,
	es_indefinido		bit DEFAULT 0,		
	fec_alta			datetime,
	fec_modificacion	datetime,
	fec_baja			datetime,
	CONSTRAINT uk_ot_entidades UNIQUE (entidad)
)

MERGE @@norm.ot_entidades
SELECT 1 #es_indefinido, 'ZZ' entidad, 'Indefinida' des_entidad;

CREATE OR REPLACE PROCEDURE @@proc.cargar_normalizado_ot_entidades(@logpadre int)
LOAD @@norm.ot_entidades partition ( tbn1_ot_entidades.es_indefinido=0 ) with SCD1 
select 	
entidad #entidad,
des_entidad		des_entidad         
from file with column names '@@root/data/OT_entidades.csv'		
group by all



CREATE OR ALTER TABLE @@norm.ot_origenes(
	#id_origen_liquidacion	int identity(1,1),
	cod_origen				varchar(2) NOT NULL,
	des_origen				varchar(30) NOT NULL,
	es_indefinido			bit DEFAULT 0,		
	fec_alta				datetime,
	fec_modificacion		datetime,
	fec_baja				datetime,
	CONSTRAINT uk_ot_origenes UNIQUE (cod_origen)
)

MERGE @@norm.ot_origenes
SELECT 1 #es_indefinido, '' cod_origen, 'Indefinido' des_origen;



CREATE OR ALTER TABLE @@norm.ot_estado_situacion(
	#id_estado_situacion	int identity(1,1),
	cod_estado_situacion	varchar(2) NOT NULL,
	des_estado_situacion	varchar(30) NOT NULL,
	es_indefinido			bit DEFAULT 0,		
	fec_alta				datetime,
	fec_modificacion		datetime,
	fec_baja				datetime,
	CONSTRAINT uk_ot_estado_situacion UNIQUE (cod_estado_situacion)
)

MERGE @@norm.ot_estado_situacion
SELECT 1 #es_indefinido, '' cod_estado_situacion, 'Otros' des_estado_situacion;

CREATE OR REPLACE PROCEDURE @@proc.cargar_normalizado_ot_estado_situacion(@logpadre int)
LOAD @@norm.ot_estado_situacion partition ( tbn1_ot_estado_situacion.es_indefinido=0 ) with SCD1 
select 	#cod_estado_situacion,
		des_estado_situacion         
from file with column names '@@root/data/OT_estado_situacion_hibrida.csv'		
group by all




CREATE OR REPLACE PROCEDURE @@proc.cargar_normalizado_maestros(@logpadre int)
BEGIN
	EXEC @@proc.cargar_normalizado_ot_tipos_ingreso(@log)	
    EXEC @@proc.cargar_normalizado_ot_claves_ingreso(@log)
	EXEC @@proc.cargar_normalizado_ot_claves_contables(@log)	
	EXEC @@proc.cargar_normalizado_ot_grupos_subgrupos_subconceptos_lista(@log)	
    EXEC @@proc.cargar_normalizado_ot_grupos_subgrupos_subconceptos_no_lista(@log)	
	EXEC @@proc.cargar_normalizado_ot_modos_ingreso(@log)	
	EXEC @@proc.cargar_normalizado_ot_situaciones(@log)
	EXEC @@proc.cargar_normalizado_ot_codigos_operacion(@log)
    EXEC @@proc.cargar_normalizado_ot_tipos_compensacion(@log)	
	EXEC @@proc.cargar_normalizado_ot_tipos_responsable(@log)
	EXEC @@proc.cargar_normalizado_ot_fases_proceso(@log)
	EXEC @@proc.cargar_normalizado_ot_estados(@log)
	EXEC @@proc.cargar_normalizado_ot_oficinas(@log)
	EXEC @@proc.cargar_normalizado_ot_antiguedad_contraido(@log)
	EXEC @@proc.cargar_normalizado_ot_formatos_ingreso(@log)
	EXEC @@proc.cargar_normalizado_ot_aplicaciones_lote(@log)
	EXEC @@proc.cargar_normalizado_ot_secciones(@log)
	EXEC @@proc.cargar_normalizado_ot_entidades(@log)
	EXEC @@proc.cargar_normalizado_ot_origenes(@log)
	EXEC @@proc.cargar_normalizado_ot_estado_situacion(@log)
END






MERGE @@norm.indefinidos
SELECT 
  1 #es_indefinido,
  situacion.id_situacion,
  tipo_ingreso.id_tipo_ingreso,
  codigo_operacion.id_codigo_operacion,
  tipo_compensacion.id_tipo_compensacion,
  tipo_responsable.id_tipo_responsable,
  modo_ingreso.id_modo_ingreso,
  fase_proceso.id_fase_proceso,
  clave_contable.id_clave_contable,
  subcon.id_grupo_subgrupo_subconcepto,
  antig.id_antiguedad,
  ofi.id_oficina,
  est.id_estado,
  foin.id_formato_ingreso,
  aplo.id_aplicacion_lote,
  sec.id_seccion,
  ent.id_entidad,
  clin.id_clave_ingreso,
  orig.id_origen_liquidacion,
  estsit.id_estado_situacion
FROM @@norm.tipos_documento tipos_documento
CROSS JOIN @@norm.ot_situaciones situacion
CROSS JOIN @@norm.ot_tipos_ingreso tipo_ingreso
CROSS JOIN @@norm.ot_codigos_operacion codigo_operacion
CROSS JOIN @@norm.ot_tipos_compensacion tipo_compensacion
CROSS JOIN @@norm.ot_tipos_responsable tipo_responsable
CROSS JOIN @@norm.ot_modos_ingreso modo_ingreso
CROSS JOIN @@norm.ot_fases_proceso fase_proceso
CROSS JOIN @@norm.ot_claves_contables clave_contable
CROSS JOIN @@norm.ot_grupos_subgrupos_subconceptos subcon
CROSS JOIN @@norm.ot_antiguedad_contraido antig
CROSS JOIN @@norm.ot_oficinas ofi
CROSS JOIN @@norm.ot_estados est
CROSS JOIN @@norm.ot_formatos_ingreso foin
CROSS JOIN @@norm.ot_aplicaciones_lote aplo
CROSS JOIN @@norm.ot_secciones sec
CROSS JOIN @@norm.ot_entidades ent
CROSS JOIN @@norm.ot_claves_ingreso clin
CROSS JOIN @@norm.ot_origenes orig
CROSS JOIN @@norm.ot_estado_situacion estsit
WHERE
  tipos_documento.es_indefinido=1
  AND situacion.es_indefinido=1 
  AND tipo_ingreso.es_indefinido=1 
  AND codigo_operacion.es_indefinido=1
  AND tipo_compensacion.es_indefinido=1
  AND tipo_responsable.es_indefinido=1  
  AND modo_ingreso.es_indefinido=1 
  AND fase_proceso.es_indefinido=1 
  AND clave_contable.es_indefinido=1  
  AND subcon.es_indefinido=1
  AND antig.es_indefinido=1
  AND ofi.es_indefinido=1
  and est.es_indefinido=1
  and foin.es_indefinido=1
  and aplo.es_indefinido=1
  and sec.es_indefinido=1
  and ent.es_indefinido=1
  and clin.es_indefinido=1
  and orig.es_indefinido=1  
  and estsit.es_indefinido=1  