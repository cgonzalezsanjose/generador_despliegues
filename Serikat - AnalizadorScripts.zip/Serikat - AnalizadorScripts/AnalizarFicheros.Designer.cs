﻿namespace Serikat___AnalizadorScripts
{
	partial class AnalizarFicheros
	{
		/// <summary>
		/// Variable del diseñador requerida.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Limpiar los recursos que se estén utilizando.
		/// </summary>
		/// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Código generado por el Diseñador de Windows Forms

		/// <summary>
		/// Método necesario para admitir el Diseñador. No se puede modificar
		/// el contenido del método con el editor de código.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnExaminarFichero = new System.Windows.Forms.Button();
			this.ofdFichero = new System.Windows.Forms.OpenFileDialog();
			this.tbFichero = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.tbRegex = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.btnAnalizar = new System.Windows.Forms.Button();
			this.rbCreate = new System.Windows.Forms.RadioButton();
			this.gbTipos = new System.Windows.Forms.GroupBox();
			this.rbTruncateTable = new System.Windows.Forms.RadioButton();
			this.rbDrop = new System.Windows.Forms.RadioButton();
			this.rbUpdate = new System.Windows.Forms.RadioButton();
			this.rbInsertInto = new System.Windows.Forms.RadioButton();
			this.rbFromJoinsApply = new System.Windows.Forms.RadioButton();
			this.rbDropTableSinCreate = new System.Windows.Forms.RadioButton();
			this.rbTodos = new System.Windows.Forms.RadioButton();
			this.rbMerge = new System.Windows.Forms.RadioButton();
			this.gridDatos = new System.Windows.Forms.DataGridView();
			this.fbCarpeta = new System.Windows.Forms.FolderBrowserDialog();
			this.btnExaminarCarpeta = new System.Windows.Forms.Button();
			this.label3 = new System.Windows.Forms.Label();
			this.tbCarpeta = new System.Windows.Forms.TextBox();
			this.statusStrip1 = new System.Windows.Forms.StatusStrip();
			this.lblStatus = new System.Windows.Forms.ToolStripStatusLabel();
			this.tbFiltro = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.btnFiltrar = new System.Windows.Forms.Button();
			this.chkRecursivo = new System.Windows.Forms.CheckBox();
			this.gbTipos.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.gridDatos)).BeginInit();
			this.statusStrip1.SuspendLayout();
			this.SuspendLayout();
			// 
			// btnExaminarFichero
			// 
			this.btnExaminarFichero.Location = new System.Drawing.Point(490, 41);
			this.btnExaminarFichero.Name = "btnExaminarFichero";
			this.btnExaminarFichero.Size = new System.Drawing.Size(29, 23);
			this.btnExaminarFichero.TabIndex = 1;
			this.btnExaminarFichero.Text = "...";
			this.btnExaminarFichero.UseVisualStyleBackColor = true;
			this.btnExaminarFichero.Click += new System.EventHandler(this.btnExaminarFichero_Click);
			// 
			// tbFichero
			// 
			this.tbFichero.Location = new System.Drawing.Point(49, 44);
			this.tbFichero.Name = "tbFichero";
			this.tbFichero.ReadOnly = true;
			this.tbFichero.Size = new System.Drawing.Size(435, 20);
			this.tbFichero.TabIndex = 1;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(5, 46);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(45, 13);
			this.label1.TabIndex = 2;
			this.label1.Text = "Fichero:";
			// 
			// tbRegex
			// 
			this.tbRegex.Location = new System.Drawing.Point(56, 149);
			this.tbRegex.Name = "tbRegex";
			this.tbRegex.Size = new System.Drawing.Size(435, 20);
			this.tbRegex.TabIndex = 3;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(9, 152);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(41, 13);
			this.label2.TabIndex = 4;
			this.label2.Text = "Regex:";
			// 
			// btnAnalizar
			// 
			this.btnAnalizar.Location = new System.Drawing.Point(497, 146);
			this.btnAnalizar.Name = "btnAnalizar";
			this.btnAnalizar.Size = new System.Drawing.Size(75, 23);
			this.btnAnalizar.TabIndex = 4;
			this.btnAnalizar.Text = "Analizar";
			this.btnAnalizar.UseVisualStyleBackColor = true;
			this.btnAnalizar.Click += new System.EventHandler(this.btnAnalizar_Click);
			// 
			// rbCreate
			// 
			this.rbCreate.AutoSize = true;
			this.rbCreate.Location = new System.Drawing.Point(87, 19);
			this.rbCreate.Name = "rbCreate";
			this.rbCreate.Size = new System.Drawing.Size(56, 17);
			this.rbCreate.TabIndex = 2;
			this.rbCreate.Text = "Create";
			this.rbCreate.UseVisualStyleBackColor = true;
			this.rbCreate.CheckedChanged += new System.EventHandler(this.rb_CheckedChanged);
			// 
			// gbTipos
			// 
			this.gbTipos.Controls.Add(this.rbTruncateTable);
			this.gbTipos.Controls.Add(this.rbDrop);
			this.gbTipos.Controls.Add(this.rbUpdate);
			this.gbTipos.Controls.Add(this.rbInsertInto);
			this.gbTipos.Controls.Add(this.rbFromJoinsApply);
			this.gbTipos.Controls.Add(this.rbDropTableSinCreate);
			this.gbTipos.Controls.Add(this.rbTodos);
			this.gbTipos.Controls.Add(this.rbMerge);
			this.gbTipos.Controls.Add(this.rbCreate);
			this.gbTipos.Location = new System.Drawing.Point(15, 70);
			this.gbTipos.Name = "gbTipos";
			this.gbTipos.Size = new System.Drawing.Size(506, 70);
			this.gbTipos.TabIndex = 2;
			this.gbTipos.TabStop = false;
			this.gbTipos.Text = "Tipo Regex";
			// 
			// rbTruncateTable
			// 
			this.rbTruncateTable.AutoSize = true;
			this.rbTruncateTable.Location = new System.Drawing.Point(410, 47);
			this.rbTruncateTable.Name = "rbTruncateTable";
			this.rbTruncateTable.Size = new System.Drawing.Size(94, 17);
			this.rbTruncateTable.TabIndex = 10;
			this.rbTruncateTable.Text = "Truncate table";
			this.rbTruncateTable.UseVisualStyleBackColor = true;
			this.rbTruncateTable.CheckedChanged += new System.EventHandler(this.rb_CheckedChanged);
			// 
			// rbDrop
			// 
			this.rbDrop.AutoSize = true;
			this.rbDrop.Location = new System.Drawing.Point(298, 47);
			this.rbDrop.Name = "rbDrop";
			this.rbDrop.Size = new System.Drawing.Size(48, 17);
			this.rbDrop.TabIndex = 9;
			this.rbDrop.Text = "Drop";
			this.rbDrop.UseVisualStyleBackColor = true;
			this.rbDrop.CheckedChanged += new System.EventHandler(this.rb_CheckedChanged);
			// 
			// rbUpdate
			// 
			this.rbUpdate.AutoSize = true;
			this.rbUpdate.Location = new System.Drawing.Point(169, 47);
			this.rbUpdate.Name = "rbUpdate";
			this.rbUpdate.Size = new System.Drawing.Size(60, 17);
			this.rbUpdate.TabIndex = 8;
			this.rbUpdate.Text = "Update";
			this.rbUpdate.UseVisualStyleBackColor = true;
			this.rbUpdate.CheckedChanged += new System.EventHandler(this.rb_CheckedChanged);
			// 
			// rbInsertInto
			// 
			this.rbInsertInto.AutoSize = true;
			this.rbInsertInto.Location = new System.Drawing.Point(87, 47);
			this.rbInsertInto.Name = "rbInsertInto";
			this.rbInsertInto.Size = new System.Drawing.Size(71, 17);
			this.rbInsertInto.TabIndex = 7;
			this.rbInsertInto.Text = "Insert into";
			this.rbInsertInto.UseVisualStyleBackColor = true;
			this.rbInsertInto.CheckedChanged += new System.EventHandler(this.rb_CheckedChanged);
			// 
			// rbFromJoinsApply
			// 
			this.rbFromJoinsApply.AutoSize = true;
			this.rbFromJoinsApply.Location = new System.Drawing.Point(298, 19);
			this.rbFromJoinsApply.Name = "rbFromJoinsApply";
			this.rbFromJoinsApply.Size = new System.Drawing.Size(106, 17);
			this.rbFromJoinsApply.TabIndex = 4;
			this.rbFromJoinsApply.Text = "From, joins, apply";
			this.rbFromJoinsApply.UseVisualStyleBackColor = true;
			this.rbFromJoinsApply.CheckedChanged += new System.EventHandler(this.rb_CheckedChanged);
			// 
			// rbDropTableSinCreate
			// 
			this.rbDropTableSinCreate.AutoSize = true;
			this.rbDropTableSinCreate.Location = new System.Drawing.Point(169, 19);
			this.rbDropTableSinCreate.Name = "rbDropTableSinCreate";
			this.rbDropTableSinCreate.Size = new System.Drawing.Size(123, 17);
			this.rbDropTableSinCreate.TabIndex = 3;
			this.rbDropTableSinCreate.Text = "Drop table sin create";
			this.rbDropTableSinCreate.UseVisualStyleBackColor = true;
			this.rbDropTableSinCreate.CheckedChanged += new System.EventHandler(this.rb_CheckedChanged);
			// 
			// rbTodos
			// 
			this.rbTodos.AutoSize = true;
			this.rbTodos.Checked = true;
			this.rbTodos.Location = new System.Drawing.Point(22, 19);
			this.rbTodos.Name = "rbTodos";
			this.rbTodos.Size = new System.Drawing.Size(55, 17);
			this.rbTodos.TabIndex = 1;
			this.rbTodos.TabStop = true;
			this.rbTodos.Text = "Todos";
			this.rbTodos.UseVisualStyleBackColor = true;
			this.rbTodos.CheckedChanged += new System.EventHandler(this.rb_CheckedChanged);
			// 
			// rbMerge
			// 
			this.rbMerge.AutoSize = true;
			this.rbMerge.Location = new System.Drawing.Point(410, 19);
			this.rbMerge.Name = "rbMerge";
			this.rbMerge.Size = new System.Drawing.Size(55, 17);
			this.rbMerge.TabIndex = 5;
			this.rbMerge.Text = "Merge";
			this.rbMerge.UseVisualStyleBackColor = true;
			this.rbMerge.CheckedChanged += new System.EventHandler(this.rb_CheckedChanged);
			// 
			// gridDatos
			// 
			this.gridDatos.AllowUserToAddRows = false;
			this.gridDatos.AllowUserToDeleteRows = false;
			this.gridDatos.AllowUserToOrderColumns = true;
			this.gridDatos.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.gridDatos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.gridDatos.Location = new System.Drawing.Point(12, 186);
			this.gridDatos.Name = "gridDatos";
			this.gridDatos.Size = new System.Drawing.Size(587, 332);
			this.gridDatos.TabIndex = 5;
			this.gridDatos.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.gridDatos_CellMouseDoubleClick);
			this.gridDatos.SelectionChanged += new System.EventHandler(this.gridDatos_SelectionChanged);
			// 
			// fbCarpeta
			// 
			this.fbCarpeta.ShowNewFolderButton = false;
			// 
			// btnExaminarCarpeta
			// 
			this.btnExaminarCarpeta.Location = new System.Drawing.Point(490, 12);
			this.btnExaminarCarpeta.Name = "btnExaminarCarpeta";
			this.btnExaminarCarpeta.Size = new System.Drawing.Size(29, 23);
			this.btnExaminarCarpeta.TabIndex = 0;
			this.btnExaminarCarpeta.Text = "...";
			this.btnExaminarCarpeta.UseVisualStyleBackColor = true;
			this.btnExaminarCarpeta.Click += new System.EventHandler(this.btnExaminarCarpeta_Click);
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(2, 12);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(47, 13);
			this.label3.TabIndex = 10;
			this.label3.Text = "Carpeta:";
			// 
			// tbCarpeta
			// 
			this.tbCarpeta.Location = new System.Drawing.Point(49, 12);
			this.tbCarpeta.Name = "tbCarpeta";
			this.tbCarpeta.ReadOnly = true;
			this.tbCarpeta.Size = new System.Drawing.Size(435, 20);
			this.tbCarpeta.TabIndex = 11;
			// 
			// statusStrip1
			// 
			this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lblStatus});
			this.statusStrip1.Location = new System.Drawing.Point(0, 569);
			this.statusStrip1.Name = "statusStrip1";
			this.statusStrip1.Size = new System.Drawing.Size(614, 22);
			this.statusStrip1.TabIndex = 12;
			this.statusStrip1.Text = "statusStrip1";
			// 
			// lblStatus
			// 
			this.lblStatus.Name = "lblStatus";
			this.lblStatus.Size = new System.Drawing.Size(0, 17);
			// 
			// tbFiltro
			// 
			this.tbFiltro.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.tbFiltro.Location = new System.Drawing.Point(115, 535);
			this.tbFiltro.Name = "tbFiltro";
			this.tbFiltro.Size = new System.Drawing.Size(295, 20);
			this.tbFiltro.TabIndex = 13;
			// 
			// label4
			// 
			this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(77, 538);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(32, 13);
			this.label4.TabIndex = 14;
			this.label4.Text = "Filtro:";
			// 
			// btnFiltrar
			// 
			this.btnFiltrar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.btnFiltrar.Location = new System.Drawing.Point(416, 533);
			this.btnFiltrar.Name = "btnFiltrar";
			this.btnFiltrar.Size = new System.Drawing.Size(75, 23);
			this.btnFiltrar.TabIndex = 15;
			this.btnFiltrar.Text = "Filtrar";
			this.btnFiltrar.UseVisualStyleBackColor = true;
			this.btnFiltrar.Click += new System.EventHandler(this.btnFiltrar_Click);
			// 
			// chkRecursivo
			// 
			this.chkRecursivo.AutoSize = true;
			this.chkRecursivo.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.chkRecursivo.Checked = true;
			this.chkRecursivo.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkRecursivo.Location = new System.Drawing.Point(526, 15);
			this.chkRecursivo.Name = "chkRecursivo";
			this.chkRecursivo.Size = new System.Drawing.Size(69, 17);
			this.chkRecursivo.TabIndex = 16;
			this.chkRecursivo.Text = "recursivo";
			this.chkRecursivo.UseVisualStyleBackColor = true;
			// 
			// AnalizarFicheros
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(614, 591);
			this.Controls.Add(this.chkRecursivo);
			this.Controls.Add(this.btnFiltrar);
			this.Controls.Add(this.statusStrip1);
			this.Controls.Add(this.tbCarpeta);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.tbFiltro);
			this.Controls.Add(this.btnExaminarCarpeta);
			this.Controls.Add(this.gridDatos);
			this.Controls.Add(this.gbTipos);
			this.Controls.Add(this.btnAnalizar);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.tbRegex);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.tbFichero);
			this.Controls.Add(this.btnExaminarFichero);
			this.Name = "AnalizarFicheros";
			this.Text = "Analizar script";
			this.Load += new System.EventHandler(this.AnalizarFicheros_Load);
			this.gbTipos.ResumeLayout(false);
			this.gbTipos.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.gridDatos)).EndInit();
			this.statusStrip1.ResumeLayout(false);
			this.statusStrip1.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button btnExaminarFichero;
		private System.Windows.Forms.OpenFileDialog ofdFichero;
		private System.Windows.Forms.TextBox tbFichero;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox tbRegex;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Button btnAnalizar;
		private System.Windows.Forms.RadioButton rbCreate;
		private System.Windows.Forms.GroupBox gbTipos;
		private System.Windows.Forms.DataGridView gridDatos;
		private System.Windows.Forms.RadioButton rbMerge;
		private System.Windows.Forms.RadioButton rbTodos;
		private System.Windows.Forms.FolderBrowserDialog fbCarpeta;
		private System.Windows.Forms.Button btnExaminarCarpeta;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox tbCarpeta;
		private System.Windows.Forms.StatusStrip statusStrip1;
		private System.Windows.Forms.ToolStripStatusLabel lblStatus;
		private System.Windows.Forms.RadioButton rbDropTableSinCreate;
		private System.Windows.Forms.RadioButton rbFromJoinsApply;
		private System.Windows.Forms.RadioButton rbInsertInto;
		private System.Windows.Forms.RadioButton rbUpdate;
		private System.Windows.Forms.RadioButton rbDrop;
		private System.Windows.Forms.RadioButton rbTruncateTable;
		private System.Windows.Forms.TextBox tbFiltro;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Button btnFiltrar;
		private System.Windows.Forms.CheckBox chkRecursivo;
	}
}

