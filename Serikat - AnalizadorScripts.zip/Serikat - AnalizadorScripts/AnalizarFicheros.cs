﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Configuration;
using System.Xml;
using System.Collections.Specialized;
using System.IO;
using System.Text.RegularExpressions;
using Serikat.PME.AnalizadorScripts;
using Serikat.PME.AnalizadorScriptsComun;

namespace Serikat___AnalizadorScripts
{
	public partial class AnalizarFicheros : Form
	{
		public AnalizarFicheros()
		{
			InitializeComponent();
		}

		private void btnExaminarFichero_Click(object sender, EventArgs e)
		{
			if(ofdFichero.ShowDialog() != DialogResult.OK) return;
			tbFichero.Text = ofdFichero.FileName;
			tbCarpeta.Text = string.Empty;
		}

		private void AnalizarFicheros_Load(object sender, EventArgs e)
		{
			ofdFichero.Filter = "Archivos soportados|" + ConfigurationManager.AppSettings["filtroFicheros"];
			ofdFichero.InitialDirectory = Environment.CurrentDirectory;
			fbCarpeta.SelectedPath = Environment.CurrentDirectory;
		}

		private string rbSeleccionado = "Todos";
		private string regexSeleccionada = string.Empty;
		private DataTable tabla = new DataTable("datos");

		private void rb_CheckedChanged(object sender, EventArgs e)
		{
			RadioButton rb = sender as RadioButton;
			if(!rb.Checked) return;
			rbSeleccionado = rb.Text;
			XmlDocument docConfig = new XmlDocument();
			docConfig.Load("Configuracion.xml");
			XmlNode nodoExpresion = docConfig.DocumentElement.SelectSingleNode("expresiones/expresion[@name='" + rbSeleccionado + "']");
			if(nodoExpresion != null)
			{
				tbRegex.Text = nodoExpresion.InnerText;
			}
			else
			{
				tbRegex.Text = string.Empty;
			}
			regexSeleccionada = tbRegex.Text;
		}

		private void btnAnalizar_Click(object sender, EventArgs e)
		{
			if (string.IsNullOrEmpty(tbFichero.Text) && string.IsNullOrEmpty(tbCarpeta.Text))
			{
				MessageBox.Show("Debe seleccionar un fichero o carpeta para analizar", "Aviso");
				return;
			}
			if (string.IsNullOrWhiteSpace(rbSeleccionado))
			{
				MessageBox.Show("Debe seleccionar un tipo de análisis", "Aviso");
				return;
			}
			lblStatus.Text = string.Empty;
			NameValueCollection expresiones = new NameValueCollection();
			List<string> excepciones = new List<string>();
			XmlDocument docConfig = new XmlDocument();
			docConfig.Load("Configuracion.xml");
			if(rbTodos.Checked)
			{	
				XmlNodeList nodosExpresiones = docConfig.DocumentElement.SelectNodes("expresiones/expresion");
				foreach(XmlNode nodoExpresion in nodosExpresiones)
				{
					expresiones.Add(nodoExpresion.Attributes["name"].Value, nodoExpresion.InnerText);
				}
			}
			else
			{
				expresiones.Add(rbSeleccionado, regexSeleccionada);
			}
			XmlNodeList nodosExcepciones = docConfig.DocumentElement.SelectNodes("elementosExcluidos/elementoExcluido");
			foreach(XmlNode nodoExcepcion in nodosExcepciones)
			{
				excepciones.Add(nodoExcepcion.InnerText);
			}

			AnalisisScripts analisis = new AnalisisScripts();

			string ruta = string.IsNullOrEmpty(tbFichero.Text)? tbCarpeta.Text : tbFichero.Text;

			tabla = analisis.Analizar(expresiones, ConfigurationManager.AppSettings["filtroFicheros"], ruta, chkRecursivo.Checked);
			
			tabla.Columns.Add("CantidadCoincidencias", typeof(int));

			List<DataRow> rowsAgrupadas = 
			(
				from row in tabla.AsEnumerable()
				where !excepciones.Contains(obtenerNombreObjetoCorto(row.Field<string>(ConfigurationManager.AppSettings["columnaFiltro"])))
				group row by new 
				{
					Fichero =  row.Field<string>("Fichero"),
					Filename = row.Field<string>("___Filename"), 
					Tipo = row.Field<string>("Tipo"),
					TipoObjeto = tabla.Columns.Contains("tipoObjeto")? row.Field<string>("tipoObjeto") : null,
					NombreObjeto = row.Field<string>(ConfigurationManager.AppSettings["columnaFiltro"]) 
				} into grupo
				orderby grupo.Key.Filename, grupo.Key.Fichero, grupo.Key.Tipo, grupo.Key.TipoObjeto, grupo.Key.NombreObjeto
				select ObtenerRow(grupo.Key.Filename, grupo.Key.Fichero, grupo.Key.Tipo, grupo.Key.TipoObjeto, grupo.Key.NombreObjeto, grupo.Count())
			).ToList();

			tabla.Rows.Clear();
			foreach (DataRow row in rowsAgrupadas)
			{
				tabla.Rows.Add(row);
			}
		
			lblStatus.Text = string.Format("Cantidad de elementos: {0} registro(s)", tabla.Rows.Count);
			DataView vista = new DataView(tabla);
			gridDatos.DataSource = vista;
			gridDatos.Columns["___Filename"].Visible = gridDatos.Columns["___PosicionMatch"].Visible = gridDatos.Columns["___LongitudMatch"].Visible = false;
		}

		private string obtenerNombreObjetoCorto(string nombreObjeto)
		{
			return (nombreObjeto.IndexOf('.') != -1)? nombreObjeto.Substring(nombreObjeto.LastIndexOf('.') + 1) : nombreObjeto;
		}

		DataRow ObtenerRow(string filename, string fichero, string tipo, string tipoObjeto, string nombreObjeto, int cantidadCoincidencias)
		{
			DataRow retorno = tabla.NewRow();
			retorno["___Filename"] = filename;
			retorno["Fichero"] = fichero;
			retorno["Tipo"] = tipo;
			if(tabla.Columns.Contains("tipoObjeto")) retorno["tipoObjeto"] = tipoObjeto; // Algunas Regex no tienen este campo
			retorno["CantidadCoincidencias"] = cantidadCoincidencias;
			retorno[ConfigurationManager.AppSettings["columnaFiltro"]] = nombreObjeto;
			return retorno;
		}

		private void btnExaminarCarpeta_Click(object sender, EventArgs e)
		{
			if (fbCarpeta.ShowDialog() != DialogResult.OK) return;
			tbCarpeta.Text = fbCarpeta.SelectedPath;
			tbFichero.Text = string.Empty;
		}

		private void btnFiltrar_Click(object sender, EventArgs e)
		{
			if(gridDatos.DataSource == null)
			{
				MessageBox.Show("Debe analizar un archivo o carpeta si desea filtrar los resultados");
				return;
			}
			DataView vista = (DataView) gridDatos.DataSource;
			if(string.IsNullOrWhiteSpace(tbFiltro.Text))
			{
				vista.RowFilter = string.Empty;
				lblStatus.Text = string.Format("Cantidad de elementos: {0} registro(s)", tabla.Rows.Count);
			}
			else
			{
				vista.RowFilter = ConfigurationManager.AppSettings["columnaFiltro"] + " like '%" + tbFiltro.Text.Replace("'", "''") + "%'";
				int cantidadMostrados = gridDatos.Rows.GetRowCount(DataGridViewElementStates.Visible);
				lblStatus.Text = string.Format("Mostrando {0} de un total de {1} elemento(s)", cantidadMostrados, tabla.Rows.Count);
			}
		}

		private void gridDatos_SelectionChanged(object sender, EventArgs e)
		{
			if(gridDatos.SelectedCells.Count == 0 || gridDatos.SelectedCells[0].OwningColumn.Name != ConfigurationManager.AppSettings["columnaFiltro"]) return;
			tbFiltro.Text = (string)gridDatos.SelectedCells[0].Value;
		}

		private void gridDatos_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
		{
			if(e.RowIndex < 0) return;
			DataGridViewRow rowSeleccionada = gridDatos.CurrentRow;
			string filename = (string)rowSeleccionada.Cells["___Filename"].Value;
			AbrirFichero.AbrirProgramaAsociado(filename);
		}
	}
}
