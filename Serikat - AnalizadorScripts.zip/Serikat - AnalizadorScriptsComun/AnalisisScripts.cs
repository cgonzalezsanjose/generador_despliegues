﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections.Specialized;
using System.Xml;
using System.IO;
using System.Text.RegularExpressions;

namespace Serikat.PME.AnalizadorScriptsComun
{
	public class AnalisisScripts
	{
		/*public DataTable Analizar(NameValueCollection expresiones, string filtroFicheros, string ruta, bool recursivo)
		{

			DataTable tabla = new DataTable("datos");
			NameValueCollection limpiezaPrevia = new NameValueCollection();
			XmlDocument docConfig = new XmlDocument();
			docConfig.Load("Configuracion.xml");
			XmlNodeList nodosLimpieza = docConfig.DocumentElement.SelectNodes("reemplazos/reemplazo");
			foreach (XmlNode nodoLimpieza in nodosLimpieza)
			{
				string valorViejo = nodoLimpieza.SelectSingleNode("valorViejo").InnerText;
				string valorNuevo = nodoLimpieza.SelectSingleNode("valorNuevo").InnerText;
				limpiezaPrevia.Add(valorViejo, valorNuevo);
			}
			tabla.Rows.Clear();
			tabla.Columns.Clear();
			tabla.Columns.Add("Fichero", typeof(string));
			tabla.Columns.Add("Tipo", typeof(string));
			tabla.Columns.Add("___Filename", typeof(string));
			tabla.Columns.Add("___PosicionMatch", typeof(int));
			tabla.Columns.Add("___LongitudMatch", typeof(int));

			FileInfo fichero = new FileInfo(ruta);

			if (fichero.Exists)
			{
				AnalizarFichero(ruta, expresiones, limpiezaPrevia, tabla);
			}
			else
			{
				SearchOption options = recursivo ? SearchOption.AllDirectories : SearchOption.TopDirectoryOnly;
				string[] archivos = Directory.GetFiles(ruta, filtroFicheros, options);
				foreach (string archivo in archivos)
				{
					AnalizarFichero(archivo, expresiones, limpiezaPrevia, tabla);
				}
			}

			return tabla;
		}
		
		private void AnalizarFichero(string filename, NameValueCollection expressiones, NameValueCollection limpiezaPrevia, DataTable tabla)
		{
			string contenidoFichero = File.ReadAllText(filename, Encoding.Default);
			if (limpiezaPrevia.Count > 0)
			{
				foreach (string valorViejo in limpiezaPrevia.Keys)
				{
					contenidoFichero = Regex.Replace(contenidoFichero, valorViejo, limpiezaPrevia[valorViejo], RegexOptions.Compiled | RegexOptions.IgnoreCase | RegexOptions.Multiline);
				}
			}
			FileInfo info = new FileInfo(filename);
			foreach (string nombreExpresion in expressiones.Keys)
			{
				Regex reg = new Regex(expressiones[nombreExpresion], RegexOptions.Compiled | RegexOptions.IgnoreCase | RegexOptions.Multiline);
				MatchCollection coincidencias = reg.Matches(contenidoFichero);
				string[] groupNames = reg.GetGroupNames();
				foreach (string groupName in groupNames)
				{
					if (groupName != "0" && tabla.Columns[groupName] == null)
					{
						tabla.Columns.Add(groupName, typeof(string));

					}
				}
				foreach (Match m in coincidencias)
				{
					try
					{
						DataRow nuevaRow = tabla.NewRow();
						nuevaRow["Fichero"] = info.Name;
						nuevaRow["Tipo"] = nombreExpresion;
						nuevaRow["___Filename"] = info.FullName;
						nuevaRow["___PosicionMatch"] = m.Index;
						nuevaRow["___LongitudMatch"] = m.Length;
						foreach (string groupName in groupNames)
						{
							if (groupName != "0")
							{
								nuevaRow[groupName] = m.Groups[groupName].Value;
							}
						}
						tabla.Rows.Add(nuevaRow);
					}
					catch { }
				}
			}
		}
		 
		 */

		public DataTable Analizar(NameValueCollection expresiones, string filtroFicheros, string ruta, bool recursivo)
		{

			DataTable tabla = new DataTable("datos");
			NameValueCollection limpiezaPrevia = new NameValueCollection();
			XmlDocument docConfig = new XmlDocument();
			docConfig.Load("Configuracion.xml");
			XmlNodeList nodosLimpieza = docConfig.DocumentElement.SelectNodes("reemplazos/reemplazo");
			foreach (XmlNode nodoLimpieza in nodosLimpieza)
			{
				string valorViejo = nodoLimpieza.SelectSingleNode("valorViejo").InnerText;
				string valorNuevo = nodoLimpieza.SelectSingleNode("valorNuevo").InnerText;
				limpiezaPrevia.Add(valorViejo, valorNuevo);
			}
			tabla.Rows.Clear();
			tabla.Columns.Clear();
			tabla.Columns.Add("Fichero", typeof(string));
			tabla.Columns.Add("Tipo", typeof(string));
			tabla.Columns.Add("___Filename", typeof(string));
			tabla.Columns.Add("___PosicionMatch", typeof(int));
			tabla.Columns.Add("___LongitudMatch", typeof(int));

			FileInfo fichero = new FileInfo(ruta);

			Dictionary<string, Regex> regs = new Dictionary<string,Regex>();
			foreach(string key in expresiones.Keys)
			{
				Regex reg = new Regex(expresiones[key], RegexOptions.Compiled | RegexOptions.IgnoreCase | RegexOptions.Multiline);
				regs.Add(key, reg);
			}

			if (fichero.Exists)
			{
				AnalizarFichero(ruta, regs, limpiezaPrevia, tabla);
			}
			else
			{
				SearchOption options = recursivo ? SearchOption.AllDirectories : SearchOption.TopDirectoryOnly;
				string[] archivos = Directory.GetFiles(ruta, filtroFicheros, options);
				/*System.Threading.Tasks.Parallel.ForEach(archivos, archivo =>
				{
					AnalizarFichero(archivo, regs, limpiezaPrevia, tabla);
				});*/
				foreach (string archivo in archivos)
				{
					AnalizarFichero(archivo, regs, limpiezaPrevia, tabla);
				}
			}

			return tabla;
		}

		private void AnalizarFichero(string filename, Dictionary<string, Regex> expresiones, NameValueCollection limpiezaPrevia, DataTable tabla)
		{
			string contenidoFichero = File.ReadAllText(filename, Encoding.Default);
			if (limpiezaPrevia.Count > 0)
			{
				foreach (string valorViejo in limpiezaPrevia.Keys)
				{
					contenidoFichero = Regex.Replace(contenidoFichero, valorViejo, limpiezaPrevia[valorViejo], RegexOptions.Compiled | RegexOptions.IgnoreCase | RegexOptions.Multiline);
				}
			}
			FileInfo info = new FileInfo(filename);
			foreach (string nombreExpresion in expresiones.Keys)
			{
				Regex reg = expresiones[nombreExpresion];
				MatchCollection coincidencias = reg.Matches(contenidoFichero);
				string[] groupNames = reg.GetGroupNames();
				foreach (string groupName in groupNames)
				{
					if (groupName != "0" && tabla.Columns[groupName] == null)
					{
						tabla.Columns.Add(groupName, typeof(string));

					}
				}
				foreach (Match m in coincidencias)
				{
					try
					{
						DataRow nuevaRow = tabla.NewRow();
						nuevaRow["Fichero"] = info.Name;
						nuevaRow["Tipo"] = nombreExpresion;
						nuevaRow["___Filename"] = info.FullName;
						nuevaRow["___PosicionMatch"] = m.Index;
						nuevaRow["___LongitudMatch"] = m.Length;
						foreach (string groupName in groupNames)
						{
							if (groupName != "0")
							{
								nuevaRow[groupName] = m.Groups[groupName].Value;
							}
						}
						tabla.Rows.Add(nuevaRow);
					}
					catch { }
				}
			}
		}
	}
}
