﻿namespace Serikat.PME.AnalizadorScriptsComun
{
	partial class DetalleCoincidencia
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.tbNombreFichero = new System.Windows.Forms.TextBox();
			this.tbLineaCoincidencia = new System.Windows.Forms.TextBox();
			this.tbLineasPosteriores = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.btnRefrescar = new System.Windows.Forms.Button();
			this.tbContenidoFichero = new System.Windows.Forms.TextBox();
			this.tbCoincidencia = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(12, 18);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(45, 13);
			this.label1.TabIndex = 0;
			this.label1.Text = "Fichero:";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(12, 45);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(74, 13);
			this.label2.TabIndex = 1;
			this.label2.Text = "Linea Fichero:";
			// 
			// tbNombreFichero
			// 
			this.tbNombreFichero.Location = new System.Drawing.Point(116, 15);
			this.tbNombreFichero.Name = "tbNombreFichero";
			this.tbNombreFichero.ReadOnly = true;
			this.tbNombreFichero.Size = new System.Drawing.Size(318, 20);
			this.tbNombreFichero.TabIndex = 2;
			// 
			// tbLineaCoincidencia
			// 
			this.tbLineaCoincidencia.Location = new System.Drawing.Point(117, 45);
			this.tbLineaCoincidencia.Name = "tbLineaCoincidencia";
			this.tbLineaCoincidencia.ReadOnly = true;
			this.tbLineaCoincidencia.Size = new System.Drawing.Size(54, 20);
			this.tbLineaCoincidencia.TabIndex = 3;
			this.tbLineaCoincidencia.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// tbLineasPosteriores
			// 
			this.tbLineasPosteriores.Location = new System.Drawing.Point(546, 15);
			this.tbLineasPosteriores.Name = "tbLineasPosteriores";
			this.tbLineasPosteriores.Size = new System.Drawing.Size(54, 20);
			this.tbLineasPosteriores.TabIndex = 7;
			this.tbLineasPosteriores.Text = "20";
			this.tbLineasPosteriores.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(450, 21);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(95, 13);
			this.label4.TabIndex = 6;
			this.label4.Text = "Lineas posteriores:";
			// 
			// btnRefrescar
			// 
			this.btnRefrescar.Location = new System.Drawing.Point(618, 13);
			this.btnRefrescar.Name = "btnRefrescar";
			this.btnRefrescar.Size = new System.Drawing.Size(75, 23);
			this.btnRefrescar.TabIndex = 8;
			this.btnRefrescar.Text = "Refrescar";
			this.btnRefrescar.UseVisualStyleBackColor = true;
			this.btnRefrescar.Click += new System.EventHandler(this.btnRefrescar_Click);
			// 
			// tbContenidoFichero
			// 
			this.tbContenidoFichero.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.tbContenidoFichero.Location = new System.Drawing.Point(15, 85);
			this.tbContenidoFichero.Multiline = true;
			this.tbContenidoFichero.Name = "tbContenidoFichero";
			this.tbContenidoFichero.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			this.tbContenidoFichero.Size = new System.Drawing.Size(678, 316);
			this.tbContenidoFichero.TabIndex = 9;
			// 
			// tbCoincidencia
			// 
			this.tbCoincidencia.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.tbCoincidencia.Location = new System.Drawing.Point(249, 45);
			this.tbCoincidencia.Name = "tbCoincidencia";
			this.tbCoincidencia.ReadOnly = true;
			this.tbCoincidencia.Size = new System.Drawing.Size(432, 20);
			this.tbCoincidencia.TabIndex = 10;
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(177, 48);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(71, 13);
			this.label3.TabIndex = 11;
			this.label3.Text = "Coincidencia:";
			// 
			// DetalleCoincidencia
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(719, 440);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.tbCoincidencia);
			this.Controls.Add(this.tbContenidoFichero);
			this.Controls.Add(this.btnRefrescar);
			this.Controls.Add(this.tbLineasPosteriores);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.tbLineaCoincidencia);
			this.Controls.Add(this.tbNombreFichero);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Name = "DetalleCoincidencia";
			this.Text = "DetalleCoincidencia";
			this.Activated += new System.EventHandler(this.DetalleCoincidencia_Activated);
			this.Load += new System.EventHandler(this.DetalleCoincidencia_Load);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox tbNombreFichero;
		private System.Windows.Forms.TextBox tbLineaCoincidencia;
		private System.Windows.Forms.TextBox tbLineasPosteriores;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Button btnRefrescar;
		private System.Windows.Forms.TextBox tbContenidoFichero;
		private System.Windows.Forms.TextBox tbCoincidencia;
		private System.Windows.Forms.Label label3;
	}
}