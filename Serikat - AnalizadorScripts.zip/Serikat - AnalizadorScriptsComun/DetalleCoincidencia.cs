﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Text.RegularExpressions;
using System.Collections.Specialized;
using System.IO;
using System.Xml;

namespace Serikat.PME.AnalizadorScriptsComun
{
	public partial class DetalleCoincidencia : Form
	{
		private string fileName { get; set; }
		private int posicionMatch { get; set; }
		private int longitudMatch { get; set; }

		public DetalleCoincidencia()
		{
			InitializeComponent();
		}

		public DetalleCoincidencia(string filename, int posicionMatch, int longitudMatch)
		{
			InitializeComponent();

			this.fileName = filename;
			this.posicionMatch = posicionMatch;
			this.longitudMatch = longitudMatch;
		}

		int posRelativaMatch = 0;

		private void DetalleCoincidencia_Load(object sender, EventArgs e)
		{
			tbNombreFichero.Text = this.fileName;
		}

		private void btnRefrescar_Click(object sender, EventArgs e)
		{
			analizarFichero();
		}

		private void analizarFichero()
		{
			tbContenidoFichero.Text = string.Empty;

			string contenidoFichero = File.ReadAllText(this.fileName, Encoding.Default);

			XmlDocument doc = new XmlDocument();
			doc.Load("Configuracion.xml");

			NameValueCollection limpiezaPrevia = new NameValueCollection();
			XmlNodeList nodosLimpieza = doc.DocumentElement.SelectNodes("reemplazos/reemplazo");
			foreach (XmlNode nodoLimpieza in nodosLimpieza)
			{
				string valorViejo = nodoLimpieza.SelectSingleNode("valorViejo").InnerText;
				string valorNuevo = nodoLimpieza.SelectSingleNode("valorNuevo").InnerText;
				limpiezaPrevia.Add(valorViejo, valorNuevo);
			}

			if (limpiezaPrevia.Count > 0)
			{
				foreach (string valorViejo in limpiezaPrevia.Keys)
				{
					contenidoFichero = Regex.Replace(contenidoFichero, valorViejo, limpiezaPrevia[valorViejo], RegexOptions.Compiled | RegexOptions.IgnoreCase | RegexOptions.Multiline);
				}
			}
			int lineaCoincidencia = 0;
			if(this.posicionMatch != 0)
			{
				string contenidoPrevio = contenidoFichero.Substring(0, this.posicionMatch);
				lineaCoincidencia = contenidoPrevio.Count(p => p == '\n');
			}
			tbLineaCoincidencia.Text = (lineaCoincidencia + 1).ToString();
			string[] lineasFichero = contenidoFichero.Split('\n');
			
			

			Regex regPrevio = new Regex(doc.DocumentElement.SelectSingleNode("regexContexto").InnerText, RegexOptions.Compiled | RegexOptions.IgnoreCase);

			StringBuilder builderTb = new StringBuilder();

			int lineasMetidas = -1;

			for (int i = 0; i < lineaCoincidencia; i++)
			{
				Match encontrado = regPrevio.Match(lineasFichero[i]);
				if(encontrado.Success)
				{
					builderTb = new StringBuilder();
					lineasMetidas = -1;
				}
				lineasMetidas++;
				builderTb.AppendLine(lineasFichero[i]);
			}

			this.posRelativaMatch = lineaCoincidencia;
			builderTb.AppendLine(lineasFichero[lineaCoincidencia]);
			tbCoincidencia.Text = lineasFichero[lineaCoincidencia];
			lineasMetidas++;

			int posLineasLimite = lineaCoincidencia + int.Parse(tbLineasPosteriores.Text);
			int posLineaActual = lineaCoincidencia + 1;

			while(posLineaActual <= posLineasLimite && posLineaActual < lineasFichero.Length - 1)
			{
				builderTb.AppendLine(lineasFichero[posLineaActual]);	
				posLineaActual ++;
			}
			tbContenidoFichero.Focus();
			tbContenidoFichero.Text = builderTb.ToString();
			tbContenidoFichero.SelectionStart = tbContenidoFichero.Text.Length - 1;
			tbContenidoFichero.ScrollToCaret();

			tbContenidoFichero.SelectionStart = tbContenidoFichero.GetFirstCharIndexFromLine(lineasMetidas);
			tbContenidoFichero.SelectionLength = tbContenidoFichero.Text.IndexOf('\n', tbContenidoFichero.SelectionStart) - tbContenidoFichero.SelectionStart;
			tbContenidoFichero.ScrollToCaret();
			/*			tbContenidoFichero.Select();
			 */
			
			
		}

		private void DetalleCoincidencia_Activated(object sender, EventArgs e)
		{
			analizarFichero();
		}
	}
}
