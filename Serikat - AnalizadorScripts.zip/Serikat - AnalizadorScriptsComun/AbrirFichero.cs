﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Diagnostics;

namespace Serikat.PME.AnalizadorScriptsComun
{
	public class AbrirFichero
	{
		public static void AbrirProgramaAsociado(string filename)
		{
			ProcessStartInfo info = new ProcessStartInfo(filename);
			info.Verb = "open";
			Process.Start(info);
		}
	}
}
