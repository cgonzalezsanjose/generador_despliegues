﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;

using Serikat.PME.AnalizadorScriptsComun;
using System.Collections.Specialized;
using System.Xml;

namespace Serikat___BusquedaObjetosETL
{
	public partial class BusquedaObjetos : Form
	{
		public BusquedaObjetos()
		{
			InitializeComponent();
		}

		private void btnAnalizar_Click(object sender, EventArgs e)
		{
			Analizar();
		}

		private string rbSeleccionado = "Todos";
		private string regexSeleccionada = string.Empty;

		private void rb_CheckedChanged(object sender, EventArgs e)
		{
			RadioButton rb = sender as RadioButton;
			if(!rb.Checked) return;
			rbSeleccionado = rb.Text;
			XmlDocument docConfig = new XmlDocument();
			docConfig.Load("Configuracion.xml");
			XmlNode nodoExpresion = docConfig.DocumentElement.SelectSingleNode("expresiones/expresion[@name='" + rbSeleccionado + "']");
			if (nodoExpresion != null)
			{
				regexSeleccionada = nodoExpresion.InnerText;
			}
			else
			{
				regexSeleccionada = string.Empty;
			}
		}

		private void Analizar()
		{
			if(string.IsNullOrWhiteSpace(tbCarpeta.Text))
			{
				MessageBox.Show("Debe indicar una carpeta para analizar", "Aviso");
				return;
			}
			NameValueCollection expresionesTablas = new NameValueCollection();
			NameValueCollection expresionesVistas = new NameValueCollection();
			NameValueCollection expresionesComunes = new NameValueCollection();
			XmlDocument docConfig = new XmlDocument();
			docConfig.Load("Configuracion.xml");
			if(rbTodos.Checked)
			{	
				XmlNodeList nodosExpresiones = docConfig.DocumentElement.SelectNodes("expresiones/expresion");
				foreach(XmlNode nodoExpresion in nodosExpresiones)
				{
					if (nodoExpresion.Attributes["arbol"] == null)
					{
						expresionesComunes.Add(nodoExpresion.Attributes["name"].Value, nodoExpresion.InnerText);	
					}
					else
					{
						if (nodoExpresion.Attributes["arbol"].Value == "Tablas")
						{
							expresionesTablas.Add(nodoExpresion.Attributes["name"].Value, nodoExpresion.InnerText);
						}
						else
						{
							expresionesVistas.Add(nodoExpresion.Attributes["name"].Value, nodoExpresion.InnerText);
						}
						
					}
				}
			}
			else
			{
				switch(rbSeleccionado)
				{
					case "Create table":
					case "Merge":
						expresionesTablas.Add(rbSeleccionado, regexSeleccionada);
						break;
					case "Create view":
						expresionesVistas.Add(rbSeleccionado, regexSeleccionada);
						break;
					case "From, joins, apply":
						expresionesComunes.Add(rbSeleccionado, regexSeleccionada);
						break;
				}
				
			}
			List<string> elementosExcluidos = new List<string>();
			XmlNodeList nodosExcluidos = docConfig.DocumentElement.SelectNodes("elementosExcluidos/elementoExcluido");
			foreach(XmlNode nodoExcluido in nodosExcluidos)
			{
				elementosExcluidos.Add(nodoExcluido.InnerText);
			}

			string nombreColumnaObjeto = ConfigurationManager.AppSettings["columnaFiltro"];

			DataTable dtTablas = Analizar(expresionesTablas);
			dtTablas.TableName = "Tablas";
			DataTable dtVistas = Analizar(expresionesVistas);
			dtVistas.TableName = "Vistas";
			DataTable dtComunes = Analizar(expresionesComunes);

			tvTablas.Nodes.Clear();

			if(dtTablas.Rows.Count > 0 || dtVistas.Rows.Count > 0)
			{
				foreach (DataRow rowComun in dtComunes.Rows)
				{
					string objetoComun = ((string)rowComun[nombreColumnaObjeto]).Replace("'", "''");
					if (objetoComun.IndexOf('.') != -1) objetoComun = objetoComun.Substring(objetoComun.LastIndexOf('.') + 1);
					string condicion = string.Format("{0} = '{1}'", nombreColumnaObjeto, objetoComun);
					DataRow[] encontradosVistas = dtVistas.Select(condicion, "bd desc");
					if (encontradosVistas.Length != 0)
					{
						MeterRowEnTabla(dtVistas, nombreColumnaObjeto, encontradosVistas[0], rowComun);
					}
					if (encontradosVistas.Length == 0)
					{
						DataRow[] encontradosTablas = dtTablas.Select(condicion);
						if (encontradosTablas.Length != 0)
						{
							MeterRowEnTabla(dtTablas, nombreColumnaObjeto, encontradosTablas[0], rowComun);
						}
					}
				}

				DataRow[] rowsTablas = OrdenarTabla(dtTablas, nombreColumnaObjeto);
				DataRow[] rowsVistas = OrdenarTabla(dtVistas, nombreColumnaObjeto);

				PintarTreeView(tvTablas, "Tablas", nombreColumnaObjeto, rowsTablas, elementosExcluidos);
				PintarTreeView(tvTablas, "Vistas", nombreColumnaObjeto, rowsVistas, elementosExcluidos);
			}
			else
			{
				DataRow[] rowsComunes = dtComunes.Select("", "bd desc, esquema desc, " + nombreColumnaObjeto + " desc");
				PintarTreeView(tvTablas, "From, joins, apply", nombreColumnaObjeto, rowsComunes, elementosExcluidos);
			}
		}

		private void MeterRowEnTabla(DataTable tablaDestino, string nombreColumnaObjeto, DataRow rowCopiar, DataRow rowDatos)
		{
			DataRow nuevaRow = tablaDestino.NewRow();
			foreach(DataColumn colDestino in tablaDestino.Columns)
			{
				if(rowDatos.Table.Columns[colDestino.ColumnName] != null)
				{
					nuevaRow[colDestino.ColumnName] = string.IsNullOrEmpty(rowDatos[colDestino.ColumnName] as string) ? rowCopiar[colDestino.ColumnName] : rowDatos[colDestino.ColumnName];
				}
			}
			nuevaRow[nombreColumnaObjeto] = rowCopiar[nombreColumnaObjeto];
			tablaDestino.Rows.Add(nuevaRow);
		}

		private DataRow[] OrdenarTabla(DataTable tabla, string nombreColumnaObjeto)
		{
			if(tabla.Rows.Count == 0) return tabla.Select(" 1 = 2 ");
			string filtroObjeto = string.Empty;
			if (!string.IsNullOrWhiteSpace(tbFiltro.Text)) filtroObjeto = string.Format("{0} like '%{1}%'", nombreColumnaObjeto, tbFiltro.Text.Replace("'", "''"));
			string orden = "";
			if (tabla.Columns.Contains("bd")) orden += "bd ASC, ";
			if (tabla.Columns.Contains("esquema")) orden += "esquema ASC, ";
			orden += string.Format("{0} ASC, Tipo ASC, ___Filename ASC, ___PosicionMatch ASC", nombreColumnaObjeto);
			DataRow[] rowsOrdenadas = tabla.Select(filtroObjeto, orden);
			return rowsOrdenadas;
		}

		private DataTable Analizar(NameValueCollection expresiones)
		{
			AnalisisScripts analisis = new AnalisisScripts();
			DataTable resultados = analisis.Analizar(expresiones, ConfigurationManager.AppSettings["filtroFicheros"], tbCarpeta.Text, chkRecursivo.Checked);
			return resultados;
		}

		private void PintarTreeView(TreeView control, string nombreNodoRaiz, string nombreColumnaObjeto, IEnumerable<DataRow> rows, List<string> elementosExcluidos)
		{
			TreeNode nodoBD = null;
			TreeNode nodoObjeto = null;
			TreeNode nodoTipo = null;

			TreeNode nodoRaiz = control.Nodes.Add(nombreNodoRaiz, nombreNodoRaiz);
			int coincidencias = 1;

			foreach(DataRow row in rows)
			{
				string nombreBD = row["bd"] as string;
				string nombreObjeto = (string)row[nombreColumnaObjeto];
				string filenameCorto = (string)row["___Filename"];
				int posMatch = (int)row["___PosicionMatch"];
				string tipo = (string)row["Tipo"];
				string keyNodoTipo = string.Empty;

				bool excluido = elementosExcluidos.Any(p=> nombreObjeto.ToLower().IndexOf(p.ToLower()) != -1);
				if(!excluido)
				{
					if (nodoBD == null || nombreBD != nodoBD.Text)
					{
						string keyBD = string.Format("{0}|{1}", nombreNodoRaiz, nombreBD);
						nodoBD = nodoRaiz.Nodes.Add(keyBD, nombreBD);
						nodoObjeto = null;
						nodoTipo = null;
					}
					if (nodoObjeto == null || nombreObjeto != nodoObjeto.Text)
					{
						string keyObjeto = string.Format("{0}|{1}|{2}", nombreNodoRaiz, nombreBD, nombreObjeto);
						nodoObjeto = nodoBD.Nodes.Add(keyObjeto, nombreObjeto);
						nodoTipo = null;
					}
					if (nodoTipo == null || tipo != nodoTipo.Text)
					{
						keyNodoTipo = string.Format("{0}|{1}|{2}|{3}", nombreNodoRaiz, nombreBD, nodoObjeto.Text, tipo);
						nodoTipo = nodoObjeto.Nodes.Add(keyNodoTipo, tipo);
					}
					string keyMatch = string.Format("{0}|{1}|{2}|{3}|{4}", nombreNodoRaiz, nombreBD, nodoObjeto.Text, tipo, filenameCorto);
					if(nodoTipo.Nodes.ContainsKey(keyMatch))
					{
						coincidencias ++;
						nodoTipo.Nodes[keyMatch].Text = string.Format("{0} ({1} coincidencias)", filenameCorto, coincidencias);
					}
					else
					{
						coincidencias = 1;
						TreeNode nodoMatch = nodoTipo.Nodes.Add(keyMatch, filenameCorto);
						nodoMatch.Tag = row;
					}
				}
			}
			nodoRaiz.Expand();
		}

		private void BusquedaObjetos_Load(object sender, EventArgs e)
		{
			if(!string.IsNullOrWhiteSpace(ConfigurationManager.AppSettings["RutaAccesoPredeterminada"]))
			{
				tbCarpeta.Text = ConfigurationManager.AppSettings["RutaAccesoPredeterminada"];
				fbCarpeta.SelectedPath = tbCarpeta.Text;
				Analizar();
			}
			else
			{
				fbCarpeta.SelectedPath = Environment.CurrentDirectory;
			}
		}

		private void tv_NodeMouseDoubleClick(object sender, TreeNodeMouseClickEventArgs e)
		{
			if(e.Node == null || e.Node.Tag == null) return;
			DataRow rowSeleccionada = (DataRow) e.Node.Tag;
			string filename = (string)rowSeleccionada["___Filename"];
			AbrirFichero.AbrirProgramaAsociado(filename);
			/*
			int posMatch = (int)rowSeleccionada["___PosicionMatch"];
			int longMatch = (int)rowSeleccionada["___LongitudMatch"];
			DetalleCoincidencia frmDetalle = new DetalleCoincidencia(filename, posMatch, longMatch);
			frmDetalle.ShowDialog();*/
		}

		private void btnExaminarCarpeta_Click(object sender, EventArgs e)
		{
			if (fbCarpeta.ShowDialog() != DialogResult.OK) return;
			tbCarpeta.Text = fbCarpeta.SelectedPath;
		}
	}
}
