﻿namespace Serikat___BusquedaObjetosETL
{
	partial class BusquedaObjetos
	{
		/// <summary>
		/// Variable del diseñador requerida.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Limpiar los recursos que se estén utilizando.
		/// </summary>
		/// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Código generado por el Diseñador de Windows Forms

		/// <summary>
		/// Método necesario para admitir el Diseñador. No se puede modificar
		/// el contenido del método con el editor de código.
		/// </summary>
		private void InitializeComponent()
		{
			this.chkRecursivo = new System.Windows.Forms.CheckBox();
			this.tbCarpeta = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.btnExaminarCarpeta = new System.Windows.Forms.Button();
			this.gbTipos = new System.Windows.Forms.GroupBox();
			this.rbCreateView = new System.Windows.Forms.RadioButton();
			this.rbFromJoinsApply = new System.Windows.Forms.RadioButton();
			this.rbTodos = new System.Windows.Forms.RadioButton();
			this.rbMerge = new System.Windows.Forms.RadioButton();
			this.rbCreateTable = new System.Windows.Forms.RadioButton();
			this.label4 = new System.Windows.Forms.Label();
			this.tbFiltro = new System.Windows.Forms.TextBox();
			this.btnAnalizar = new System.Windows.Forms.Button();
			this.tvTablas = new System.Windows.Forms.TreeView();
			this.statusStrip1 = new System.Windows.Forms.StatusStrip();
			this.lblStatus = new System.Windows.Forms.ToolStripStatusLabel();
			this.fbCarpeta = new System.Windows.Forms.FolderBrowserDialog();
			this.gbTipos.SuspendLayout();
			this.statusStrip1.SuspendLayout();
			this.SuspendLayout();
			// 
			// chkRecursivo
			// 
			this.chkRecursivo.AutoSize = true;
			this.chkRecursivo.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.chkRecursivo.Checked = true;
			this.chkRecursivo.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkRecursivo.Location = new System.Drawing.Point(538, 15);
			this.chkRecursivo.Name = "chkRecursivo";
			this.chkRecursivo.Size = new System.Drawing.Size(69, 17);
			this.chkRecursivo.TabIndex = 24;
			this.chkRecursivo.Text = "recursivo";
			this.chkRecursivo.UseVisualStyleBackColor = true;
			// 
			// tbCarpeta
			// 
			this.tbCarpeta.Location = new System.Drawing.Point(57, 12);
			this.tbCarpeta.Name = "tbCarpeta";
			this.tbCarpeta.ReadOnly = true;
			this.tbCarpeta.Size = new System.Drawing.Size(435, 20);
			this.tbCarpeta.TabIndex = 23;
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(10, 12);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(47, 13);
			this.label3.TabIndex = 22;
			this.label3.Text = "Carpeta:";
			// 
			// btnExaminarCarpeta
			// 
			this.btnExaminarCarpeta.Location = new System.Drawing.Point(498, 12);
			this.btnExaminarCarpeta.Name = "btnExaminarCarpeta";
			this.btnExaminarCarpeta.Size = new System.Drawing.Size(32, 23);
			this.btnExaminarCarpeta.TabIndex = 17;
			this.btnExaminarCarpeta.Text = "...";
			this.btnExaminarCarpeta.UseVisualStyleBackColor = true;
			this.btnExaminarCarpeta.Click += new System.EventHandler(this.btnExaminarCarpeta_Click);
			// 
			// gbTipos
			// 
			this.gbTipos.Controls.Add(this.rbCreateView);
			this.gbTipos.Controls.Add(this.rbFromJoinsApply);
			this.gbTipos.Controls.Add(this.rbTodos);
			this.gbTipos.Controls.Add(this.rbMerge);
			this.gbTipos.Controls.Add(this.rbCreateTable);
			this.gbTipos.Location = new System.Drawing.Point(13, 50);
			this.gbTipos.Name = "gbTipos";
			this.gbTipos.Size = new System.Drawing.Size(447, 48);
			this.gbTipos.TabIndex = 20;
			this.gbTipos.TabStop = false;
			this.gbTipos.Text = "Tipo de análisis";
			// 
			// rbCreateView
			// 
			this.rbCreateView.AutoSize = true;
			this.rbCreateView.Location = new System.Drawing.Point(175, 19);
			this.rbCreateView.Name = "rbCreateView";
			this.rbCreateView.Size = new System.Drawing.Size(81, 17);
			this.rbCreateView.TabIndex = 6;
			this.rbCreateView.Text = "Create view";
			this.rbCreateView.UseVisualStyleBackColor = true;
			this.rbCreateView.CheckedChanged += new System.EventHandler(this.rb_CheckedChanged);
			// 
			// rbFromJoinsApply
			// 
			this.rbFromJoinsApply.AutoSize = true;
			this.rbFromJoinsApply.Location = new System.Drawing.Point(262, 19);
			this.rbFromJoinsApply.Name = "rbFromJoinsApply";
			this.rbFromJoinsApply.Size = new System.Drawing.Size(106, 17);
			this.rbFromJoinsApply.TabIndex = 4;
			this.rbFromJoinsApply.Text = "From, joins, apply";
			this.rbFromJoinsApply.UseVisualStyleBackColor = true;
			this.rbFromJoinsApply.CheckedChanged += new System.EventHandler(this.rb_CheckedChanged);
			// 
			// rbTodos
			// 
			this.rbTodos.AutoSize = true;
			this.rbTodos.Checked = true;
			this.rbTodos.Location = new System.Drawing.Point(22, 19);
			this.rbTodos.Name = "rbTodos";
			this.rbTodos.Size = new System.Drawing.Size(55, 17);
			this.rbTodos.TabIndex = 1;
			this.rbTodos.TabStop = true;
			this.rbTodos.Text = "Todos";
			this.rbTodos.UseVisualStyleBackColor = true;
			this.rbTodos.CheckedChanged += new System.EventHandler(this.rb_CheckedChanged);
			// 
			// rbMerge
			// 
			this.rbMerge.AutoSize = true;
			this.rbMerge.Location = new System.Drawing.Point(374, 19);
			this.rbMerge.Name = "rbMerge";
			this.rbMerge.Size = new System.Drawing.Size(55, 17);
			this.rbMerge.TabIndex = 5;
			this.rbMerge.Text = "Merge";
			this.rbMerge.UseVisualStyleBackColor = true;
			this.rbMerge.CheckedChanged += new System.EventHandler(this.rb_CheckedChanged);
			// 
			// rbCreateTable
			// 
			this.rbCreateTable.AutoSize = true;
			this.rbCreateTable.Location = new System.Drawing.Point(87, 19);
			this.rbCreateTable.Name = "rbCreateTable";
			this.rbCreateTable.Size = new System.Drawing.Size(82, 17);
			this.rbCreateTable.TabIndex = 2;
			this.rbCreateTable.Text = "Create table";
			this.rbCreateTable.UseVisualStyleBackColor = true;
			this.rbCreateTable.CheckedChanged += new System.EventHandler(this.rb_CheckedChanged);
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(19, 117);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(32, 13);
			this.label4.TabIndex = 27;
			this.label4.Text = "Filtro:";
			// 
			// tbFiltro
			// 
			this.tbFiltro.Location = new System.Drawing.Point(57, 114);
			this.tbFiltro.Name = "tbFiltro";
			this.tbFiltro.Size = new System.Drawing.Size(295, 20);
			this.tbFiltro.TabIndex = 26;
			// 
			// btnAnalizar
			// 
			this.btnAnalizar.Location = new System.Drawing.Point(358, 112);
			this.btnAnalizar.Name = "btnAnalizar";
			this.btnAnalizar.Size = new System.Drawing.Size(75, 23);
			this.btnAnalizar.TabIndex = 25;
			this.btnAnalizar.Text = "Analizar";
			this.btnAnalizar.UseVisualStyleBackColor = true;
			this.btnAnalizar.Click += new System.EventHandler(this.btnAnalizar_Click);
			// 
			// tvTablas
			// 
			this.tvTablas.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.tvTablas.Location = new System.Drawing.Point(22, 154);
			this.tvTablas.Name = "tvTablas";
			this.tvTablas.Size = new System.Drawing.Size(807, 295);
			this.tvTablas.TabIndex = 28;
			this.tvTablas.NodeMouseDoubleClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.tv_NodeMouseDoubleClick);
			// 
			// statusStrip1
			// 
			this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lblStatus});
			this.statusStrip1.Location = new System.Drawing.Point(0, 462);
			this.statusStrip1.Name = "statusStrip1";
			this.statusStrip1.Size = new System.Drawing.Size(856, 22);
			this.statusStrip1.TabIndex = 29;
			this.statusStrip1.Text = "statusStrip1";
			// 
			// lblStatus
			// 
			this.lblStatus.Name = "lblStatus";
			this.lblStatus.Size = new System.Drawing.Size(0, 17);
			// 
			// fbCarpeta
			// 
			this.fbCarpeta.ShowNewFolderButton = false;
			// 
			// BusquedaObjetos
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(856, 484);
			this.Controls.Add(this.statusStrip1);
			this.Controls.Add(this.tvTablas);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.tbFiltro);
			this.Controls.Add(this.btnAnalizar);
			this.Controls.Add(this.chkRecursivo);
			this.Controls.Add(this.tbCarpeta);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.btnExaminarCarpeta);
			this.Controls.Add(this.gbTipos);
			this.Name = "BusquedaObjetos";
			this.Text = "Busqueda de objetos de ETLS\'s";
			this.Load += new System.EventHandler(this.BusquedaObjetos_Load);
			this.gbTipos.ResumeLayout(false);
			this.gbTipos.PerformLayout();
			this.statusStrip1.ResumeLayout(false);
			this.statusStrip1.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.CheckBox chkRecursivo;
		private System.Windows.Forms.TextBox tbCarpeta;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Button btnExaminarCarpeta;
		private System.Windows.Forms.GroupBox gbTipos;
		private System.Windows.Forms.RadioButton rbFromJoinsApply;
		private System.Windows.Forms.RadioButton rbTodos;
		private System.Windows.Forms.RadioButton rbMerge;
		private System.Windows.Forms.RadioButton rbCreateTable;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.TextBox tbFiltro;
		private System.Windows.Forms.Button btnAnalizar;
		private System.Windows.Forms.TreeView tvTablas;
		private System.Windows.Forms.StatusStrip statusStrip1;
		private System.Windows.Forms.ToolStripStatusLabel lblStatus;
		private System.Windows.Forms.RadioButton rbCreateView;
		private System.Windows.Forms.FolderBrowserDialog fbCarpeta;
	}
}

